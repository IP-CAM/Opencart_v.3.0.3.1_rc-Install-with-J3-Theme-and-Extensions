-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 02, 2020 at 08:52 PM
-- Server version: 5.7.21-20-beget-5.7.21-20-1-log
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mmvmolkov_op`
--

-- --------------------------------------------------------

--
-- Table structure for table `oc_address`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_address`;
CREATE TABLE `oc_address` (
  `address_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `company` varchar(40) NOT NULL,
  `address_1` varchar(128) NOT NULL,
  `address_2` varchar(128) NOT NULL,
  `city` varchar(128) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `country_id` int(11) NOT NULL DEFAULT '0',
  `zone_id` int(11) NOT NULL DEFAULT '0',
  `custom_field` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_advertise_google_target`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_advertise_google_target`;
CREATE TABLE `oc_advertise_google_target` (
  `advertise_google_target_id` int(11) UNSIGNED NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `campaign_name` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(2) NOT NULL DEFAULT '',
  `budget` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `feeds` text NOT NULL,
  `status` enum('paused','active') NOT NULL DEFAULT 'paused'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_api`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_api`;
CREATE TABLE `oc_api` (
  `api_id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `key` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_api`
--

INSERT INTO `oc_api` (`api_id`, `username`, `key`, `status`, `date_added`, `date_modified`) VALUES
(1, 'Default', 'hAnMBQkD99MwtoRq36B0iHHOmuYwpQyTNn7I1ySNN9l4smTv4kZ7mPpXJzMDiIRkF7quwlQre17FBcxfZSCXLY9Ie21CIAxJBOQOQi64NbfUaasFjBfX6f8DYrxIk5tJkDFeKLk4WXdLRJmTt5ZXD3k23hyOFwuDRlNK7XejctO6Y1PTlIC5mJYsuP4zvErpT7xMR6V2ocDXjIsa1qWAfreKGdxRQcmHdahTCynfqQ88gE9k1yo7DM3nIRUkcIrg', 1, '2020-08-02 09:18:25', '2020-08-02 09:18:25');

-- --------------------------------------------------------

--
-- Table structure for table `oc_api_ip`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_api_ip`;
CREATE TABLE `oc_api_ip` (
  `api_ip_id` int(11) NOT NULL,
  `api_id` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_api_session`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_api_session`;
CREATE TABLE `oc_api_session` (
  `api_session_id` int(11) NOT NULL,
  `api_id` int(11) NOT NULL,
  `session_id` varchar(32) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_attribute`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_attribute`;
CREATE TABLE `oc_attribute` (
  `attribute_id` int(11) NOT NULL,
  `attribute_group_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_attribute`
--

INSERT INTO `oc_attribute` (`attribute_id`, `attribute_group_id`, `sort_order`) VALUES
(1, 6, 1),
(2, 6, 5),
(3, 6, 3),
(4, 3, 1),
(5, 3, 2),
(6, 3, 3),
(7, 3, 4),
(8, 3, 5),
(9, 3, 6),
(10, 3, 7),
(11, 3, 8);

-- --------------------------------------------------------

--
-- Table structure for table `oc_attribute_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_attribute_description`;
CREATE TABLE `oc_attribute_description` (
  `attribute_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_attribute_description`
--

INSERT INTO `oc_attribute_description` (`attribute_id`, `language_id`, `name`) VALUES
(1, 1, 'Description'),
(2, 1, 'No. of Cores'),
(4, 1, 'test 1'),
(5, 1, 'test 2'),
(6, 1, 'test 3'),
(7, 1, 'test 4'),
(8, 1, 'test 5'),
(9, 1, 'test 6'),
(10, 1, 'test 7'),
(11, 1, 'test 8'),
(3, 1, 'Clockspeed'),
(1, 2, 'Description'),
(2, 2, 'No. of Cores'),
(4, 2, 'test 1'),
(5, 2, 'test 2'),
(6, 2, 'test 3'),
(7, 2, 'test 4'),
(8, 2, 'test 5'),
(9, 2, 'test 6'),
(10, 2, 'test 7'),
(11, 2, 'test 8'),
(3, 2, 'Clockspeed');

-- --------------------------------------------------------

--
-- Table structure for table `oc_attribute_group`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_attribute_group`;
CREATE TABLE `oc_attribute_group` (
  `attribute_group_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_attribute_group`
--

INSERT INTO `oc_attribute_group` (`attribute_group_id`, `sort_order`) VALUES
(3, 2),
(4, 1),
(5, 3),
(6, 4);

-- --------------------------------------------------------

--
-- Table structure for table `oc_attribute_group_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_attribute_group_description`;
CREATE TABLE `oc_attribute_group_description` (
  `attribute_group_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_attribute_group_description`
--

INSERT INTO `oc_attribute_group_description` (`attribute_group_id`, `language_id`, `name`) VALUES
(3, 1, 'Memory'),
(4, 1, 'Technical'),
(5, 1, 'Motherboard'),
(6, 1, 'Processor'),
(3, 2, 'Memory'),
(4, 2, 'Technical'),
(5, 2, 'Motherboard'),
(6, 2, 'Processor');

-- --------------------------------------------------------

--
-- Table structure for table `oc_banner`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_banner`;
CREATE TABLE `oc_banner` (
  `banner_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_banner`
--

INSERT INTO `oc_banner` (`banner_id`, `name`, `status`) VALUES
(6, 'HP Products', 1),
(7, 'Home Page Slideshow', 1),
(8, 'Manufacturers', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_banner_image`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_banner_image`;
CREATE TABLE `oc_banner_image` (
  `banner_image_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(64) NOT NULL,
  `link` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_banner_image`
--

INSERT INTO `oc_banner_image` (`banner_image_id`, `banner_id`, `language_id`, `title`, `link`, `image`, `sort_order`) VALUES
(79, 7, 1, 'iPhone 6', 'index.php?route=product/product&amp;path=57&amp;product_id=49', 'catalog/demo/banners/iPhone6.jpg', 0),
(87, 6, 1, 'HP Banner', 'index.php?route=product/manufacturer/info&amp;manufacturer_id=7', 'catalog/demo/compaq_presario.jpg', 0),
(94, 8, 1, 'NFL', '', 'catalog/demo/manufacturer/nfl.png', 0),
(95, 8, 1, 'RedBull', '', 'catalog/demo/manufacturer/redbull.png', 0),
(96, 8, 1, 'Sony', '', 'catalog/demo/manufacturer/sony.png', 0),
(91, 8, 1, 'Coca Cola', '', 'catalog/demo/manufacturer/cocacola.png', 0),
(92, 8, 1, 'Burger King', '', 'catalog/demo/manufacturer/burgerking.png', 0),
(93, 8, 1, 'Canon', '', 'catalog/demo/manufacturer/canon.png', 0),
(88, 8, 1, 'Harley Davidson', '', 'catalog/demo/manufacturer/harley.png', 0),
(89, 8, 1, 'Dell', '', 'catalog/demo/manufacturer/dell.png', 0),
(90, 8, 1, 'Disney', '', 'catalog/demo/manufacturer/disney.png', 0),
(80, 7, 1, 'MacBookAir', '', 'catalog/demo/banners/MacBookAir.jpg', 0),
(97, 8, 1, 'Starbucks', '', 'catalog/demo/manufacturer/starbucks.png', 0),
(98, 8, 1, 'Nintendo', '', 'catalog/demo/manufacturer/nintendo.png', 0),
(99, 7, 2, 'iPhone 6', 'index.php?route=product/product&amp;path=57&amp;product_id=49', 'catalog/demo/banners/iPhone6.jpg', 0),
(100, 6, 2, 'HP Banner', 'index.php?route=product/manufacturer/info&amp;manufacturer_id=7', 'catalog/demo/compaq_presario.jpg', 0),
(101, 8, 2, 'NFL', '', 'catalog/demo/manufacturer/nfl.png', 0),
(102, 8, 2, 'RedBull', '', 'catalog/demo/manufacturer/redbull.png', 0),
(103, 8, 2, 'Sony', '', 'catalog/demo/manufacturer/sony.png', 0),
(104, 8, 2, 'Coca Cola', '', 'catalog/demo/manufacturer/cocacola.png', 0),
(105, 8, 2, 'Burger King', '', 'catalog/demo/manufacturer/burgerking.png', 0),
(106, 8, 2, 'Canon', '', 'catalog/demo/manufacturer/canon.png', 0),
(107, 8, 2, 'Harley Davidson', '', 'catalog/demo/manufacturer/harley.png', 0),
(108, 8, 2, 'Dell', '', 'catalog/demo/manufacturer/dell.png', 0),
(109, 8, 2, 'Disney', '', 'catalog/demo/manufacturer/disney.png', 0),
(110, 7, 2, 'MacBookAir', '', 'catalog/demo/banners/MacBookAir.jpg', 0),
(111, 8, 2, 'Starbucks', '', 'catalog/demo/manufacturer/starbucks.png', 0),
(112, 8, 2, 'Nintendo', '', 'catalog/demo/manufacturer/nintendo.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_cart`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 01:17 PM
--

DROP TABLE IF EXISTS `oc_cart`;
CREATE TABLE `oc_cart` (
  `cart_id` int(11) UNSIGNED NOT NULL,
  `api_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `session_id` varchar(32) NOT NULL,
  `product_id` int(11) NOT NULL,
  `recurring_id` int(11) NOT NULL,
  `option` text NOT NULL,
  `quantity` int(5) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_category`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_category`;
CREATE TABLE `oc_category` (
  `category_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `top` tinyint(1) NOT NULL,
  `column` int(3) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_category`
--

INSERT INTO `oc_category` (`category_id`, `image`, `parent_id`, `top`, `column`, `sort_order`, `status`, `date_added`, `date_modified`) VALUES
(25, '', 0, 1, 1, 3, 1, '2009-01-31 01:04:25', '2011-05-30 12:14:55'),
(27, '', 20, 0, 0, 2, 1, '2009-01-31 01:55:34', '2010-08-22 06:32:15'),
(20, 'catalog/demo/compaq_presario.jpg', 0, 1, 1, 1, 1, '2009-01-05 21:49:43', '2011-07-16 02:14:42'),
(24, '', 0, 1, 1, 5, 1, '2009-01-20 02:36:26', '2011-05-30 12:15:18'),
(18, 'catalog/demo/hp_2.jpg', 0, 1, 0, 2, 1, '2009-01-05 21:49:15', '2011-05-30 12:13:55'),
(17, '', 0, 1, 1, 4, 1, '2009-01-03 21:08:57', '2011-05-30 12:15:11'),
(28, '', 25, 0, 0, 1, 1, '2009-02-02 13:11:12', '2010-08-22 06:32:46'),
(26, '', 20, 0, 0, 1, 1, '2009-01-31 01:55:14', '2010-08-22 06:31:45'),
(29, '', 25, 0, 0, 1, 1, '2009-02-02 13:11:37', '2010-08-22 06:32:39'),
(30, '', 25, 0, 0, 1, 1, '2009-02-02 13:11:59', '2010-08-22 06:33:00'),
(31, '', 25, 0, 0, 1, 1, '2009-02-03 14:17:24', '2010-08-22 06:33:06'),
(32, '', 25, 0, 0, 1, 1, '2009-02-03 14:17:34', '2010-08-22 06:33:12'),
(33, '', 0, 1, 1, 6, 1, '2009-02-03 14:17:55', '2011-05-30 12:15:25'),
(34, 'catalog/demo/ipod_touch_4.jpg', 0, 1, 4, 7, 1, '2009-02-03 14:18:11', '2011-05-30 12:15:31'),
(35, '', 28, 0, 0, 0, 1, '2010-09-17 10:06:48', '2010-09-18 14:02:42'),
(36, '', 28, 0, 0, 0, 1, '2010-09-17 10:07:13', '2010-09-18 14:02:55'),
(37, '', 34, 0, 0, 0, 1, '2010-09-18 14:03:39', '2011-04-22 01:55:08'),
(38, '', 34, 0, 0, 0, 1, '2010-09-18 14:03:51', '2010-09-18 14:03:51'),
(39, '', 34, 0, 0, 0, 1, '2010-09-18 14:04:17', '2011-04-22 01:55:20'),
(40, '', 34, 0, 0, 0, 1, '2010-09-18 14:05:36', '2010-09-18 14:05:36'),
(41, '', 34, 0, 0, 0, 1, '2010-09-18 14:05:49', '2011-04-22 01:55:30'),
(42, '', 34, 0, 0, 0, 1, '2010-09-18 14:06:34', '2010-11-07 20:31:04'),
(43, '', 34, 0, 0, 0, 1, '2010-09-18 14:06:49', '2011-04-22 01:55:40'),
(44, '', 34, 0, 0, 0, 1, '2010-09-21 15:39:21', '2010-11-07 20:30:55'),
(45, '', 18, 0, 0, 0, 1, '2010-09-24 18:29:16', '2011-04-26 08:52:11'),
(46, '', 18, 0, 0, 0, 1, '2010-09-24 18:29:31', '2011-04-26 08:52:23'),
(47, '', 34, 0, 0, 0, 1, '2010-11-07 11:13:16', '2010-11-07 11:13:16'),
(48, '', 34, 0, 0, 0, 1, '2010-11-07 11:13:33', '2010-11-07 11:13:33'),
(49, '', 34, 0, 0, 0, 1, '2010-11-07 11:14:04', '2010-11-07 11:14:04'),
(50, '', 34, 0, 0, 0, 1, '2010-11-07 11:14:23', '2011-04-22 01:16:01'),
(51, '', 34, 0, 0, 0, 1, '2010-11-07 11:14:38', '2011-04-22 01:16:13'),
(52, '', 34, 0, 0, 0, 1, '2010-11-07 11:16:09', '2011-04-22 01:54:57'),
(53, '', 34, 0, 0, 0, 1, '2010-11-07 11:28:53', '2011-04-22 01:14:36'),
(54, '', 34, 0, 0, 0, 1, '2010-11-07 11:29:16', '2011-04-22 01:16:50'),
(55, '', 34, 0, 0, 0, 1, '2010-11-08 10:31:32', '2010-11-08 10:31:32'),
(56, '', 34, 0, 0, 0, 1, '2010-11-08 10:31:50', '2011-04-22 01:16:37'),
(57, '', 0, 1, 1, 3, 1, '2011-04-26 08:53:16', '2011-05-30 12:15:05'),
(58, '', 52, 0, 0, 0, 1, '2011-05-08 13:44:16', '2011-05-08 13:44:16');

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_description`
--
-- Creation: Aug 02, 2020 at 10:54 AM
-- Last update: Aug 02, 2020 at 10:54 AM
--

DROP TABLE IF EXISTS `oc_category_description`;
CREATE TABLE `oc_category_description` (
  `category_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  `seo_h1` varchar(255) NOT NULL,
  `seo_h2` varchar(255) NOT NULL,
  `seo_h3` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_category_description`
--

INSERT INTO `oc_category_description` (`category_id`, `language_id`, `name`, `description`, `meta_title`, `meta_description`, `meta_keyword`, `seo_keyword`, `seo_h1`, `seo_h2`, `seo_h3`) VALUES
(28, 1, 'Monitors', '', 'Monitors', '', '', '', '', '', ''),
(33, 1, 'Cameras', '', 'Cameras', '', '', '', '', '', ''),
(32, 1, 'Web Cameras', '', 'Web Cameras', '', '', '', '', '', ''),
(31, 1, 'Scanners', '', 'Scanners', '', '', '', '', '', ''),
(30, 1, 'Printers', '', 'Printers', '', '', '', '', '', ''),
(29, 1, 'Mice and Trackballs', '', 'Mice and Trackballs', '', '', '', '', '', ''),
(27, 1, 'Mac', '', 'Mac', '', '', '', '', '', ''),
(26, 1, 'PC', '', 'PC', '', '', '', '', '', ''),
(17, 1, 'Software', '', 'Software', '', '', '', '', '', ''),
(25, 1, 'Components', '', 'Components', '', '', '', '', '', ''),
(24, 1, 'Phones &amp; PDAs', '', 'Phones &amp; PDAs', '', '', '', '', '', ''),
(20, 1, 'Desktops', '&lt;p&gt;\r\n	Example of category description text&lt;/p&gt;\r\n', 'Desktops', 'Example of category description', '', '', '', '', ''),
(35, 1, 'test 1', '', 'test 1', '', '', '', '', '', ''),
(36, 1, 'test 2', '', 'test 2', '', '', '', '', '', ''),
(37, 1, 'test 5', '', 'test 5', '', '', '', '', '', ''),
(38, 1, 'test 4', '', 'test 4', '', '', '', '', '', ''),
(39, 1, 'test 6', '', 'test 6', '', '', '', '', '', ''),
(40, 1, 'test 7', '', 'test 7', '', '', '', '', '', ''),
(41, 1, 'test 8', '', 'test 8', '', '', '', '', '', ''),
(42, 1, 'test 9', '', 'test 9', '', '', '', '', '', ''),
(43, 1, 'test 11', '', 'test 11', '', '', '', '', '', ''),
(34, 1, 'MP3 Players', '&lt;p&gt;\r\n	Shop Laptop feature only the best laptop deals on the market. By comparing laptop deals from the likes of PC World, Comet, Dixons, The Link and Carphone Warehouse, Shop Laptop has the most comprehensive selection of laptops on the internet. At Shop Laptop, we pride ourselves on offering customers the very best laptop deals. From refurbished laptops to netbooks, Shop Laptop ensures that every laptop - in every colour, style, size and technical spec - is featured on the site at the lowest possible price.&lt;/p&gt;\r\n', 'MP3 Players', '', '', '', '', '', ''),
(18, 1, 'Laptops &amp; Notebooks', '&lt;p&gt;\r\n	Shop Laptop feature only the best laptop deals on the market. By comparing laptop deals from the likes of PC World, Comet, Dixons, The Link and Carphone Warehouse, Shop Laptop has the most comprehensive selection of laptops on the internet. At Shop Laptop, we pride ourselves on offering customers the very best laptop deals. From refurbished laptops to netbooks, Shop Laptop ensures that every laptop - in every colour, style, size and technical spec - is featured on the site at the lowest possible price.&lt;/p&gt;\r\n', 'Laptops &amp; Notebooks', '', '', '', '', '', ''),
(44, 1, 'test 12', '', 'test 12', '', '', '', '', '', ''),
(45, 1, 'Windows', '', 'Windows', '', '', '', '', '', ''),
(46, 1, 'Macs', '', 'Macs', '', '', '', '', '', ''),
(47, 1, 'test 15', '', 'test 15', '', '', '', '', '', ''),
(48, 1, 'test 16', '', 'test 16', '', '', '', '', '', ''),
(49, 1, 'test 17', '', 'test 17', '', '', '', '', '', ''),
(50, 1, 'test 18', '', 'test 18', '', '', '', '', '', ''),
(51, 1, 'test 19', '', 'test 19', '', '', '', '', '', ''),
(52, 1, 'test 20', '', 'test 20', '', '', '', '', '', ''),
(53, 1, 'test 21', '', 'test 21', '', '', '', '', '', ''),
(54, 1, 'test 22', '', 'test 22', '', '', '', '', '', ''),
(55, 1, 'test 23', '', 'test 23', '', '', '', '', '', ''),
(56, 1, 'test 24', '', 'test 24', '', '', '', '', '', ''),
(57, 1, 'Tablets', '', 'Tablets', '', '', '', '', '', ''),
(58, 1, 'test 25', '', 'test 25', '', '', '', '', '', ''),
(28, 2, 'Monitors', '', 'Monitors', '', '', '', '', '', ''),
(33, 2, 'Cameras', '', 'Cameras', '', '', '', '', '', ''),
(32, 2, 'Web Cameras', '', 'Web Cameras', '', '', '', '', '', ''),
(31, 2, 'Scanners', '', 'Scanners', '', '', '', '', '', ''),
(30, 2, 'Printers', '', 'Printers', '', '', '', '', '', ''),
(29, 2, 'Mice and Trackballs', '', 'Mice and Trackballs', '', '', '', '', '', ''),
(27, 2, 'Mac', '', 'Mac', '', '', '', '', '', ''),
(26, 2, 'PC', '', 'PC', '', '', '', '', '', ''),
(17, 2, 'Software', '', 'Software', '', '', '', '', '', ''),
(25, 2, 'Components', '', 'Components', '', '', '', '', '', ''),
(24, 2, 'Phones &amp; PDAs', '', 'Phones &amp; PDAs', '', '', '', '', '', ''),
(20, 2, 'Desktops', '&lt;p&gt;\r\n	Example of category description text&lt;/p&gt;\r\n', 'Desktops', 'Example of category description', '', '', '', '', ''),
(35, 2, 'test 1', '', 'test 1', '', '', '', '', '', ''),
(36, 2, 'test 2', '', 'test 2', '', '', '', '', '', ''),
(37, 2, 'test 5', '', 'test 5', '', '', '', '', '', ''),
(38, 2, 'test 4', '', 'test 4', '', '', '', '', '', ''),
(39, 2, 'test 6', '', 'test 6', '', '', '', '', '', ''),
(40, 2, 'test 7', '', 'test 7', '', '', '', '', '', ''),
(41, 2, 'test 8', '', 'test 8', '', '', '', '', '', ''),
(42, 2, 'test 9', '', 'test 9', '', '', '', '', '', ''),
(43, 2, 'test 11', '', 'test 11', '', '', '', '', '', ''),
(34, 2, 'MP3 Players', '&lt;p&gt;\r\n	Shop Laptop feature only the best laptop deals on the market. By comparing laptop deals from the likes of PC World, Comet, Dixons, The Link and Carphone Warehouse, Shop Laptop has the most comprehensive selection of laptops on the internet. At Shop Laptop, we pride ourselves on offering customers the very best laptop deals. From refurbished laptops to netbooks, Shop Laptop ensures that every laptop - in every colour, style, size and technical spec - is featured on the site at the lowest possible price.&lt;/p&gt;\r\n', 'MP3 Players', '', '', '', '', '', ''),
(18, 2, 'Laptops &amp; Notebooks', '&lt;p&gt;\r\n	Shop Laptop feature only the best laptop deals on the market. By comparing laptop deals from the likes of PC World, Comet, Dixons, The Link and Carphone Warehouse, Shop Laptop has the most comprehensive selection of laptops on the internet. At Shop Laptop, we pride ourselves on offering customers the very best laptop deals. From refurbished laptops to netbooks, Shop Laptop ensures that every laptop - in every colour, style, size and technical spec - is featured on the site at the lowest possible price.&lt;/p&gt;\r\n', 'Laptops &amp; Notebooks', '', '', '', '', '', ''),
(44, 2, 'test 12', '', 'test 12', '', '', '', '', '', ''),
(45, 2, 'Windows', '', 'Windows', '', '', '', '', '', ''),
(46, 2, 'Macs', '', 'Macs', '', '', '', '', '', ''),
(47, 2, 'test 15', '', 'test 15', '', '', '', '', '', ''),
(48, 2, 'test 16', '', 'test 16', '', '', '', '', '', ''),
(49, 2, 'test 17', '', 'test 17', '', '', '', '', '', ''),
(50, 2, 'test 18', '', 'test 18', '', '', '', '', '', ''),
(51, 2, 'test 19', '', 'test 19', '', '', '', '', '', ''),
(52, 2, 'test 20', '', 'test 20', '', '', '', '', '', ''),
(53, 2, 'test 21', '', 'test 21', '', '', '', '', '', ''),
(54, 2, 'test 22', '', 'test 22', '', '', '', '', '', ''),
(55, 2, 'test 23', '', 'test 23', '', '', '', '', '', ''),
(56, 2, 'test 24', '', 'test 24', '', '', '', '', '', ''),
(57, 2, 'Tablets', '', 'Tablets', '', '', '', '', '', ''),
(58, 2, 'test 25', '', 'test 25', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_filter`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_category_filter`;
CREATE TABLE `oc_category_filter` (
  `category_id` int(11) NOT NULL,
  `filter_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_path`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_category_path`;
CREATE TABLE `oc_category_path` (
  `category_id` int(11) NOT NULL,
  `path_id` int(11) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_category_path`
--

INSERT INTO `oc_category_path` (`category_id`, `path_id`, `level`) VALUES
(25, 25, 0),
(28, 25, 0),
(28, 28, 1),
(35, 25, 0),
(35, 28, 1),
(35, 35, 2),
(36, 25, 0),
(36, 28, 1),
(36, 36, 2),
(29, 25, 0),
(29, 29, 1),
(30, 25, 0),
(30, 30, 1),
(31, 25, 0),
(31, 31, 1),
(32, 25, 0),
(32, 32, 1),
(20, 20, 0),
(27, 20, 0),
(27, 27, 1),
(26, 20, 0),
(26, 26, 1),
(24, 24, 0),
(18, 18, 0),
(45, 18, 0),
(45, 45, 1),
(46, 18, 0),
(46, 46, 1),
(17, 17, 0),
(33, 33, 0),
(34, 34, 0),
(37, 34, 0),
(37, 37, 1),
(38, 34, 0),
(38, 38, 1),
(39, 34, 0),
(39, 39, 1),
(40, 34, 0),
(40, 40, 1),
(41, 34, 0),
(41, 41, 1),
(42, 34, 0),
(42, 42, 1),
(43, 34, 0),
(43, 43, 1),
(44, 34, 0),
(44, 44, 1),
(47, 34, 0),
(47, 47, 1),
(48, 34, 0),
(48, 48, 1),
(49, 34, 0),
(49, 49, 1),
(50, 34, 0),
(50, 50, 1),
(51, 34, 0),
(51, 51, 1),
(52, 34, 0),
(52, 52, 1),
(58, 34, 0),
(58, 52, 1),
(58, 58, 2),
(53, 34, 0),
(53, 53, 1),
(54, 34, 0),
(54, 54, 1),
(55, 34, 0),
(55, 55, 1),
(56, 34, 0),
(56, 56, 1),
(57, 57, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_to_google_product_category`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_category_to_google_product_category`;
CREATE TABLE `oc_category_to_google_product_category` (
  `google_product_category` varchar(10) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_to_layout`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_category_to_layout`;
CREATE TABLE `oc_category_to_layout` (
  `category_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_to_store`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_category_to_store`;
CREATE TABLE `oc_category_to_store` (
  `category_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_category_to_store`
--

INSERT INTO `oc_category_to_store` (`category_id`, `store_id`) VALUES
(17, 0),
(18, 0),
(20, 0),
(24, 0),
(25, 0),
(26, 0),
(27, 0),
(28, 0),
(29, 0),
(30, 0),
(31, 0),
(32, 0),
(33, 0),
(34, 0),
(35, 0),
(36, 0),
(37, 0),
(38, 0),
(39, 0),
(40, 0),
(41, 0),
(42, 0),
(43, 0),
(44, 0),
(45, 0),
(46, 0),
(47, 0),
(48, 0),
(49, 0),
(50, 0),
(51, 0),
(52, 0),
(53, 0),
(54, 0),
(55, 0),
(56, 0),
(57, 0),
(58, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_country`
--
-- Creation: Aug 02, 2020 at 10:38 AM
-- Last update: Aug 02, 2020 at 10:38 AM
--

DROP TABLE IF EXISTS `oc_country`;
CREATE TABLE `oc_country` (
  `country_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `iso_code_2` varchar(2) NOT NULL,
  `iso_code_3` varchar(3) NOT NULL,
  `address_format` text NOT NULL,
  `postcode_required` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_country`
--

INSERT INTO `oc_country` (`country_id`, `name`, `iso_code_2`, `iso_code_3`, `address_format`, `postcode_required`, `status`) VALUES
(1, 'Афганистан', 'AF', 'AFG', '', 0, 1),
(2, 'Албания', 'AL', 'ALB', '', 0, 1),
(3, 'Алжир', 'DZ', 'DZA', '', 0, 1),
(4, 'Восточное Самоа', 'AS', 'ASM', '', 0, 1),
(5, 'Андорра', 'AD', 'AND', '', 0, 1),
(6, 'Ангола', 'AO', 'AGO', '', 0, 1),
(7, 'Ангилья', 'AI', 'AIA', '', 0, 1),
(8, 'Антарктида', 'AQ', 'ATA', '', 0, 1),
(9, 'Антигуа и Барбуда', 'AG', 'ATG', '', 0, 1),
(10, 'Аргентина', 'AR', 'ARG', '', 0, 1),
(11, 'Армения', 'AM', 'ARM', '', 0, 1),
(12, 'Аруба', 'AW', 'ABW', '', 0, 1),
(13, 'Австралия', 'AU', 'AUS', '', 0, 1),
(14, 'Австрия', 'AT', 'AUT', '', 0, 1),
(15, 'Азербайджан', 'AZ', 'AZE', '', 0, 1),
(16, 'Багамские острова', 'BS', 'BHS', '', 0, 1),
(17, 'Бахрейн', 'BH', 'BHR', '', 0, 1),
(18, 'Бангладеш', 'BD', 'BGD', '', 0, 1),
(19, 'Барбадос', 'BB', 'BRB', '', 0, 1),
(20, 'Белоруссия (Беларусь)', 'BY', 'BLR', '', 0, 1),
(21, 'Бельгия', 'BE', 'BEL', '', 0, 1),
(22, 'Белиз', 'BZ', 'BLZ', '', 0, 1),
(23, 'Бенин', 'BJ', 'BEN', '', 0, 1),
(24, 'Бермудские острова', 'BM', 'BMU', '', 0, 1),
(25, 'Бутан', 'BT', 'BTN', '', 0, 1),
(26, 'Боливия', 'BO', 'BOL', '', 0, 1),
(27, 'Босния и Герцеговина', 'BA', 'BIH', '', 0, 1),
(28, 'Ботсвана', 'BW', 'BWA', '', 0, 1),
(29, 'Остров Буве', 'BV', 'BVT', '', 0, 1),
(30, 'Бразилия', 'BR', 'BRA', '', 0, 1),
(31, 'Британская территория в Индийском океане', 'IO', 'IOT', '', 0, 1),
(32, 'Бруней', 'BN', 'BRN', '', 0, 1),
(33, 'Болгария', 'BG', 'BGR', '', 0, 1),
(34, 'Буркина-Фасо', 'BF', 'BFA', '', 0, 1),
(35, 'Бурунди', 'BI', 'BDI', '', 0, 1),
(36, 'Камбоджа', 'KH', 'KHM', '', 0, 1),
(37, 'Камерун', 'CM', 'CMR', '', 0, 1),
(38, 'Канада', 'CA', 'CAN', '', 0, 1),
(39, 'Кабо-Верде', 'CV', 'CPV', '', 0, 1),
(40, 'Каймановы острова', 'KY', 'CYM', '', 0, 1),
(41, 'Центрально-Африканская Республика', 'CF', 'CAF', '', 0, 1),
(42, 'Чад', 'TD', 'TCD', '', 0, 1),
(43, 'Чили', 'CL', 'CHL', '', 0, 1),
(44, 'Китайская Народная Республика', 'CN', 'CHN', '', 0, 1),
(45, 'Остров Рождества', 'CX', 'CXR', '', 0, 1),
(46, 'Кокосовые острова', 'CC', 'CCK', '', 0, 1),
(47, 'Колумбия', 'CO', 'COL', '', 0, 1),
(48, 'Коморские острова', 'KM', 'COM', '', 0, 1),
(49, 'Конго', 'CG', 'COG', '', 0, 1),
(50, 'Острова Кука', 'CK', 'COK', '', 0, 1),
(51, 'Коста-Рика', 'CR', 'CRI', '', 0, 1),
(52, 'Кот д\'Ивуар', 'CI', 'CIV', '', 0, 1),
(53, 'Хорватия', 'HR', 'HRV', '', 0, 1),
(54, 'Куба', 'CU', 'CUB', '', 0, 1),
(55, 'Кипр', 'CY', 'CYP', '', 0, 1),
(56, 'Чехия', 'CZ', 'CZE', '', 0, 1),
(57, 'Дания', 'DK', 'DNK', '', 0, 1),
(58, 'Джибути', 'DJ', 'DJI', '', 0, 1),
(59, 'Доминика', 'DM', 'DMA', '', 0, 1),
(60, 'Доминиканская Республика', 'DO', 'DOM', '', 0, 1),
(61, 'Восточный Тимор', 'TP', 'TMP', '', 0, 1),
(62, 'Эквадор', 'EC', 'ECU', '', 0, 1),
(63, 'Египет', 'EG', 'EGY', '', 0, 1),
(64, 'Сальвадор', 'SV', 'SLV', '', 0, 1),
(65, 'Экваториальная Гвинея', 'GQ', 'GNQ', '', 0, 1),
(66, 'Эритрея', 'ER', 'ERI', '', 0, 1),
(67, 'Эстония', 'EE', 'EST', '', 0, 1),
(68, 'Эфиопия', 'ET', 'ETH', '', 0, 1),
(69, 'Фолклендские (Мальвинские) острова', 'FK', 'FLK', '', 0, 1),
(70, 'Фарерские острова', 'FO', 'FRO', '', 0, 1),
(71, 'Фиджи', 'FJ', 'FJI', '', 0, 1),
(72, 'Финляндия', 'FI', 'FIN', '', 0, 1),
(73, 'Франция', 'FR', 'FRA', '', 0, 1),
(74, 'Франция, Метрополия', 'FX', 'FXX', '', 0, 1),
(75, 'Французская Гвиана', 'GF', 'GUF', '', 0, 1),
(76, 'Французская Полинезия', 'PF', 'PYF', '', 0, 1),
(77, 'Французские Южные территории', 'TF', 'ATF', '', 0, 1),
(78, 'Габон', 'GA', 'GAB', '', 0, 1),
(79, 'Гамбия', 'GM', 'GMB', '', 0, 1),
(80, 'Грузия', 'GE', 'GEO', '', 0, 1),
(81, 'Германия', 'DE', 'DEU', '{company}\r\n{firstname} {lastname}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}', 0, 1),
(82, 'Гана', 'GH', 'GHA', '', 0, 1),
(83, 'Гибралтар', 'GI', 'GIB', '', 0, 1),
(84, 'Греция', 'GR', 'GRC', '', 0, 1),
(85, 'Гренландия', 'GL', 'GRL', '', 0, 1),
(86, 'Гренада', 'GD', 'GRD', '', 0, 1),
(87, 'Гваделупа', 'GP', 'GLP', '', 0, 1),
(88, 'Гуам', 'GU', 'GUM', '', 0, 1),
(89, 'Гватемала', 'GT', 'GTM', '', 0, 1),
(90, 'Гвинея', 'GN', 'GIN', '', 0, 1),
(91, 'Гвинея-Бисау', 'GW', 'GNB', '', 0, 1),
(92, 'Гайана', 'GY', 'GUY', '', 0, 1),
(93, 'Гаити', 'HT', 'HTI', '', 0, 1),
(94, 'Херд и Макдональд, острова', 'HM', 'HMD', '', 0, 1),
(95, 'Гондурас', 'HN', 'HND', '', 0, 1),
(96, 'Гонконг', 'HK', 'HKG', '', 0, 1),
(97, 'Венгрия', 'HU', 'HUN', '', 0, 1),
(98, 'Исландия', 'IS', 'ISL', '', 0, 1),
(99, 'Индия', 'IN', 'IND', '', 0, 1),
(100, 'Индонезия', 'ID', 'IDN', '', 0, 1),
(101, 'Иран', 'IR', 'IRN', '', 0, 1),
(102, 'Ирак', 'IQ', 'IRQ', '', 0, 1),
(103, 'Ирландия', 'IE', 'IRL', '', 0, 1),
(104, 'Израиль', 'IL', 'ISR', '', 0, 1),
(105, 'Италия', 'IT', 'ITA', '', 0, 1),
(106, 'Ямайка', 'JM', 'JAM', '', 0, 1),
(107, 'Япония', 'JP', 'JPN', '', 0, 1),
(108, 'Иордания', 'JO', 'JOR', '', 0, 1),
(109, 'Казахстан', 'KZ', 'KAZ', '', 0, 1),
(110, 'Кения', 'KE', 'KEN', '', 0, 1),
(111, 'Кирибати', 'KI', 'KIR', '', 0, 1),
(112, 'Корейская Народно-Демократическая Республика', 'KP', 'PRK', '', 0, 1),
(113, 'Республика Корея', 'KR', 'KOR', '', 0, 1),
(114, 'Кувейт', 'KW', 'KWT', '', 0, 1),
(115, 'Киргизия (Кыргызстан)', 'KG', 'KGZ', '', 0, 1),
(116, 'Лаос', 'LA', 'LAO', '', 0, 1),
(117, 'Латвия', 'LV', 'LVA', '', 0, 1),
(118, 'Ливан', 'LB', 'LBN', '', 0, 1),
(119, 'Лесото', 'LS', 'LSO', '', 0, 1),
(120, 'Либерия', 'LR', 'LBR', '', 0, 1),
(121, 'Ливия', 'LY', 'LBY', '', 0, 1),
(122, 'Лихтенштейн', 'LI', 'LIE', '', 0, 1),
(123, 'Литва', 'LT', 'LTU', '', 0, 1),
(124, 'Люксембург', 'LU', 'LUX', '', 0, 1),
(125, 'Макао', 'MO', 'MAC', '', 0, 1),
(126, 'Македония', 'MK', 'MKD', '', 0, 1),
(127, 'Мадагаскар', 'MG', 'MDG', '', 0, 1),
(128, 'Малави', 'MW', 'MWI', '', 0, 1),
(129, 'Малайзия', 'MY', 'MYS', '', 0, 1),
(130, 'Мальдивы', 'MV', 'MDV', '', 0, 1),
(131, 'Мали', 'ML', 'MLI', '', 0, 1),
(132, 'Мальта', 'MT', 'MLT', '', 0, 1),
(133, 'Маршалловы острова', 'MH', 'MHL', '', 0, 1),
(134, 'Мартиника', 'MQ', 'MTQ', '', 0, 1),
(135, 'Мавритания', 'MR', 'MRT', '', 0, 1),
(136, 'Маврикий', 'MU', 'MUS', '', 0, 1),
(137, 'Майотта', 'YT', 'MYT', '', 0, 1),
(138, 'Мексика', 'MX', 'MEX', '', 0, 1),
(139, 'Микронезия', 'FM', 'FSM', '', 0, 1),
(140, 'Молдова', 'MD', 'MDA', '', 0, 1),
(141, 'Монако', 'MC', 'MCO', '', 0, 1),
(142, 'Монголия', 'MN', 'MNG', '', 0, 1),
(143, 'Монтсеррат', 'MS', 'MSR', '', 0, 1),
(144, 'Марокко', 'MA', 'MAR', '', 0, 1),
(145, 'Мозамбик', 'MZ', 'MOZ', '', 0, 1),
(146, 'Мьянма', 'MM', 'MMR', '', 0, 1),
(147, 'Намибия', 'NA', 'NAM', '', 0, 1),
(148, 'Науру', 'NR', 'NRU', '', 0, 1),
(149, 'Непал', 'NP', 'NPL', '', 0, 1),
(150, 'Нидерланды', 'NL', 'NLD', '', 0, 1),
(151, 'Антильские (Нидерландские) острова', 'AN', 'ANT', '', 0, 1),
(152, 'Новая Каледония', 'NC', 'NCL', '', 0, 1),
(153, 'Новая Зеландия', 'NZ', 'NZL', '', 0, 1),
(154, 'Никарагуа', 'NI', 'NIC', '', 0, 1),
(155, 'Нигер', 'NE', 'NER', '', 0, 1),
(156, 'Нигерия', 'NG', 'NGA', '', 0, 1),
(157, 'Ниуэ', 'NU', 'NIU', '', 0, 1),
(158, 'Остров Норфолк', 'NF', 'NFK', '', 0, 1),
(159, 'Северные Марианские острова', 'MP', 'MNP', '', 0, 1),
(160, 'Норвегия', 'NO', 'NOR', '', 0, 1),
(161, 'Оман', 'OM', 'OMN', '', 0, 1),
(162, 'Пакистан', 'PK', 'PAK', '', 0, 1),
(163, 'Палау', 'PW', 'PLW', '', 0, 1),
(164, 'Панама', 'PA', 'PAN', '', 0, 1),
(165, 'Папуа - Новая Гвинея', 'PG', 'PNG', '', 0, 1),
(166, 'Парагвай', 'PY', 'PRY', '', 0, 1),
(167, 'Перу', 'PE', 'PER', '', 0, 1),
(168, 'Филиппины', 'PH', 'PHL', '', 0, 1),
(169, 'Острова Питкэрн', 'PN', 'PCN', '', 0, 1),
(170, 'Польша', 'PL', 'POL', '', 0, 1),
(171, 'Португалия', 'PT', 'PRT', '', 0, 1),
(172, 'Пуэрто-Рико', 'PR', 'PRI', '', 0, 1),
(173, 'Катар', 'QA', 'QAT', '', 0, 1),
(174, 'Реюньон', 'RE', 'REU', '', 0, 1),
(175, 'Румыния', 'RO', 'ROM', '', 0, 1),
(176, 'Российская Федерация', 'RU', 'RUS', '', 0, 1),
(177, 'Руанда', 'RW', 'RWA', '', 0, 1),
(178, 'Сент-Китс и Невис', 'KN', 'KNA', '', 0, 1),
(179, 'Сент-Люсия', 'LC', 'LCA', '', 0, 1),
(180, 'Сент-Винсент и Гренадины', 'VC', 'VCT', '', 0, 1),
(181, 'Западное Самоа', 'WS', 'WSM', '', 0, 1),
(182, 'Сан-Марино', 'SM', 'SMR', '', 0, 1),
(183, 'Сан-Томе и Принсипи', 'ST', 'STP', '', 0, 1),
(184, 'Саудовская Аравия', 'SA', 'SAU', '', 0, 1),
(185, 'Сенегал', 'SN', 'SEN', '', 0, 1),
(186, 'Сейшельские острова', 'SC', 'SYC', '', 0, 1),
(187, 'Сьерра-Леоне', 'SL', 'SLE', '', 0, 1),
(188, 'Сингапур', 'SG', 'SGP', '', 0, 1),
(189, 'Словакия', 'SK', 'SVK', '{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{city} {postcode}\r\n{zone}\r\n{country}', 0, 1),
(190, 'Словения', 'SI', 'SVN', '', 0, 1),
(191, 'Соломоновы острова', 'SB', 'SLB', '', 0, 1),
(192, 'Сомали', 'SO', 'SOM', '', 0, 1),
(193, 'Южно-Африканская Республика', 'ZA', 'ZAF', '', 0, 1),
(194, 'Южная Джорджия и Южные Сандвичевы острова', 'GS', 'SGS', '', 0, 1),
(195, 'Испания', 'ES', 'ESP', '', 0, 1),
(196, 'Шри-Ланка', 'LK', 'LKA', '', 0, 1),
(197, 'Остров Святой Елены', 'SH', 'SHN', '', 0, 1),
(198, 'Сен-Пьер и Микелон', 'PM', 'SPM', '', 0, 1),
(199, 'Судан', 'SD', 'SDN', '', 0, 1),
(200, 'Суринам', 'SR', 'SUR', '', 0, 1),
(201, 'Шпицберген и Ян Майен', 'SJ', 'SJM', '', 0, 1),
(202, 'Свазиленд', 'SZ', 'SWZ', '', 0, 1),
(203, 'Швеция', 'SE', 'SWE', '', 0, 1),
(204, 'Швейцария', 'CH', 'CHE', '', 0, 1),
(205, 'Сирия', 'SY', 'SYR', '', 0, 1),
(206, 'Тайвань (провинция Китая)', 'TW', 'TWN', '', 0, 1),
(207, 'Таджикистан', 'TJ', 'TJK', '', 0, 1),
(208, 'Танзания', 'TZ', 'TZA', '', 0, 1),
(209, 'Таиланд', 'TH', 'THA', '', 0, 1),
(210, 'Того', 'TG', 'TGO', '', 0, 1),
(211, 'Токелау', 'TK', 'TKL', '', 0, 1),
(212, 'Тонга', 'TO', 'TON', '', 0, 1),
(213, 'Тринидад и Тобаго', 'TT', 'TTO', '', 0, 1),
(214, 'Тунис', 'TN', 'TUN', '', 0, 1),
(215, 'Турция', 'TR', 'TUR', '', 0, 1),
(216, 'Туркменистан', 'TM', 'TKM', '', 0, 1),
(217, 'Острова Теркс и Кайкос', 'TC', 'TCA', '', 0, 1),
(218, 'Тувалу', 'TV', 'TUV', '', 0, 1),
(219, 'Уганда', 'UG', 'UGA', '', 0, 1),
(220, 'Украина', 'UA', 'UKR', '', 0, 1),
(221, 'Объединенные Арабские Эмираты', 'AE', 'ARE', '', 0, 1),
(222, 'Великобритания', 'GB', 'GBR', '', 1, 1),
(223, 'Соединенные Штаты Америки', 'US', 'USA', '{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{city}, {zone} {postcode}\r\n{country}', 0, 1),
(224, 'Мелкие отдаленные острова США', 'UM', 'UMI', '', 0, 1),
(225, 'Уругвай', 'UY', 'URY', '', 0, 1),
(226, 'Узбекистан', 'UZ', 'UZB', '', 0, 1),
(227, 'Вануату', 'VU', 'VUT', '', 0, 1),
(228, 'Ватикан', 'VA', 'VAT', '', 0, 1),
(229, 'Венесуэла', 'VE', 'VEN', '', 0, 1),
(230, 'Вьетнам', 'VN', 'VNM', '', 0, 1),
(231, 'Виргинские острова (Британские)', 'VG', 'VGB', '', 0, 1),
(232, 'Виргинские острова (США)', 'VI', 'VIR', '', 0, 1),
(233, 'Уоллис и Футуна', 'WF', 'WLF', '', 0, 1),
(234, 'Западная Сахара', 'EH', 'ESH', '', 0, 1),
(235, 'Йемен', 'YE', 'YEM', '', 0, 1),
(236, 'Сербия и Черногория', 'CS', 'SCG', '', 0, 1),
(237, 'Заир', 'ZR', 'ZAR', '', 0, 1),
(238, 'Замбия', 'ZM', 'ZMB', '', 0, 1),
(239, 'Зимбабве', 'ZW', 'ZWE', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_coupon`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_coupon`;
CREATE TABLE `oc_coupon` (
  `coupon_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `code` varchar(20) NOT NULL,
  `type` char(1) NOT NULL,
  `discount` decimal(15,4) NOT NULL,
  `logged` tinyint(1) NOT NULL,
  `shipping` tinyint(1) NOT NULL,
  `total` decimal(15,4) NOT NULL,
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00',
  `uses_total` int(11) NOT NULL,
  `uses_customer` varchar(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_coupon`
--

INSERT INTO `oc_coupon` (`coupon_id`, `name`, `code`, `type`, `discount`, `logged`, `shipping`, `total`, `date_start`, `date_end`, `uses_total`, `uses_customer`, `status`, `date_added`) VALUES
(4, '-10% Discount', '2222', 'P', '10.0000', 0, 0, '0.0000', '2014-01-01', '2020-01-01', 10, '10', 0, '2009-01-27 13:55:03'),
(5, 'Free Shipping', '3333', 'P', '0.0000', 0, 1, '100.0000', '2014-01-01', '2014-02-01', 10, '10', 0, '2009-03-14 21:13:53'),
(6, '-10.00 Discount', '1111', 'F', '10.0000', 0, 0, '10.0000', '2014-01-01', '2020-01-01', 100000, '10000', 0, '2009-03-14 21:15:18');

-- --------------------------------------------------------

--
-- Table structure for table `oc_coupon_category`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_coupon_category`;
CREATE TABLE `oc_coupon_category` (
  `coupon_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_coupon_history`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_coupon_history`;
CREATE TABLE `oc_coupon_history` (
  `coupon_history_id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_coupon_product`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_coupon_product`;
CREATE TABLE `oc_coupon_product` (
  `coupon_product_id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_currency`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:26 AM
--

DROP TABLE IF EXISTS `oc_currency`;
CREATE TABLE `oc_currency` (
  `currency_id` int(11) NOT NULL,
  `title` varchar(32) NOT NULL,
  `code` varchar(3) NOT NULL,
  `symbol_left` varchar(12) NOT NULL,
  `symbol_right` varchar(12) NOT NULL,
  `decimal_place` char(1) NOT NULL,
  `value` double(15,8) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_currency`
--

INSERT INTO `oc_currency` (`currency_id`, `title`, `code`, `symbol_left`, `symbol_right`, `decimal_place`, `value`, `status`, `date_modified`) VALUES
(4, 'Рубли', 'RUB', '', 'р.', '1', 1.00000000, 1, '2020-08-02 09:25:22');

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer`;
CREATE TABLE `oc_customer` (
  `customer_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `fax` varchar(32) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(9) NOT NULL,
  `cart` text,
  `wishlist` text,
  `newsletter` tinyint(1) NOT NULL DEFAULT '0',
  `address_id` int(11) NOT NULL DEFAULT '0',
  `custom_field` text NOT NULL,
  `ip` varchar(40) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `safe` tinyint(1) NOT NULL,
  `token` text NOT NULL,
  `code` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_activity`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_activity`;
CREATE TABLE `oc_customer_activity` (
  `customer_activity_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `key` varchar(64) NOT NULL,
  `data` text NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_affiliate`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_affiliate`;
CREATE TABLE `oc_customer_affiliate` (
  `customer_id` int(11) NOT NULL,
  `company` varchar(40) NOT NULL,
  `website` varchar(255) NOT NULL,
  `tracking` varchar(64) NOT NULL,
  `commission` decimal(4,2) NOT NULL DEFAULT '0.00',
  `tax` varchar(64) NOT NULL,
  `payment` varchar(6) NOT NULL,
  `cheque` varchar(100) NOT NULL,
  `paypal` varchar(64) NOT NULL,
  `bank_name` varchar(64) NOT NULL,
  `bank_branch_number` varchar(64) NOT NULL,
  `bank_swift_code` varchar(64) NOT NULL,
  `bank_account_name` varchar(64) NOT NULL,
  `bank_account_number` varchar(64) NOT NULL,
  `custom_field` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_approval`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_approval`;
CREATE TABLE `oc_customer_approval` (
  `customer_approval_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `type` varchar(9) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_group`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_group`;
CREATE TABLE `oc_customer_group` (
  `customer_group_id` int(11) NOT NULL,
  `approval` int(1) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_customer_group`
--

INSERT INTO `oc_customer_group` (`customer_group_id`, `approval`, `sort_order`) VALUES
(1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_group_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_customer_group_description`;
CREATE TABLE `oc_customer_group_description` (
  `customer_group_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_customer_group_description`
--

INSERT INTO `oc_customer_group_description` (`customer_group_id`, `language_id`, `name`, `description`) VALUES
(1, 1, 'Default', 'test'),
(1, 2, 'Default', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_history`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_history`;
CREATE TABLE `oc_customer_history` (
  `customer_history_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_ip`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_ip`;
CREATE TABLE `oc_customer_ip` (
  `customer_ip_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_login`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_login`;
CREATE TABLE `oc_customer_login` (
  `customer_login_id` int(11) NOT NULL,
  `email` varchar(96) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `total` int(4) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_online`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_online`;
CREATE TABLE `oc_customer_online` (
  `ip` varchar(40) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `url` text NOT NULL,
  `referer` text NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_reward`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_reward`;
CREATE TABLE `oc_customer_reward` (
  `customer_reward_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `points` int(8) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_search`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_search`;
CREATE TABLE `oc_customer_search` (
  `customer_search_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `sub_category` tinyint(1) NOT NULL,
  `description` tinyint(1) NOT NULL,
  `products` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_transaction`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_transaction`;
CREATE TABLE `oc_customer_transaction` (
  `customer_transaction_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_wishlist`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_customer_wishlist`;
CREATE TABLE `oc_customer_wishlist` (
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_custom_field`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_custom_field`;
CREATE TABLE `oc_custom_field` (
  `custom_field_id` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `value` text NOT NULL,
  `validation` varchar(255) NOT NULL,
  `location` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_custom_field_customer_group`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_custom_field_customer_group`;
CREATE TABLE `oc_custom_field_customer_group` (
  `custom_field_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_custom_field_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_custom_field_description`;
CREATE TABLE `oc_custom_field_description` (
  `custom_field_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_custom_field_value`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_custom_field_value`;
CREATE TABLE `oc_custom_field_value` (
  `custom_field_value_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_custom_field_value_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_custom_field_value_description`;
CREATE TABLE `oc_custom_field_value_description` (
  `custom_field_value_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_download`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_download`;
CREATE TABLE `oc_download` (
  `download_id` int(11) NOT NULL,
  `filename` varchar(160) NOT NULL,
  `mask` varchar(128) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_download_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_download_description`;
CREATE TABLE `oc_download_description` (
  `download_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_event`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 11:43 AM
--

DROP TABLE IF EXISTS `oc_event`;
CREATE TABLE `oc_event` (
  `event_id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `trigger` text NOT NULL,
  `action` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_event`
--

INSERT INTO `oc_event` (`event_id`, `code`, `trigger`, `action`, `status`, `sort_order`) VALUES
(1, 'activity_customer_add', 'catalog/model/account/customer/addCustomer/after', 'event/activity/addCustomer', 1, 0),
(2, 'activity_customer_edit', 'catalog/model/account/customer/editCustomer/after', 'event/activity/editCustomer', 1, 0),
(3, 'activity_customer_password', 'catalog/model/account/customer/editPassword/after', 'event/activity/editPassword', 1, 0),
(4, 'activity_customer_forgotten', 'catalog/model/account/customer/editCode/after', 'event/activity/forgotten', 1, 0),
(5, 'activity_transaction', 'catalog/model/account/customer/addTransaction/after', 'event/activity/addTransaction', 1, 0),
(6, 'activity_customer_login', 'catalog/model/account/customer/deleteLoginAttempts/after', 'event/activity/login', 1, 0),
(7, 'activity_address_add', 'catalog/model/account/address/addAddress/after', 'event/activity/addAddress', 1, 0),
(8, 'activity_address_edit', 'catalog/model/account/address/editAddress/after', 'event/activity/editAddress', 1, 0),
(9, 'activity_address_delete', 'catalog/model/account/address/deleteAddress/after', 'event/activity/deleteAddress', 1, 0),
(10, 'activity_affiliate_add', 'catalog/model/account/customer/addAffiliate/after', 'event/activity/addAffiliate', 1, 0),
(11, 'activity_affiliate_edit', 'catalog/model/account/customer/editAffiliate/after', 'event/activity/editAffiliate', 1, 0),
(12, 'activity_order_add', 'catalog/model/checkout/order/addOrderHistory/before', 'event/activity/addOrderHistory', 1, 0),
(13, 'activity_return_add', 'catalog/model/account/return/addReturn/after', 'event/activity/addReturn', 1, 0),
(14, 'mail_transaction', 'catalog/model/account/customer/addTransaction/after', 'mail/transaction', 1, 0),
(15, 'mail_forgotten', 'catalog/model/account/customer/editCode/after', 'mail/forgotten', 1, 0),
(16, 'mail_customer_add', 'catalog/model/account/customer/addCustomer/after', 'mail/register', 1, 0),
(17, 'mail_customer_alert', 'catalog/model/account/customer/addCustomer/after', 'mail/register/alert', 1, 0),
(18, 'mail_affiliate_add', 'catalog/model/account/customer/addAffiliate/after', 'mail/affiliate', 1, 0),
(19, 'mail_affiliate_alert', 'catalog/model/account/customer/addAffiliate/after', 'mail/affiliate/alert', 1, 0),
(20, 'mail_voucher', 'catalog/model/checkout/order/addOrderHistory/after', 'extension/total/voucher/send', 1, 0),
(21, 'mail_order_add', 'catalog/model/checkout/order/addOrderHistory/before', 'mail/order', 1, 0),
(22, 'mail_order_alert', 'catalog/model/checkout/order/addOrderHistory/before', 'mail/order/alert', 1, 0),
(23, 'statistics_review_add', 'catalog/model/catalog/review/addReview/after', 'event/statistics/addReview', 1, 0),
(24, 'statistics_return_add', 'catalog/model/account/return/addReturn/after', 'event/statistics/addReturn', 1, 0),
(25, 'statistics_order_history', 'catalog/model/checkout/order/addOrderHistory/after', 'event/statistics/addOrderHistory', 1, 0),
(26, 'admin_mail_affiliate_approve', 'admin/model/customer/customer_approval/approveAffiliate/after', 'mail/affiliate/approve', 1, 0),
(27, 'admin_mail_affiliate_deny', 'admin/model/customer/customer_approval/denyAffiliate/after', 'mail/affiliate/deny', 1, 0),
(28, 'admin_mail_customer_approve', 'admin/model/customer/customer_approval/approveCustomer/after', 'mail/customer/approve', 1, 0),
(29, 'admin_mail_customer_deny', 'admin/model/customer/customer_approval/denyCustomer/after', 'mail/customer/deny', 1, 0),
(30, 'admin_mail_reward', 'admin/model/customer/customer/addReward/after', 'mail/reward', 1, 0),
(31, 'admin_mail_transaction', 'admin/model/customer/customer/addTransaction/after', 'mail/transaction', 1, 0),
(32, 'admin_mail_return', 'admin/model/sale/return/addReturn/after', 'mail/return', 1, 0),
(33, 'admin_mail_forgotten', 'admin/model/user/user/editCode/after', 'mail/forgotten', 1, 0),
(34, 'advertise_google', 'admin/model/catalog/product/deleteProduct/after', 'extension/advertise/google/deleteProduct', 1, 0),
(35, 'advertise_google', 'admin/model/catalog/product/copyProduct/after', 'extension/advertise/google/copyProduct', 1, 0),
(36, 'advertise_google', 'admin/view/common/column_left/before', 'extension/advertise/google/admin_link', 1, 0),
(37, 'advertise_google', 'admin/model/catalog/product/addProduct/after', 'extension/advertise/google/addProduct', 1, 0),
(38, 'advertise_google', 'catalog/controller/checkout/success/before', 'extension/advertise/google/before_checkout_success', 1, 0),
(39, 'advertise_google', 'catalog/view/common/header/after', 'extension/advertise/google/google_global_site_tag', 1, 0),
(40, 'advertise_google', 'catalog/view/common/success/after', 'extension/advertise/google/google_dynamic_remarketing_purchase', 1, 0),
(41, 'advertise_google', 'catalog/view/product/product/after', 'extension/advertise/google/google_dynamic_remarketing_product', 1, 0),
(42, 'advertise_google', 'catalog/view/product/search/after', 'extension/advertise/google/google_dynamic_remarketing_searchresults', 1, 0),
(43, 'advertise_google', 'catalog/view/product/category/after', 'extension/advertise/google/google_dynamic_remarketing_category', 1, 0),
(44, 'advertise_google', 'catalog/view/common/home/after', 'extension/advertise/google/google_dynamic_remarketing_home', 1, 0),
(45, 'advertise_google', 'catalog/view/checkout/cart/after', 'extension/advertise/google/google_dynamic_remarketing_cart', 1, 0),
(46, 'module_quickcheckout', 'catalog/controller/checkout/checkout/before', 'extension/quickcheckout/checkout/eventPreControllerCheckoutCheckout', 1, 0),
(47, 'module_quickcheckout', 'catalog/controller/checkout/success/before', 'extension/quickcheckout/checkout/eventPreControllerCheckoutSuccess', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_extension`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 05:24 PM
--

DROP TABLE IF EXISTS `oc_extension`;
CREATE TABLE `oc_extension` (
  `extension_id` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `code` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_extension`
--

INSERT INTO `oc_extension` (`extension_id`, `type`, `code`) VALUES
(1, 'payment', 'cod'),
(2, 'total', 'shipping'),
(3, 'total', 'sub_total'),
(4, 'total', 'tax'),
(5, 'total', 'total'),
(6, 'module', 'banner'),
(7, 'module', 'carousel'),
(8, 'total', 'credit'),
(9, 'shipping', 'flat'),
(10, 'total', 'handling'),
(11, 'total', 'low_order_fee'),
(12, 'total', 'coupon'),
(13, 'module', 'category'),
(14, 'module', 'account'),
(15, 'total', 'reward'),
(16, 'total', 'voucher'),
(17, 'payment', 'free_checkout'),
(18, 'module', 'featured'),
(19, 'module', 'slideshow'),
(20, 'theme', 'default'),
(21, 'dashboard', 'activity'),
(22, 'dashboard', 'sale'),
(23, 'dashboard', 'recent'),
(24, 'dashboard', 'order'),
(25, 'dashboard', 'online'),
(26, 'dashboard', 'map'),
(27, 'dashboard', 'customer'),
(28, 'dashboard', 'chart'),
(29, 'report', 'sale_coupon'),
(31, 'report', 'customer_search'),
(32, 'report', 'customer_transaction'),
(33, 'report', 'product_purchased'),
(34, 'report', 'product_viewed'),
(35, 'report', 'sale_return'),
(36, 'report', 'sale_order'),
(37, 'report', 'sale_shipping'),
(38, 'report', 'sale_tax'),
(39, 'report', 'customer_activity'),
(40, 'report', 'customer_order'),
(41, 'report', 'customer_reward'),
(42, 'advertise', 'google'),
(44, 'module', 'ocfilter'),
(45, 'module', 'complete_seo'),
(46, 'feed', 'advanced_sitemap'),
(47, 'module', 'quickcheckout'),
(48, 'payment', 'yandex_money');

-- --------------------------------------------------------

--
-- Table structure for table `oc_extension_install`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 05:23 PM
--

DROP TABLE IF EXISTS `oc_extension_install`;
CREATE TABLE `oc_extension_install` (
  `extension_install_id` int(11) NOT NULL,
  `extension_download_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_extension_install`
--

INSERT INTO `oc_extension_install` (`extension_install_id`, `extension_download_id`, `filename`, `date_added`) VALUES
(3, 0, 'russian_oc3.ocmod.zip', '2020-08-02 09:22:55'),
(2, 0, 'localcopy_oc3.ocmod.zip', '2020-08-02 09:21:41'),
(5, 0, 'ocfilter.ocmod.zip', '2020-08-02 13:48:50'),
(6, 0, 'quickcheckout190_oc3.ocmod.zip', '2020-08-02 14:43:19'),
(9, 0, 'ycms2.oc3x.ocmod.zip', '2020-08-02 20:23:56'),
(8, 0, 'export-import-multilingual_oc3x.ocmod.zip', '2020-08-02 19:56:24');

-- --------------------------------------------------------

--
-- Table structure for table `oc_extension_path`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 05:23 PM
--

DROP TABLE IF EXISTS `oc_extension_path`;
CREATE TABLE `oc_extension_path` (
  `extension_path_id` int(11) NOT NULL,
  `extension_install_id` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_extension_path`
--

INSERT INTO `oc_extension_path` (`extension_path_id`, `extension_install_id`, `path`, `date_added`) VALUES
(306, 3, 'admin/language/ru-ru', '2020-08-02 09:22:55'),
(307, 3, 'catalog/language/ru-ru', '2020-08-02 09:22:55'),
(308, 3, 'admin/language/ru-ru/catalog', '2020-08-02 09:22:55'),
(309, 3, 'admin/language/ru-ru/common', '2020-08-02 09:22:55'),
(310, 3, 'admin/language/ru-ru/customer', '2020-08-02 09:22:55'),
(311, 3, 'admin/language/ru-ru/design', '2020-08-02 09:22:55'),
(312, 3, 'admin/language/ru-ru/error', '2020-08-02 09:22:55'),
(313, 3, 'admin/language/ru-ru/extension', '2020-08-02 09:22:55'),
(314, 3, 'admin/language/ru-ru/localisation', '2020-08-02 09:22:55'),
(315, 3, 'admin/language/ru-ru/mail', '2020-08-02 09:22:55'),
(316, 3, 'admin/language/ru-ru/marketing', '2020-08-02 09:22:55'),
(317, 3, 'admin/language/ru-ru/marketplace', '2020-08-02 09:22:55'),
(318, 3, 'admin/language/ru-ru/report', '2020-08-02 09:22:55'),
(319, 3, 'admin/language/ru-ru/ru-ru.php', '2020-08-02 09:22:55'),
(320, 3, 'admin/language/ru-ru/ru-ru.png', '2020-08-02 09:22:55'),
(321, 3, 'admin/language/ru-ru/sale', '2020-08-02 09:22:55'),
(322, 3, 'admin/language/ru-ru/setting', '2020-08-02 09:22:55'),
(323, 3, 'admin/language/ru-ru/tool', '2020-08-02 09:22:55'),
(324, 3, 'admin/language/ru-ru/user', '2020-08-02 09:22:55'),
(325, 3, 'catalog/language/ru-ru/account', '2020-08-02 09:22:55'),
(326, 3, 'catalog/language/ru-ru/affiliate', '2020-08-02 09:22:55'),
(327, 3, 'catalog/language/ru-ru/api', '2020-08-02 09:22:55'),
(328, 3, 'catalog/language/ru-ru/checkout', '2020-08-02 09:22:55'),
(329, 3, 'catalog/language/ru-ru/common', '2020-08-02 09:22:55'),
(330, 3, 'catalog/language/ru-ru/error', '2020-08-02 09:22:55'),
(331, 3, 'catalog/language/ru-ru/extension', '2020-08-02 09:22:55'),
(332, 3, 'catalog/language/ru-ru/information', '2020-08-02 09:22:55'),
(333, 3, 'catalog/language/ru-ru/mail', '2020-08-02 09:22:55'),
(334, 3, 'catalog/language/ru-ru/product', '2020-08-02 09:22:55'),
(335, 3, 'catalog/language/ru-ru/ru-ru.php', '2020-08-02 09:22:55'),
(336, 3, 'catalog/language/ru-ru/ru-ru.png', '2020-08-02 09:22:55'),
(337, 3, 'catalog/language/ru-ru/tool', '2020-08-02 09:22:55'),
(338, 3, 'admin/language/ru-ru/catalog/attribute.php', '2020-08-02 09:22:55'),
(339, 3, 'admin/language/ru-ru/catalog/attribute_group.php', '2020-08-02 09:22:55'),
(340, 3, 'admin/language/ru-ru/catalog/category.php', '2020-08-02 09:22:55'),
(341, 3, 'admin/language/ru-ru/catalog/download.php', '2020-08-02 09:22:55'),
(342, 3, 'admin/language/ru-ru/catalog/filter.php', '2020-08-02 09:22:55'),
(343, 3, 'admin/language/ru-ru/catalog/information.php', '2020-08-02 09:22:55'),
(344, 3, 'admin/language/ru-ru/catalog/manufacturer.php', '2020-08-02 09:22:55'),
(345, 3, 'admin/language/ru-ru/catalog/option.php', '2020-08-02 09:22:55'),
(346, 3, 'admin/language/ru-ru/catalog/product.php', '2020-08-02 09:22:55'),
(347, 3, 'admin/language/ru-ru/catalog/recurring.php', '2020-08-02 09:22:55'),
(348, 3, 'admin/language/ru-ru/catalog/review.php', '2020-08-02 09:22:55'),
(349, 3, 'admin/language/ru-ru/common/column_left.php', '2020-08-02 09:22:55'),
(350, 3, 'admin/language/ru-ru/common/dashboard.php', '2020-08-02 09:22:55'),
(351, 3, 'admin/language/ru-ru/common/filemanager.php', '2020-08-02 09:22:55'),
(352, 3, 'admin/language/ru-ru/common/footer.php', '2020-08-02 09:22:55'),
(353, 3, 'admin/language/ru-ru/common/forgotten.php', '2020-08-02 09:22:55'),
(354, 3, 'admin/language/ru-ru/common/header.php', '2020-08-02 09:22:55'),
(355, 3, 'admin/language/ru-ru/common/login.php', '2020-08-02 09:22:55'),
(356, 3, 'admin/language/ru-ru/common/reset.php', '2020-08-02 09:22:55'),
(357, 3, 'admin/language/ru-ru/customer/custom_field.php', '2020-08-02 09:22:55'),
(358, 3, 'admin/language/ru-ru/customer/customer.php', '2020-08-02 09:22:55'),
(359, 3, 'admin/language/ru-ru/customer/customer_approval.php', '2020-08-02 09:22:55'),
(360, 3, 'admin/language/ru-ru/customer/customer_group.php', '2020-08-02 09:22:55'),
(361, 3, 'admin/language/ru-ru/design/banner.php', '2020-08-02 09:22:55'),
(362, 3, 'admin/language/ru-ru/design/language.php', '2020-08-02 09:22:55'),
(363, 3, 'admin/language/ru-ru/design/layout.php', '2020-08-02 09:22:55'),
(364, 3, 'admin/language/ru-ru/design/menu.php', '2020-08-02 09:22:55'),
(365, 3, 'admin/language/ru-ru/design/theme.php', '2020-08-02 09:22:55'),
(366, 3, 'admin/language/ru-ru/design/translation.php', '2020-08-02 09:22:55'),
(367, 3, 'admin/language/ru-ru/error/not_found.php', '2020-08-02 09:22:55'),
(368, 3, 'admin/language/ru-ru/error/permission.php', '2020-08-02 09:22:55'),
(369, 3, 'admin/language/ru-ru/extension/analytics', '2020-08-02 09:22:55'),
(370, 3, 'admin/language/ru-ru/extension/captcha', '2020-08-02 09:22:55'),
(371, 3, 'admin/language/ru-ru/extension/dashboard', '2020-08-02 09:22:55'),
(372, 3, 'admin/language/ru-ru/extension/extension', '2020-08-02 09:22:55'),
(373, 3, 'admin/language/ru-ru/extension/feed', '2020-08-02 09:22:55'),
(374, 3, 'admin/language/ru-ru/extension/fraud', '2020-08-02 09:22:55'),
(375, 3, 'admin/language/ru-ru/extension/module', '2020-08-02 09:22:55'),
(376, 3, 'admin/language/ru-ru/extension/openbay', '2020-08-02 09:22:55'),
(377, 3, 'admin/language/ru-ru/extension/payment', '2020-08-02 09:22:55'),
(378, 3, 'admin/language/ru-ru/extension/shipping', '2020-08-02 09:22:55'),
(379, 3, 'admin/language/ru-ru/extension/store.php', '2020-08-02 09:22:55'),
(380, 3, 'admin/language/ru-ru/extension/theme', '2020-08-02 09:22:55'),
(381, 3, 'admin/language/ru-ru/extension/total', '2020-08-02 09:22:55'),
(382, 3, 'admin/language/ru-ru/localisation/country.php', '2020-08-02 09:22:55'),
(383, 3, 'admin/language/ru-ru/localisation/currency.php', '2020-08-02 09:22:55'),
(384, 3, 'admin/language/ru-ru/localisation/geo_zone.php', '2020-08-02 09:22:55'),
(385, 3, 'admin/language/ru-ru/localisation/language.php', '2020-08-02 09:22:55'),
(386, 3, 'admin/language/ru-ru/localisation/length_class.php', '2020-08-02 09:22:55'),
(387, 3, 'admin/language/ru-ru/localisation/location.php', '2020-08-02 09:22:55'),
(388, 3, 'admin/language/ru-ru/localisation/order_status.php', '2020-08-02 09:22:55'),
(389, 3, 'admin/language/ru-ru/localisation/return_action.php', '2020-08-02 09:22:55'),
(390, 3, 'admin/language/ru-ru/localisation/return_reason.php', '2020-08-02 09:22:55'),
(391, 3, 'admin/language/ru-ru/localisation/return_status.php', '2020-08-02 09:22:55'),
(392, 3, 'admin/language/ru-ru/localisation/stock_status.php', '2020-08-02 09:22:55'),
(393, 3, 'admin/language/ru-ru/localisation/tax_class.php', '2020-08-02 09:22:55'),
(394, 3, 'admin/language/ru-ru/localisation/tax_rate.php', '2020-08-02 09:22:55'),
(395, 3, 'admin/language/ru-ru/localisation/weight_class.php', '2020-08-02 09:22:55'),
(396, 3, 'admin/language/ru-ru/localisation/zone.php', '2020-08-02 09:22:55'),
(397, 3, 'admin/language/ru-ru/mail/affiliate.php', '2020-08-02 09:22:55'),
(398, 3, 'admin/language/ru-ru/mail/customer.php', '2020-08-02 09:22:55'),
(399, 3, 'admin/language/ru-ru/mail/forgotten.php', '2020-08-02 09:22:55'),
(400, 3, 'admin/language/ru-ru/mail/return.php', '2020-08-02 09:22:55'),
(401, 3, 'admin/language/ru-ru/mail/voucher.php', '2020-08-02 09:22:55'),
(402, 3, 'admin/language/ru-ru/marketing/affiliate.php', '2020-08-02 09:22:55'),
(403, 3, 'admin/language/ru-ru/marketing/contact.php', '2020-08-02 09:22:55'),
(404, 3, 'admin/language/ru-ru/marketing/coupon.php', '2020-08-02 09:22:55'),
(405, 3, 'admin/language/ru-ru/marketing/marketing.php', '2020-08-02 09:22:55'),
(406, 3, 'admin/language/ru-ru/marketplace/api.php', '2020-08-02 09:22:55'),
(407, 3, 'admin/language/ru-ru/marketplace/event.php', '2020-08-02 09:22:55'),
(408, 3, 'admin/language/ru-ru/marketplace/extension.php', '2020-08-02 09:22:55'),
(409, 3, 'admin/language/ru-ru/marketplace/install.php', '2020-08-02 09:22:55'),
(410, 3, 'admin/language/ru-ru/marketplace/installer.php', '2020-08-02 09:22:55'),
(411, 3, 'admin/language/ru-ru/marketplace/marketplace.php', '2020-08-02 09:22:55'),
(412, 3, 'admin/language/ru-ru/marketplace/modification.php', '2020-08-02 09:22:55'),
(413, 3, 'admin/language/ru-ru/marketplace/openbay.php', '2020-08-02 09:22:55'),
(414, 3, 'admin/language/ru-ru/report/online.php', '2020-08-02 09:22:55'),
(415, 3, 'admin/language/ru-ru/report/report.php', '2020-08-02 09:22:55'),
(416, 3, 'admin/language/ru-ru/report/statistics.php', '2020-08-02 09:22:55'),
(417, 3, 'admin/language/ru-ru/sale/order.php', '2020-08-02 09:22:55'),
(418, 3, 'admin/language/ru-ru/sale/recurring.php', '2020-08-02 09:22:55'),
(419, 3, 'admin/language/ru-ru/sale/return.php', '2020-08-02 09:22:55'),
(420, 3, 'admin/language/ru-ru/sale/voucher.php', '2020-08-02 09:22:55'),
(421, 3, 'admin/language/ru-ru/sale/voucher_theme.php', '2020-08-02 09:22:55'),
(422, 3, 'admin/language/ru-ru/setting/setting.php', '2020-08-02 09:22:55'),
(423, 3, 'admin/language/ru-ru/setting/store.php', '2020-08-02 09:22:55'),
(424, 3, 'admin/language/ru-ru/tool/backup.php', '2020-08-02 09:22:55'),
(425, 3, 'admin/language/ru-ru/tool/log.php', '2020-08-02 09:22:55'),
(426, 3, 'admin/language/ru-ru/tool/upload.php', '2020-08-02 09:22:55'),
(427, 3, 'admin/language/ru-ru/user/api.php', '2020-08-02 09:22:55'),
(428, 3, 'admin/language/ru-ru/user/user.php', '2020-08-02 09:22:55'),
(429, 3, 'admin/language/ru-ru/user/user_group.php', '2020-08-02 09:22:55'),
(430, 3, 'catalog/language/ru-ru/account/account.php', '2020-08-02 09:22:55'),
(431, 3, 'catalog/language/ru-ru/account/address.php', '2020-08-02 09:22:55'),
(432, 3, 'catalog/language/ru-ru/account/download.php', '2020-08-02 09:22:55'),
(433, 3, 'catalog/language/ru-ru/account/edit.php', '2020-08-02 09:22:55'),
(434, 3, 'catalog/language/ru-ru/account/forgotten.php', '2020-08-02 09:22:55'),
(435, 3, 'catalog/language/ru-ru/account/login.php', '2020-08-02 09:22:55'),
(436, 3, 'catalog/language/ru-ru/account/logout.php', '2020-08-02 09:22:55'),
(437, 3, 'catalog/language/ru-ru/account/newsletter.php', '2020-08-02 09:22:55'),
(438, 3, 'catalog/language/ru-ru/account/order.php', '2020-08-02 09:22:55'),
(439, 3, 'catalog/language/ru-ru/account/password.php', '2020-08-02 09:22:55'),
(440, 3, 'catalog/language/ru-ru/account/recurring.php', '2020-08-02 09:22:55'),
(441, 3, 'catalog/language/ru-ru/account/register.php', '2020-08-02 09:22:55'),
(442, 3, 'catalog/language/ru-ru/account/reset.php', '2020-08-02 09:22:55'),
(443, 3, 'catalog/language/ru-ru/account/return.php', '2020-08-02 09:22:55'),
(444, 3, 'catalog/language/ru-ru/account/reward.php', '2020-08-02 09:22:55'),
(445, 3, 'catalog/language/ru-ru/account/success.php', '2020-08-02 09:22:55'),
(446, 3, 'catalog/language/ru-ru/account/transaction.php', '2020-08-02 09:22:55'),
(447, 3, 'catalog/language/ru-ru/account/voucher.php', '2020-08-02 09:22:55'),
(448, 3, 'catalog/language/ru-ru/account/wishlist.php', '2020-08-02 09:22:55'),
(449, 3, 'catalog/language/ru-ru/affiliate/account.php', '2020-08-02 09:22:55'),
(450, 3, 'catalog/language/ru-ru/affiliate/edit.php', '2020-08-02 09:22:55'),
(451, 3, 'catalog/language/ru-ru/affiliate/forgotten.php', '2020-08-02 09:22:55'),
(452, 3, 'catalog/language/ru-ru/affiliate/login.php', '2020-08-02 09:22:55'),
(453, 3, 'catalog/language/ru-ru/affiliate/logout.php', '2020-08-02 09:22:55'),
(454, 3, 'catalog/language/ru-ru/affiliate/password.php', '2020-08-02 09:22:55'),
(455, 3, 'catalog/language/ru-ru/affiliate/payment.php', '2020-08-02 09:22:55'),
(456, 3, 'catalog/language/ru-ru/affiliate/register.php', '2020-08-02 09:22:55'),
(457, 3, 'catalog/language/ru-ru/affiliate/success.php', '2020-08-02 09:22:55'),
(458, 3, 'catalog/language/ru-ru/affiliate/tracking.php', '2020-08-02 09:22:55'),
(459, 3, 'catalog/language/ru-ru/affiliate/transaction.php', '2020-08-02 09:22:55'),
(460, 3, 'catalog/language/ru-ru/api/cart.php', '2020-08-02 09:22:55'),
(461, 3, 'catalog/language/ru-ru/api/coupon.php', '2020-08-02 09:22:55'),
(462, 3, 'catalog/language/ru-ru/api/customer.php', '2020-08-02 09:22:55'),
(463, 3, 'catalog/language/ru-ru/api/login.php', '2020-08-02 09:22:55'),
(464, 3, 'catalog/language/ru-ru/api/order.php', '2020-08-02 09:22:55'),
(465, 3, 'catalog/language/ru-ru/api/payment.php', '2020-08-02 09:22:55'),
(466, 3, 'catalog/language/ru-ru/api/reward.php', '2020-08-02 09:22:55'),
(467, 3, 'catalog/language/ru-ru/api/shipping.php', '2020-08-02 09:22:55'),
(468, 3, 'catalog/language/ru-ru/api/voucher.php', '2020-08-02 09:22:55'),
(469, 3, 'catalog/language/ru-ru/checkout/cart.php', '2020-08-02 09:22:55'),
(470, 3, 'catalog/language/ru-ru/checkout/checkout.php', '2020-08-02 09:22:55'),
(471, 3, 'catalog/language/ru-ru/checkout/failure.php', '2020-08-02 09:22:55'),
(472, 3, 'catalog/language/ru-ru/checkout/success.php', '2020-08-02 09:22:55'),
(473, 3, 'catalog/language/ru-ru/common/cart.php', '2020-08-02 09:22:55'),
(474, 3, 'catalog/language/ru-ru/common/currency.php', '2020-08-02 09:22:55'),
(475, 3, 'catalog/language/ru-ru/common/footer.php', '2020-08-02 09:22:55'),
(476, 3, 'catalog/language/ru-ru/common/header.php', '2020-08-02 09:22:55'),
(477, 3, 'catalog/language/ru-ru/common/language.php', '2020-08-02 09:22:55'),
(478, 3, 'catalog/language/ru-ru/common/maintenance.php', '2020-08-02 09:22:55'),
(479, 3, 'catalog/language/ru-ru/common/search.php', '2020-08-02 09:22:55'),
(480, 3, 'catalog/language/ru-ru/error/not_found.php', '2020-08-02 09:22:55'),
(481, 3, 'catalog/language/ru-ru/extension/captcha', '2020-08-02 09:22:55'),
(482, 3, 'catalog/language/ru-ru/extension/module', '2020-08-02 09:22:55'),
(483, 3, 'catalog/language/ru-ru/extension/openbay', '2020-08-02 09:22:55'),
(484, 3, 'catalog/language/ru-ru/extension/payment', '2020-08-02 09:22:55'),
(485, 3, 'catalog/language/ru-ru/extension/recurring', '2020-08-02 09:22:55'),
(486, 3, 'catalog/language/ru-ru/extension/shipping', '2020-08-02 09:22:55'),
(487, 3, 'catalog/language/ru-ru/extension/total', '2020-08-02 09:22:55'),
(488, 3, 'catalog/language/ru-ru/information/contact.php', '2020-08-02 09:22:55'),
(489, 3, 'catalog/language/ru-ru/information/information.php', '2020-08-02 09:22:55'),
(490, 3, 'catalog/language/ru-ru/information/sitemap.php', '2020-08-02 09:22:55'),
(491, 3, 'catalog/language/ru-ru/mail/affiliate.php', '2020-08-02 09:22:55'),
(492, 3, 'catalog/language/ru-ru/mail/customer.php', '2020-08-02 09:22:55'),
(493, 3, 'catalog/language/ru-ru/mail/forgotten.php', '2020-08-02 09:22:55'),
(494, 3, 'catalog/language/ru-ru/mail/order.php', '2020-08-02 09:22:55'),
(495, 3, 'catalog/language/ru-ru/mail/review.php', '2020-08-02 09:22:55'),
(496, 3, 'catalog/language/ru-ru/mail/voucher.php', '2020-08-02 09:22:55'),
(497, 3, 'catalog/language/ru-ru/product/category.php', '2020-08-02 09:22:55'),
(498, 3, 'catalog/language/ru-ru/product/compare.php', '2020-08-02 09:22:55'),
(499, 3, 'catalog/language/ru-ru/product/manufacturer.php', '2020-08-02 09:22:55'),
(500, 3, 'catalog/language/ru-ru/product/product.php', '2020-08-02 09:22:55'),
(501, 3, 'catalog/language/ru-ru/product/search.php', '2020-08-02 09:22:55'),
(502, 3, 'catalog/language/ru-ru/product/special.php', '2020-08-02 09:22:55'),
(503, 3, 'catalog/language/ru-ru/tool/upload.php', '2020-08-02 09:22:55'),
(504, 3, 'admin/language/ru-ru/extension/analytics/google_analytics.php', '2020-08-02 09:22:55'),
(505, 3, 'admin/language/ru-ru/extension/captcha/basic_captcha.php', '2020-08-02 09:22:55'),
(506, 3, 'admin/language/ru-ru/extension/captcha/google_captcha.php', '2020-08-02 09:22:55'),
(507, 3, 'admin/language/ru-ru/extension/dashboard/activity.php', '2020-08-02 09:22:55'),
(508, 3, 'admin/language/ru-ru/extension/dashboard/chart.php', '2020-08-02 09:22:55'),
(509, 3, 'admin/language/ru-ru/extension/dashboard/customer.php', '2020-08-02 09:22:55'),
(510, 3, 'admin/language/ru-ru/extension/dashboard/map.php', '2020-08-02 09:22:55'),
(511, 3, 'admin/language/ru-ru/extension/dashboard/online.php', '2020-08-02 09:22:55'),
(512, 3, 'admin/language/ru-ru/extension/dashboard/order.php', '2020-08-02 09:22:55'),
(513, 3, 'admin/language/ru-ru/extension/dashboard/recent.php', '2020-08-02 09:22:55'),
(514, 3, 'admin/language/ru-ru/extension/dashboard/sale.php', '2020-08-02 09:22:55'),
(515, 3, 'admin/language/ru-ru/extension/extension/analytics.php', '2020-08-02 09:22:55'),
(516, 3, 'admin/language/ru-ru/extension/extension/captcha.php', '2020-08-02 09:22:55'),
(517, 3, 'admin/language/ru-ru/extension/extension/dashboard.php', '2020-08-02 09:22:55'),
(518, 3, 'admin/language/ru-ru/extension/extension/feed.php', '2020-08-02 09:22:55'),
(519, 3, 'admin/language/ru-ru/extension/extension/fraud.php', '2020-08-02 09:22:55'),
(520, 3, 'admin/language/ru-ru/extension/extension/module.php', '2020-08-02 09:22:55'),
(521, 3, 'admin/language/ru-ru/extension/extension/payment.php', '2020-08-02 09:22:55'),
(522, 3, 'admin/language/ru-ru/extension/extension/shipping.php', '2020-08-02 09:22:55'),
(523, 3, 'admin/language/ru-ru/extension/extension/theme.php', '2020-08-02 09:22:55'),
(524, 3, 'admin/language/ru-ru/extension/extension/total.php', '2020-08-02 09:22:55'),
(525, 3, 'admin/language/ru-ru/extension/feed/google_base.php', '2020-08-02 09:22:55'),
(526, 3, 'admin/language/ru-ru/extension/feed/google_sitemap.php', '2020-08-02 09:22:55'),
(527, 3, 'admin/language/ru-ru/extension/fraud/ip.php', '2020-08-02 09:22:55'),
(528, 3, 'admin/language/ru-ru/extension/module/account.php', '2020-08-02 09:22:55'),
(529, 3, 'admin/language/ru-ru/extension/module/affiliate.php', '2020-08-02 09:22:55'),
(530, 3, 'admin/language/ru-ru/extension/module/banner.php', '2020-08-02 09:22:55'),
(531, 3, 'admin/language/ru-ru/extension/module/bestseller.php', '2020-08-02 09:22:55'),
(532, 3, 'admin/language/ru-ru/extension/module/carousel.php', '2020-08-02 09:22:55'),
(533, 3, 'admin/language/ru-ru/extension/module/category.php', '2020-08-02 09:22:55'),
(534, 3, 'admin/language/ru-ru/extension/module/featured.php', '2020-08-02 09:22:55'),
(535, 3, 'admin/language/ru-ru/extension/module/filter.php', '2020-08-02 09:22:55'),
(536, 3, 'admin/language/ru-ru/extension/module/google_hangouts.php', '2020-08-02 09:22:55'),
(537, 3, 'admin/language/ru-ru/extension/module/html.php', '2020-08-02 09:22:55'),
(538, 3, 'admin/language/ru-ru/extension/module/information.php', '2020-08-02 09:22:55'),
(539, 3, 'admin/language/ru-ru/extension/module/latest.php', '2020-08-02 09:22:55'),
(540, 3, 'admin/language/ru-ru/extension/module/pp_button.php', '2020-08-02 09:22:55'),
(541, 3, 'admin/language/ru-ru/extension/module/slideshow.php', '2020-08-02 09:22:55'),
(542, 3, 'admin/language/ru-ru/extension/module/special.php', '2020-08-02 09:22:55'),
(543, 3, 'admin/language/ru-ru/extension/module/store.php', '2020-08-02 09:22:55'),
(544, 3, 'admin/language/ru-ru/extension/payment/bank_transfer.php', '2020-08-02 09:22:55'),
(545, 3, 'admin/language/ru-ru/extension/payment/cheque.php', '2020-08-02 09:22:55'),
(546, 3, 'admin/language/ru-ru/extension/payment/cod.php', '2020-08-02 09:22:55'),
(547, 3, 'admin/language/ru-ru/extension/payment/free_checkout.php', '2020-08-02 09:22:55'),
(548, 3, 'admin/language/ru-ru/extension/payment/liqpay.php', '2020-08-02 09:22:55'),
(549, 3, 'admin/language/ru-ru/extension/payment/pp_express.php', '2020-08-02 09:22:55'),
(550, 3, 'admin/language/ru-ru/extension/payment/pp_express_order.php', '2020-08-02 09:22:55'),
(551, 3, 'admin/language/ru-ru/extension/payment/pp_express_refund.php', '2020-08-02 09:22:55'),
(552, 3, 'admin/language/ru-ru/extension/payment/pp_express_search.php', '2020-08-02 09:22:55'),
(553, 3, 'admin/language/ru-ru/extension/payment/pp_express_view.php', '2020-08-02 09:22:55'),
(554, 3, 'admin/language/ru-ru/extension/payment/pp_pro.php', '2020-08-02 09:22:55'),
(555, 3, 'admin/language/ru-ru/extension/payment/pp_standard.php', '2020-08-02 09:22:55'),
(556, 3, 'admin/language/ru-ru/extension/shipping/citylink.php', '2020-08-02 09:22:55'),
(557, 3, 'admin/language/ru-ru/extension/shipping/flat.php', '2020-08-02 09:22:55'),
(558, 3, 'admin/language/ru-ru/extension/shipping/free.php', '2020-08-02 09:22:55'),
(559, 3, 'admin/language/ru-ru/extension/shipping/item.php', '2020-08-02 09:22:55'),
(560, 3, 'admin/language/ru-ru/extension/shipping/pickup.php', '2020-08-02 09:22:55'),
(561, 3, 'admin/language/ru-ru/extension/shipping/weight.php', '2020-08-02 09:22:55'),
(562, 3, 'admin/language/ru-ru/extension/theme/theme_default.php', '2020-08-02 09:22:55'),
(563, 3, 'admin/language/ru-ru/extension/total/coupon.php', '2020-08-02 09:22:55'),
(564, 3, 'admin/language/ru-ru/extension/total/credit.php', '2020-08-02 09:22:55'),
(565, 3, 'admin/language/ru-ru/extension/total/handling.php', '2020-08-02 09:22:55'),
(566, 3, 'admin/language/ru-ru/extension/total/low_order_fee.php', '2020-08-02 09:22:55'),
(567, 3, 'admin/language/ru-ru/extension/total/reward.php', '2020-08-02 09:22:55'),
(568, 3, 'admin/language/ru-ru/extension/total/shipping.php', '2020-08-02 09:22:55'),
(569, 3, 'admin/language/ru-ru/extension/total/sub_total.php', '2020-08-02 09:22:55'),
(570, 3, 'admin/language/ru-ru/extension/total/tax.php', '2020-08-02 09:22:55'),
(571, 3, 'admin/language/ru-ru/extension/total/total.php', '2020-08-02 09:22:55'),
(572, 3, 'admin/language/ru-ru/extension/total/voucher.php', '2020-08-02 09:22:55'),
(573, 3, 'catalog/language/ru-ru/extension/captcha/basic_captcha.php', '2020-08-02 09:22:55'),
(574, 3, 'catalog/language/ru-ru/extension/captcha/google_captcha.php', '2020-08-02 09:22:55'),
(575, 3, 'catalog/language/ru-ru/extension/module/account.php', '2020-08-02 09:22:55'),
(576, 3, 'catalog/language/ru-ru/extension/module/affiliate.php', '2020-08-02 09:22:55'),
(577, 3, 'catalog/language/ru-ru/extension/module/bestseller.php', '2020-08-02 09:22:55'),
(578, 3, 'catalog/language/ru-ru/extension/module/category.php', '2020-08-02 09:22:55'),
(579, 3, 'catalog/language/ru-ru/extension/module/featured.php', '2020-08-02 09:22:55'),
(580, 3, 'catalog/language/ru-ru/extension/module/filter.php', '2020-08-02 09:22:55'),
(581, 3, 'catalog/language/ru-ru/extension/module/google_hangouts.php', '2020-08-02 09:22:55'),
(582, 3, 'catalog/language/ru-ru/extension/module/information.php', '2020-08-02 09:22:55'),
(583, 3, 'catalog/language/ru-ru/extension/module/latest.php', '2020-08-02 09:22:55'),
(584, 3, 'catalog/language/ru-ru/extension/module/special.php', '2020-08-02 09:22:55'),
(585, 3, 'catalog/language/ru-ru/extension/module/store.php', '2020-08-02 09:22:55'),
(586, 3, 'catalog/language/ru-ru/extension/payment/bank_transfer.php', '2020-08-02 09:22:55'),
(587, 3, 'catalog/language/ru-ru/extension/payment/cheque.php', '2020-08-02 09:22:55'),
(588, 3, 'catalog/language/ru-ru/extension/payment/cod.php', '2020-08-02 09:22:55'),
(589, 3, 'catalog/language/ru-ru/extension/payment/free_checkout.php', '2020-08-02 09:22:55'),
(590, 3, 'catalog/language/ru-ru/extension/payment/liqpay.php', '2020-08-02 09:22:55'),
(591, 3, 'catalog/language/ru-ru/extension/payment/moneybookers.php', '2020-08-02 09:22:55'),
(592, 3, 'catalog/language/ru-ru/extension/payment/pp_express.php', '2020-08-02 09:22:55'),
(593, 3, 'catalog/language/ru-ru/extension/payment/pp_pro.php', '2020-08-02 09:22:55'),
(594, 3, 'catalog/language/ru-ru/extension/payment/pp_standard.php', '2020-08-02 09:22:55'),
(595, 3, 'catalog/language/ru-ru/extension/recurring/pp_express.php', '2020-08-02 09:22:55'),
(596, 3, 'catalog/language/ru-ru/extension/shipping/citylink.php', '2020-08-02 09:22:55'),
(597, 3, 'catalog/language/ru-ru/extension/shipping/flat.php', '2020-08-02 09:22:55'),
(598, 3, 'catalog/language/ru-ru/extension/shipping/free.php', '2020-08-02 09:22:55'),
(599, 3, 'catalog/language/ru-ru/extension/shipping/item.php', '2020-08-02 09:22:55'),
(600, 3, 'catalog/language/ru-ru/extension/shipping/pickup.php', '2020-08-02 09:22:55'),
(601, 3, 'catalog/language/ru-ru/extension/shipping/weight.php', '2020-08-02 09:22:55'),
(602, 3, 'catalog/language/ru-ru/extension/total/coupon.php', '2020-08-02 09:22:55'),
(603, 3, 'catalog/language/ru-ru/extension/total/credit.php', '2020-08-02 09:22:55'),
(604, 3, 'catalog/language/ru-ru/extension/total/handling.php', '2020-08-02 09:22:55'),
(605, 3, 'catalog/language/ru-ru/extension/total/low_order_fee.php', '2020-08-02 09:22:55'),
(606, 3, 'catalog/language/ru-ru/extension/total/reward.php', '2020-08-02 09:22:55'),
(607, 3, 'catalog/language/ru-ru/extension/total/shipping.php', '2020-08-02 09:22:55'),
(608, 3, 'catalog/language/ru-ru/extension/total/sub_total.php', '2020-08-02 09:22:55'),
(609, 3, 'catalog/language/ru-ru/extension/total/total.php', '2020-08-02 09:22:55'),
(610, 3, 'catalog/language/ru-ru/extension/total/voucher.php', '2020-08-02 09:22:55'),
(611, 5, 'admin/language/en', '2020-08-02 13:48:51'),
(612, 5, 'admin/language/en-us', '2020-08-02 13:48:51'),
(613, 5, 'admin/language/english', '2020-08-02 13:48:51'),
(614, 5, 'admin/language/ru', '2020-08-02 13:48:51'),
(615, 5, 'admin/language/russian', '2020-08-02 13:48:51'),
(616, 5, 'catalog/language/en', '2020-08-02 13:48:51'),
(617, 5, 'catalog/language/en-us', '2020-08-02 13:48:51'),
(618, 5, 'catalog/language/english', '2020-08-02 13:48:51'),
(619, 5, 'catalog/language/ru', '2020-08-02 13:48:51'),
(620, 5, 'catalog/language/russian', '2020-08-02 13:48:51'),
(621, 5, 'system/config/ocfilter.php', '2020-08-02 13:48:51'),
(622, 5, 'system/library/ocfilter.php', '2020-08-02 13:48:51'),
(623, 5, 'admin/language/en/extension', '2020-08-02 13:48:51'),
(624, 5, 'admin/language/en-us/extension', '2020-08-02 13:48:51'),
(625, 5, 'admin/language/english/extension', '2020-08-02 13:48:51'),
(626, 5, 'admin/language/ru/extension', '2020-08-02 13:48:51'),
(627, 5, 'admin/language/russian/extension', '2020-08-02 13:48:51'),
(628, 5, 'admin/model/extension/ocfilter.php', '2020-08-02 13:48:51'),
(629, 5, 'admin/model/extension/ocfilter_page.php', '2020-08-02 13:48:51'),
(630, 5, 'admin/view/image/ocfilter', '2020-08-02 13:48:51'),
(631, 5, 'admin/view/javascript/ocfilter', '2020-08-02 13:48:51'),
(632, 5, 'admin/view/stylesheet/ocfilter', '2020-08-02 13:48:51'),
(633, 5, 'catalog/language/en/extension', '2020-08-02 13:48:51'),
(634, 5, 'catalog/language/en-us/extension', '2020-08-02 13:48:51'),
(635, 5, 'catalog/language/english/extension', '2020-08-02 13:48:51'),
(636, 5, 'catalog/language/ru/extension', '2020-08-02 13:48:51'),
(637, 5, 'catalog/language/russian/extension', '2020-08-02 13:48:51'),
(638, 5, 'catalog/view/javascript/ocfilter', '2020-08-02 13:48:51'),
(639, 5, 'admin/controller/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(640, 5, 'admin/language/en/extension/module', '2020-08-02 13:48:51'),
(641, 5, 'admin/language/en-us/extension/module', '2020-08-02 13:48:51'),
(642, 5, 'admin/language/english/extension/module', '2020-08-02 13:48:51'),
(643, 5, 'admin/language/ru/extension/module', '2020-08-02 13:48:51'),
(644, 5, 'admin/language/russian/extension/module', '2020-08-02 13:48:51'),
(645, 5, 'admin/view/image/ocfilter/delete-value.png', '2020-08-02 13:48:51'),
(646, 5, 'admin/view/image/ocfilter/select-text.png', '2020-08-02 13:48:51'),
(647, 5, 'admin/view/image/ocfilter/sort-handler.png', '2020-08-02 13:48:51'),
(648, 5, 'admin/view/javascript/ocfilter/ocfilter.js', '2020-08-02 13:48:51'),
(649, 5, 'admin/view/stylesheet/ocfilter/ocfilter.css', '2020-08-02 13:48:51'),
(650, 5, 'catalog/controller/extension/feed/ocfilter_sitemap.php', '2020-08-02 13:48:51'),
(651, 5, 'catalog/controller/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(652, 5, 'catalog/language/en/extension/module', '2020-08-02 13:48:51'),
(653, 5, 'catalog/language/en-us/extension/module', '2020-08-02 13:48:51'),
(654, 5, 'catalog/language/english/extension/module', '2020-08-02 13:48:51'),
(655, 5, 'catalog/language/ru/extension/module', '2020-08-02 13:48:51'),
(656, 5, 'catalog/language/russian/extension/module', '2020-08-02 13:48:51'),
(657, 5, 'catalog/model/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(658, 5, 'catalog/view/javascript/ocfilter/nouislider.min.css', '2020-08-02 13:48:51'),
(659, 5, 'catalog/view/javascript/ocfilter/nouislider.min.js', '2020-08-02 13:48:51'),
(660, 5, 'catalog/view/javascript/ocfilter/ocfilter.js', '2020-08-02 13:48:51'),
(661, 5, 'admin/language/en/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(662, 5, 'admin/language/en-gb/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(663, 5, 'admin/language/en-us/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(664, 5, 'admin/language/english/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(665, 5, 'admin/language/ru/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(666, 5, 'admin/language/ru-ru/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(667, 5, 'admin/language/russian/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(668, 5, 'admin/view/template/extension/module/ocfilter.twig', '2020-08-02 13:48:51'),
(669, 5, 'admin/view/template/extension/module/ocfilter_form.twig', '2020-08-02 13:48:51'),
(670, 5, 'admin/view/template/extension/module/ocfilter_list.twig', '2020-08-02 13:48:51'),
(671, 5, 'admin/view/template/extension/module/ocfilter_page_form.twig', '2020-08-02 13:48:51'),
(672, 5, 'admin/view/template/extension/module/ocfilter_page_list.twig', '2020-08-02 13:48:51'),
(673, 5, 'catalog/language/en/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(674, 5, 'catalog/language/en-gb/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(675, 5, 'catalog/language/en-us/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(676, 5, 'catalog/language/english/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(677, 5, 'catalog/language/ru/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(678, 5, 'catalog/language/ru-ru/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(679, 5, 'catalog/language/russian/extension/module/ocfilter.php', '2020-08-02 13:48:51'),
(680, 5, 'catalog/view/theme/default/image/ocfilter', '2020-08-02 13:48:51'),
(681, 5, 'catalog/view/theme/default/stylesheet/ocfilter', '2020-08-02 13:48:51'),
(682, 5, 'catalog/view/theme/default/image/ocfilter/diagram-bg-repeat.png', '2020-08-02 13:48:51'),
(683, 5, 'catalog/view/theme/default/stylesheet/ocfilter/ocfilter.css', '2020-08-02 13:48:51'),
(684, 5, 'catalog/view/theme/default/template/extension/module/ocfilter', '2020-08-02 13:48:51'),
(685, 5, 'catalog/view/theme/default/template/extension/module/ocfilter/filter_item.twig', '2020-08-02 13:48:51'),
(686, 5, 'catalog/view/theme/default/template/extension/module/ocfilter/filter_list.twig', '2020-08-02 13:48:51'),
(687, 5, 'catalog/view/theme/default/template/extension/module/ocfilter/filter_price.twig', '2020-08-02 13:48:51'),
(688, 5, 'catalog/view/theme/default/template/extension/module/ocfilter/filter_slider_item.twig', '2020-08-02 13:48:51'),
(689, 5, 'catalog/view/theme/default/template/extension/module/ocfilter/module.twig', '2020-08-02 13:48:51'),
(690, 5, 'catalog/view/theme/default/template/extension/module/ocfilter/selected_filter.twig', '2020-08-02 13:48:51'),
(691, 5, 'catalog/view/theme/default/template/extension/module/ocfilter/value_item.twig', '2020-08-02 13:48:51'),
(692, 5, 'catalog/view/theme/default/template/extension/module/ocfilter/value_list.twig', '2020-08-02 13:48:51'),
(693, 6, 'admin/language/uk-ua', '2020-08-02 14:43:19'),
(694, 6, 'catalog/language/uk-ua', '2020-08-02 14:43:19'),
(695, 6, 'admin/language/uk-ua/extension', '2020-08-02 14:43:19'),
(696, 6, 'admin/model/extension/module', '2020-08-02 14:43:19'),
(697, 6, 'admin/view/javascript/quickcheckout', '2020-08-02 14:43:19'),
(698, 6, 'admin/view/stylesheet/quickcheckout.css', '2020-08-02 14:43:19'),
(699, 6, 'catalog/controller/extension/quickcheckout', '2020-08-02 14:43:19'),
(700, 6, 'catalog/language/uk-ua/extension', '2020-08-02 14:43:19'),
(701, 6, 'admin/controller/extension/module/quickcheckout.php', '2020-08-02 14:43:19'),
(702, 6, 'admin/language/uk-ua/extension/module', '2020-08-02 14:43:19'),
(703, 6, 'admin/model/extension/module/quickcheckout.php', '2020-08-02 14:43:19'),
(704, 6, 'admin/view/javascript/quickcheckout/bootstrap-slider', '2020-08-02 14:43:19'),
(705, 6, 'admin/view/javascript/quickcheckout/bootstrap-sortable.js', '2020-08-02 14:43:19'),
(706, 6, 'admin/view/javascript/quickcheckout/tinysort', '2020-08-02 14:43:19'),
(707, 6, 'catalog/controller/extension/quickcheckout/cart.php', '2020-08-02 14:43:19'),
(708, 6, 'catalog/controller/extension/quickcheckout/checkout.php', '2020-08-02 14:43:19'),
(709, 6, 'catalog/controller/extension/quickcheckout/confirm.php', '2020-08-02 14:43:19'),
(710, 6, 'catalog/controller/extension/quickcheckout/guest.php', '2020-08-02 14:43:19'),
(711, 6, 'catalog/controller/extension/quickcheckout/guest_shipping.php', '2020-08-02 14:43:19'),
(712, 6, 'catalog/controller/extension/quickcheckout/login.php', '2020-08-02 14:43:19'),
(713, 6, 'catalog/controller/extension/quickcheckout/payment_address.php', '2020-08-02 14:43:19'),
(714, 6, 'catalog/controller/extension/quickcheckout/payment_method.php', '2020-08-02 14:43:19'),
(715, 6, 'catalog/controller/extension/quickcheckout/register.php', '2020-08-02 14:43:19'),
(716, 6, 'catalog/controller/extension/quickcheckout/shipping_address.php', '2020-08-02 14:43:19'),
(717, 6, 'catalog/controller/extension/quickcheckout/shipping_method.php', '2020-08-02 14:43:19'),
(718, 6, 'catalog/controller/extension/quickcheckout/terms.php', '2020-08-02 14:43:19'),
(719, 6, 'catalog/controller/extension/quickcheckout/voucher.php', '2020-08-02 14:43:19'),
(720, 6, 'catalog/language/en-gb/extension/quickcheckout', '2020-08-02 14:43:19'),
(721, 6, 'catalog/language/ru-ru/extension/quickcheckout', '2020-08-02 14:43:19'),
(722, 6, 'catalog/language/uk-ua/extension/quickcheckout', '2020-08-02 14:43:19'),
(723, 6, 'catalog/view/javascript/jquery/quickcheckout', '2020-08-02 14:43:19'),
(724, 6, 'admin/language/en-gb/extension/module/quickcheckout.php', '2020-08-02 14:43:19'),
(725, 6, 'admin/language/ru-ru/extension/module/quickcheckout.php', '2020-08-02 14:43:19'),
(726, 6, 'admin/language/uk-ua/extension/module/quickcheckout.php', '2020-08-02 14:43:19'),
(727, 6, 'admin/view/javascript/quickcheckout/bootstrap-slider/css', '2020-08-02 14:43:19'),
(728, 6, 'admin/view/javascript/quickcheckout/bootstrap-slider/js', '2020-08-02 14:43:19'),
(729, 6, 'admin/view/javascript/quickcheckout/tinysort/jquery.tinysort.min.js', '2020-08-02 14:43:19'),
(730, 6, 'admin/view/template/extension/module/quickcheckout.twig', '2020-08-02 14:43:19'),
(731, 6, 'catalog/language/en-gb/extension/quickcheckout/checkout.php', '2020-08-02 14:43:19'),
(732, 6, 'catalog/language/ru-ru/extension/quickcheckout/checkout.php', '2020-08-02 14:43:19'),
(733, 6, 'catalog/language/uk-ua/extension/quickcheckout/checkout.php', '2020-08-02 14:43:19'),
(734, 6, 'catalog/view/javascript/jquery/quickcheckout/bootstrap-datetimepicker.min.css', '2020-08-02 14:43:19'),
(735, 6, 'catalog/view/javascript/jquery/quickcheckout/bootstrap-datetimepicker.min.js', '2020-08-02 14:43:19'),
(736, 6, 'catalog/view/javascript/jquery/quickcheckout/jquery.tinysort.min.js', '2020-08-02 14:43:19'),
(737, 6, 'catalog/view/javascript/jquery/quickcheckout/moment-with-locales.min.js', '2020-08-02 14:43:19'),
(738, 6, 'catalog/view/javascript/jquery/quickcheckout/quickcheckout.block.js', '2020-08-02 14:43:19'),
(739, 6, 'catalog/view/javascript/jquery/quickcheckout/quickcheckout.js', '2020-08-02 14:43:19'),
(740, 6, 'catalog/view/theme/default/stylesheet/quickcheckout.css', '2020-08-02 14:43:19'),
(741, 6, 'catalog/view/theme/default/stylesheet/quickcheckout_custom.css', '2020-08-02 14:43:19'),
(742, 6, 'catalog/view/theme/default/stylesheet/quickcheckout_mobile.css', '2020-08-02 14:43:19'),
(743, 6, 'catalog/view/theme/default/stylesheet/quickcheckout_one.css', '2020-08-02 14:43:19'),
(744, 6, 'catalog/view/theme/default/stylesheet/quickcheckout_three.css', '2020-08-02 14:43:19'),
(745, 6, 'catalog/view/theme/default/stylesheet/quickcheckout_two.css', '2020-08-02 14:43:19'),
(746, 6, 'admin/view/javascript/quickcheckout/bootstrap-slider/css/slider.css', '2020-08-02 14:43:19'),
(747, 6, 'admin/view/javascript/quickcheckout/bootstrap-slider/js/bootstrap-slider.js', '2020-08-02 14:43:19'),
(748, 6, 'catalog/view/theme/default/template/extension/quickcheckout', '2020-08-02 14:43:19'),
(749, 6, 'catalog/view/theme/default/template/extension/quickcheckout/cart.twig', '2020-08-02 14:43:19'),
(750, 6, 'catalog/view/theme/default/template/extension/quickcheckout/checkout.twig', '2020-08-02 14:43:19'),
(751, 6, 'catalog/view/theme/default/template/extension/quickcheckout/confirm.twig', '2020-08-02 14:43:19'),
(752, 6, 'catalog/view/theme/default/template/extension/quickcheckout/guest.twig', '2020-08-02 14:43:19'),
(753, 6, 'catalog/view/theme/default/template/extension/quickcheckout/guest_shipping.twig', '2020-08-02 14:43:19'),
(754, 6, 'catalog/view/theme/default/template/extension/quickcheckout/login.twig', '2020-08-02 14:43:19'),
(755, 6, 'catalog/view/theme/default/template/extension/quickcheckout/payment_address.twig', '2020-08-02 14:43:19'),
(756, 6, 'catalog/view/theme/default/template/extension/quickcheckout/payment_method.twig', '2020-08-02 14:43:19'),
(757, 6, 'catalog/view/theme/default/template/extension/quickcheckout/register.twig', '2020-08-02 14:43:19'),
(758, 6, 'catalog/view/theme/default/template/extension/quickcheckout/shipping_address.twig', '2020-08-02 14:43:19'),
(759, 6, 'catalog/view/theme/default/template/extension/quickcheckout/shipping_method.twig', '2020-08-02 14:43:19'),
(760, 6, 'catalog/view/theme/default/template/extension/quickcheckout/terms.twig', '2020-08-02 14:43:19'),
(761, 6, 'catalog/view/theme/default/template/extension/quickcheckout/voucher.twig', '2020-08-02 14:43:19'),
(1089, 9, 'image/catalog/payment', '2020-08-02 20:23:56'),
(1090, 9, 'catalog/view/theme/journal3', '2020-08-02 20:23:56'),
(1091, 9, 'image/catalog/payment/yandex_money', '2020-08-02 20:23:56'),
(1092, 9, 'admin/controller/extension/payment/yandex_money.php', '2020-08-02 20:23:56'),
(765, 8, 'system/library/export_import', '2020-08-02 19:56:24'),
(766, 8, 'admin/controller/extension/export_import.php', '2020-08-02 19:56:24'),
(767, 8, 'admin/model/extension/export_import.php', '2020-08-02 19:56:24'),
(768, 8, 'admin/view/image/export-import', '2020-08-02 19:56:24'),
(769, 8, 'admin/view/stylesheet/export_import.css', '2020-08-02 19:56:24'),
(770, 8, 'system/library/export_import/Classes', '2020-08-02 19:56:24'),
(771, 8, 'admin/language/en-gb/extension/export_import.php', '2020-08-02 19:56:24'),
(772, 8, 'admin/language/ru-ru/extension/export_import.php', '2020-08-02 19:56:24'),
(773, 8, 'admin/view/image/export-import/loading.gif', '2020-08-02 19:56:24'),
(774, 8, 'admin/view/template/extension/export_import.twig', '2020-08-02 19:56:24'),
(775, 8, 'system/library/export_import/Classes/PHPExcel', '2020-08-02 19:56:24'),
(776, 8, 'system/library/export_import/Classes/PHPExcel.php', '2020-08-02 19:56:24'),
(777, 8, 'system/library/export_import/Classes/PHPExcel/Autoloader.php', '2020-08-02 19:56:24'),
(778, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage', '2020-08-02 19:56:24'),
(779, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorageFactory.php', '2020-08-02 19:56:24'),
(780, 8, 'system/library/export_import/Classes/PHPExcel/CalcEngine', '2020-08-02 19:56:24'),
(781, 8, 'system/library/export_import/Classes/PHPExcel/Calculation', '2020-08-02 19:56:24'),
(782, 8, 'system/library/export_import/Classes/PHPExcel/Calculation.php', '2020-08-02 19:56:24'),
(783, 8, 'system/library/export_import/Classes/PHPExcel/Cell', '2020-08-02 19:56:24'),
(784, 8, 'system/library/export_import/Classes/PHPExcel/Cell.php', '2020-08-02 19:56:24'),
(785, 8, 'system/library/export_import/Classes/PHPExcel/Chart', '2020-08-02 19:56:24'),
(786, 8, 'system/library/export_import/Classes/PHPExcel/Chart.php', '2020-08-02 19:56:24'),
(787, 8, 'system/library/export_import/Classes/PHPExcel/Comment.php', '2020-08-02 19:56:24'),
(788, 8, 'system/library/export_import/Classes/PHPExcel/DocumentProperties.php', '2020-08-02 19:56:24'),
(789, 8, 'system/library/export_import/Classes/PHPExcel/DocumentSecurity.php', '2020-08-02 19:56:24'),
(790, 8, 'system/library/export_import/Classes/PHPExcel/Exception.php', '2020-08-02 19:56:24'),
(791, 8, 'system/library/export_import/Classes/PHPExcel/HashTable.php', '2020-08-02 19:56:24'),
(792, 8, 'system/library/export_import/Classes/PHPExcel/Helper', '2020-08-02 19:56:24'),
(793, 8, 'system/library/export_import/Classes/PHPExcel/IComparable.php', '2020-08-02 19:56:24'),
(794, 8, 'system/library/export_import/Classes/PHPExcel/IOFactory.php', '2020-08-02 19:56:24'),
(795, 8, 'system/library/export_import/Classes/PHPExcel/NamedRange.php', '2020-08-02 19:56:24'),
(796, 8, 'system/library/export_import/Classes/PHPExcel/Reader', '2020-08-02 19:56:24'),
(797, 8, 'system/library/export_import/Classes/PHPExcel/ReferenceHelper.php', '2020-08-02 19:56:24'),
(798, 8, 'system/library/export_import/Classes/PHPExcel/RichText', '2020-08-02 19:56:24'),
(799, 8, 'system/library/export_import/Classes/PHPExcel/RichText.php', '2020-08-02 19:56:24'),
(800, 8, 'system/library/export_import/Classes/PHPExcel/Settings.php', '2020-08-02 19:56:24'),
(801, 8, 'system/library/export_import/Classes/PHPExcel/Shared', '2020-08-02 19:56:24'),
(802, 8, 'system/library/export_import/Classes/PHPExcel/Style', '2020-08-02 19:56:24'),
(803, 8, 'system/library/export_import/Classes/PHPExcel/Style.php', '2020-08-02 19:56:24'),
(804, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet', '2020-08-02 19:56:24'),
(805, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet.php', '2020-08-02 19:56:24'),
(806, 8, 'system/library/export_import/Classes/PHPExcel/WorksheetIterator.php', '2020-08-02 19:56:24'),
(807, 8, 'system/library/export_import/Classes/PHPExcel/Writer', '2020-08-02 19:56:24'),
(808, 8, 'system/library/export_import/Classes/PHPExcel/locale', '2020-08-02 19:56:24'),
(809, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/APC.php', '2020-08-02 19:56:24'),
(810, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/CacheBase.php', '2020-08-02 19:56:24'),
(811, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/DiscISAM.php', '2020-08-02 19:56:24'),
(812, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/ICache.php', '2020-08-02 19:56:24'),
(813, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/Igbinary.php', '2020-08-02 19:56:24'),
(814, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/Memcache.php', '2020-08-02 19:56:24'),
(815, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/Memory.php', '2020-08-02 19:56:24'),
(816, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/MemoryGZip.php', '2020-08-02 19:56:24'),
(817, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/MemorySerialized.php', '2020-08-02 19:56:24'),
(818, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/PHPTemp.php', '2020-08-02 19:56:24'),
(819, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/SQLite.php', '2020-08-02 19:56:24'),
(820, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/SQLite3.php', '2020-08-02 19:56:24'),
(821, 8, 'system/library/export_import/Classes/PHPExcel/CachedObjectStorage/Wincache.php', '2020-08-02 19:56:24'),
(822, 8, 'system/library/export_import/Classes/PHPExcel/CalcEngine/CyclicReferenceStack.php', '2020-08-02 19:56:24'),
(823, 8, 'system/library/export_import/Classes/PHPExcel/CalcEngine/Logger.php', '2020-08-02 19:56:24'),
(824, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/Database.php', '2020-08-02 19:56:24'),
(825, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/DateTime.php', '2020-08-02 19:56:24'),
(826, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/Engineering.php', '2020-08-02 19:56:24'),
(827, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/Exception.php', '2020-08-02 19:56:24'),
(828, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/ExceptionHandler.php', '2020-08-02 19:56:24'),
(829, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/Financial.php', '2020-08-02 19:56:24'),
(830, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/FormulaParser.php', '2020-08-02 19:56:24'),
(831, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/FormulaToken.php', '2020-08-02 19:56:24'),
(832, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/Function.php', '2020-08-02 19:56:24'),
(833, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/Functions.php', '2020-08-02 19:56:24'),
(834, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/Logical.php', '2020-08-02 19:56:24'),
(835, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/LookupRef.php', '2020-08-02 19:56:24'),
(836, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/MathTrig.php', '2020-08-02 19:56:24'),
(837, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/Statistical.php', '2020-08-02 19:56:24'),
(838, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/TextData.php', '2020-08-02 19:56:24'),
(839, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/Token', '2020-08-02 19:56:24'),
(840, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/functionlist.txt', '2020-08-02 19:56:24'),
(841, 8, 'system/library/export_import/Classes/PHPExcel/Cell/AdvancedValueBinder.php', '2020-08-02 19:56:24'),
(842, 8, 'system/library/export_import/Classes/PHPExcel/Cell/DataType.php', '2020-08-02 19:56:24'),
(843, 8, 'system/library/export_import/Classes/PHPExcel/Cell/DataValidation.php', '2020-08-02 19:56:24'),
(844, 8, 'system/library/export_import/Classes/PHPExcel/Cell/DefaultValueBinder.php', '2020-08-02 19:56:24'),
(845, 8, 'system/library/export_import/Classes/PHPExcel/Cell/ExportImportValueBinder.php', '2020-08-02 19:56:24'),
(846, 8, 'system/library/export_import/Classes/PHPExcel/Cell/Hyperlink.php', '2020-08-02 19:56:24'),
(847, 8, 'system/library/export_import/Classes/PHPExcel/Cell/IValueBinder.php', '2020-08-02 19:56:24'),
(848, 8, 'system/library/export_import/Classes/PHPExcel/Chart/Axis.php', '2020-08-02 19:56:24'),
(849, 8, 'system/library/export_import/Classes/PHPExcel/Chart/DataSeries.php', '2020-08-02 19:56:24'),
(850, 8, 'system/library/export_import/Classes/PHPExcel/Chart/DataSeriesValues.php', '2020-08-02 19:56:24'),
(851, 8, 'system/library/export_import/Classes/PHPExcel/Chart/Exception.php', '2020-08-02 19:56:24'),
(852, 8, 'system/library/export_import/Classes/PHPExcel/Chart/GridLines.php', '2020-08-02 19:56:24'),
(853, 8, 'system/library/export_import/Classes/PHPExcel/Chart/Layout.php', '2020-08-02 19:56:24'),
(854, 8, 'system/library/export_import/Classes/PHPExcel/Chart/Legend.php', '2020-08-02 19:56:24'),
(855, 8, 'system/library/export_import/Classes/PHPExcel/Chart/PlotArea.php', '2020-08-02 19:56:24'),
(856, 8, 'system/library/export_import/Classes/PHPExcel/Chart/Properties.php', '2020-08-02 19:56:24'),
(857, 8, 'system/library/export_import/Classes/PHPExcel/Chart/Renderer', '2020-08-02 19:56:24'),
(858, 8, 'system/library/export_import/Classes/PHPExcel/Chart/Title.php', '2020-08-02 19:56:24'),
(859, 8, 'system/library/export_import/Classes/PHPExcel/Helper/HTML.php', '2020-08-02 19:56:24'),
(860, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Abstract.php', '2020-08-02 19:56:24'),
(861, 8, 'system/library/export_import/Classes/PHPExcel/Reader/CSV.php', '2020-08-02 19:56:24'),
(862, 8, 'system/library/export_import/Classes/PHPExcel/Reader/DefaultReadFilter.php', '2020-08-02 19:56:24'),
(863, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel2003XML.php', '2020-08-02 19:56:24'),
(864, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel2007', '2020-08-02 19:56:24'),
(865, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel2007.php', '2020-08-02 19:56:24'),
(866, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5', '2020-08-02 19:56:24'),
(867, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5.php', '2020-08-02 19:56:24'),
(868, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Exception.php', '2020-08-02 19:56:24'),
(869, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Gnumeric.php', '2020-08-02 19:56:24'),
(870, 8, 'system/library/export_import/Classes/PHPExcel/Reader/HTML.php', '2020-08-02 19:56:24'),
(871, 8, 'system/library/export_import/Classes/PHPExcel/Reader/IReadFilter.php', '2020-08-02 19:56:24'),
(872, 8, 'system/library/export_import/Classes/PHPExcel/Reader/IReader.php', '2020-08-02 19:56:24'),
(873, 8, 'system/library/export_import/Classes/PHPExcel/Reader/OOCalc.php', '2020-08-02 19:56:24'),
(874, 8, 'system/library/export_import/Classes/PHPExcel/Reader/SYLK.php', '2020-08-02 19:56:24'),
(875, 8, 'system/library/export_import/Classes/PHPExcel/RichText/ITextElement.php', '2020-08-02 19:56:24'),
(876, 8, 'system/library/export_import/Classes/PHPExcel/RichText/Run.php', '2020-08-02 19:56:24'),
(877, 8, 'system/library/export_import/Classes/PHPExcel/RichText/TextElement.php', '2020-08-02 19:56:24'),
(878, 8, 'system/library/export_import/Classes/PHPExcel/Shared/CodePage.php', '2020-08-02 19:56:24'),
(879, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Date.php', '2020-08-02 19:56:24'),
(880, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Drawing.php', '2020-08-02 19:56:24'),
(881, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher', '2020-08-02 19:56:24'),
(882, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher.php', '2020-08-02 19:56:24'),
(883, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Excel5.php', '2020-08-02 19:56:24'),
(884, 8, 'system/library/export_import/Classes/PHPExcel/Shared/File.php', '2020-08-02 19:56:24'),
(885, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Font.php', '2020-08-02 19:56:24'),
(886, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA', '2020-08-02 19:56:24'),
(887, 8, 'system/library/export_import/Classes/PHPExcel/Shared/OLE', '2020-08-02 19:56:24'),
(888, 8, 'system/library/export_import/Classes/PHPExcel/Shared/OLE.php', '2020-08-02 19:56:24'),
(889, 8, 'system/library/export_import/Classes/PHPExcel/Shared/OLERead.php', '2020-08-02 19:56:24'),
(890, 8, 'system/library/export_import/Classes/PHPExcel/Shared/PCLZip', '2020-08-02 19:56:24'),
(891, 8, 'system/library/export_import/Classes/PHPExcel/Shared/PasswordHasher.php', '2020-08-02 19:56:24'),
(892, 8, 'system/library/export_import/Classes/PHPExcel/Shared/String.php', '2020-08-02 19:56:24'),
(893, 8, 'system/library/export_import/Classes/PHPExcel/Shared/TimeZone.php', '2020-08-02 19:56:24'),
(894, 8, 'system/library/export_import/Classes/PHPExcel/Shared/XMLWriter.php', '2020-08-02 19:56:24');
INSERT INTO `oc_extension_path` (`extension_path_id`, `extension_install_id`, `path`, `date_added`) VALUES
(895, 8, 'system/library/export_import/Classes/PHPExcel/Shared/ZipArchive.php', '2020-08-02 19:56:24'),
(896, 8, 'system/library/export_import/Classes/PHPExcel/Shared/ZipStreamWrapper.php', '2020-08-02 19:56:24'),
(897, 8, 'system/library/export_import/Classes/PHPExcel/Shared/trend', '2020-08-02 19:56:24'),
(898, 8, 'system/library/export_import/Classes/PHPExcel/Style/Alignment.php', '2020-08-02 19:56:24'),
(899, 8, 'system/library/export_import/Classes/PHPExcel/Style/Border.php', '2020-08-02 19:56:24'),
(900, 8, 'system/library/export_import/Classes/PHPExcel/Style/Borders.php', '2020-08-02 19:56:24'),
(901, 8, 'system/library/export_import/Classes/PHPExcel/Style/Color.php', '2020-08-02 19:56:24'),
(902, 8, 'system/library/export_import/Classes/PHPExcel/Style/Conditional.php', '2020-08-02 19:56:24'),
(903, 8, 'system/library/export_import/Classes/PHPExcel/Style/Fill.php', '2020-08-02 19:56:24'),
(904, 8, 'system/library/export_import/Classes/PHPExcel/Style/Font.php', '2020-08-02 19:56:24'),
(905, 8, 'system/library/export_import/Classes/PHPExcel/Style/NumberFormat.php', '2020-08-02 19:56:24'),
(906, 8, 'system/library/export_import/Classes/PHPExcel/Style/Protection.php', '2020-08-02 19:56:24'),
(907, 8, 'system/library/export_import/Classes/PHPExcel/Style/Supervisor.php', '2020-08-02 19:56:24'),
(908, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/AutoFilter', '2020-08-02 19:56:24'),
(909, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/AutoFilter.php', '2020-08-02 19:56:24'),
(910, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/BaseDrawing.php', '2020-08-02 19:56:24'),
(911, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/CellIterator.php', '2020-08-02 19:56:24'),
(912, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/Column.php', '2020-08-02 19:56:24'),
(913, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/ColumnCellIterator.php', '2020-08-02 19:56:24'),
(914, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/ColumnDimension.php', '2020-08-02 19:56:24'),
(915, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/ColumnIterator.php', '2020-08-02 19:56:24'),
(916, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/Dimension.php', '2020-08-02 19:56:24'),
(917, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/Drawing', '2020-08-02 19:56:24'),
(918, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/Drawing.php', '2020-08-02 19:56:24'),
(919, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/HeaderFooter.php', '2020-08-02 19:56:24'),
(920, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/HeaderFooterDrawing.php', '2020-08-02 19:56:24'),
(921, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/MemoryDrawing.php', '2020-08-02 19:56:24'),
(922, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/PageMargins.php', '2020-08-02 19:56:24'),
(923, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/PageSetup.php', '2020-08-02 19:56:24'),
(924, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/Protection.php', '2020-08-02 19:56:24'),
(925, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/Row.php', '2020-08-02 19:56:24'),
(926, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/RowCellIterator.php', '2020-08-02 19:56:24'),
(927, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/RowDimension.php', '2020-08-02 19:56:24'),
(928, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/RowIterator.php', '2020-08-02 19:56:24'),
(929, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/SheetView.php', '2020-08-02 19:56:24'),
(930, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Abstract.php', '2020-08-02 19:56:24'),
(931, 8, 'system/library/export_import/Classes/PHPExcel/Writer/CSV.php', '2020-08-02 19:56:24'),
(932, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007', '2020-08-02 19:56:24'),
(933, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007.php', '2020-08-02 19:56:24'),
(934, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel5', '2020-08-02 19:56:24'),
(935, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel5.php', '2020-08-02 19:56:24'),
(936, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Exception.php', '2020-08-02 19:56:24'),
(937, 8, 'system/library/export_import/Classes/PHPExcel/Writer/HTML.php', '2020-08-02 19:56:24'),
(938, 8, 'system/library/export_import/Classes/PHPExcel/Writer/IWriter.php', '2020-08-02 19:56:24'),
(939, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument', '2020-08-02 19:56:24'),
(940, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument.php', '2020-08-02 19:56:24'),
(941, 8, 'system/library/export_import/Classes/PHPExcel/Writer/PDF', '2020-08-02 19:56:24'),
(942, 8, 'system/library/export_import/Classes/PHPExcel/Writer/PDF.php', '2020-08-02 19:56:24'),
(943, 8, 'system/library/export_import/Classes/PHPExcel/locale/bg', '2020-08-02 19:56:24'),
(944, 8, 'system/library/export_import/Classes/PHPExcel/locale/cs', '2020-08-02 19:56:24'),
(945, 8, 'system/library/export_import/Classes/PHPExcel/locale/da', '2020-08-02 19:56:24'),
(946, 8, 'system/library/export_import/Classes/PHPExcel/locale/de', '2020-08-02 19:56:24'),
(947, 8, 'system/library/export_import/Classes/PHPExcel/locale/en', '2020-08-02 19:56:24'),
(948, 8, 'system/library/export_import/Classes/PHPExcel/locale/es', '2020-08-02 19:56:24'),
(949, 8, 'system/library/export_import/Classes/PHPExcel/locale/fi', '2020-08-02 19:56:24'),
(950, 8, 'system/library/export_import/Classes/PHPExcel/locale/fr', '2020-08-02 19:56:24'),
(951, 8, 'system/library/export_import/Classes/PHPExcel/locale/hu', '2020-08-02 19:56:24'),
(952, 8, 'system/library/export_import/Classes/PHPExcel/locale/it', '2020-08-02 19:56:24'),
(953, 8, 'system/library/export_import/Classes/PHPExcel/locale/nl', '2020-08-02 19:56:24'),
(954, 8, 'system/library/export_import/Classes/PHPExcel/locale/no', '2020-08-02 19:56:24'),
(955, 8, 'system/library/export_import/Classes/PHPExcel/locale/pl', '2020-08-02 19:56:24'),
(956, 8, 'system/library/export_import/Classes/PHPExcel/locale/pt', '2020-08-02 19:56:24'),
(957, 8, 'system/library/export_import/Classes/PHPExcel/locale/ru', '2020-08-02 19:56:24'),
(958, 8, 'system/library/export_import/Classes/PHPExcel/locale/sv', '2020-08-02 19:56:24'),
(959, 8, 'system/library/export_import/Classes/PHPExcel/locale/tr', '2020-08-02 19:56:24'),
(960, 8, 'system/library/export_import/Classes/PHPExcel/Calculation/Token/Stack.php', '2020-08-02 19:56:24'),
(961, 8, 'system/library/export_import/Classes/PHPExcel/Chart/Renderer/PHP Charting Libraries.txt', '2020-08-02 19:56:24'),
(962, 8, 'system/library/export_import/Classes/PHPExcel/Chart/Renderer/jpgraph.php', '2020-08-02 19:56:24'),
(963, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel2007/Chart.php', '2020-08-02 19:56:24'),
(964, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel2007/Theme.php', '2020-08-02 19:56:24'),
(965, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/Color', '2020-08-02 19:56:24'),
(966, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/Color.php', '2020-08-02 19:56:24'),
(967, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/ErrorCode.php', '2020-08-02 19:56:24'),
(968, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/Escher.php', '2020-08-02 19:56:24'),
(969, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/MD5.php', '2020-08-02 19:56:24'),
(970, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/RC4.php', '2020-08-02 19:56:24'),
(971, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/Style', '2020-08-02 19:56:24'),
(972, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DgContainer', '2020-08-02 19:56:24'),
(973, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DgContainer.php', '2020-08-02 19:56:24'),
(974, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DggContainer', '2020-08-02 19:56:24'),
(975, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DggContainer.php', '2020-08-02 19:56:24'),
(976, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA/CHANGELOG.TXT', '2020-08-02 19:56:24'),
(977, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA/CholeskyDecomposition.php', '2020-08-02 19:56:24'),
(978, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA/EigenvalueDecomposition.php', '2020-08-02 19:56:24'),
(979, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA/LUDecomposition.php', '2020-08-02 19:56:24'),
(980, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA/Matrix.php', '2020-08-02 19:56:24'),
(981, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA/QRDecomposition.php', '2020-08-02 19:56:24'),
(982, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA/SingularValueDecomposition.php', '2020-08-02 19:56:24'),
(983, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA/utils', '2020-08-02 19:56:24'),
(984, 8, 'system/library/export_import/Classes/PHPExcel/Shared/OLE/ChainedBlockStream.php', '2020-08-02 19:56:24'),
(985, 8, 'system/library/export_import/Classes/PHPExcel/Shared/OLE/PPS', '2020-08-02 19:56:24'),
(986, 8, 'system/library/export_import/Classes/PHPExcel/Shared/OLE/PPS.php', '2020-08-02 19:56:24'),
(987, 8, 'system/library/export_import/Classes/PHPExcel/Shared/PCLZip/gnu-lgpl.txt', '2020-08-02 19:56:24'),
(988, 8, 'system/library/export_import/Classes/PHPExcel/Shared/PCLZip/pclzip.lib.php', '2020-08-02 19:56:24'),
(989, 8, 'system/library/export_import/Classes/PHPExcel/Shared/PCLZip/readme.txt', '2020-08-02 19:56:24'),
(990, 8, 'system/library/export_import/Classes/PHPExcel/Shared/trend/bestFitClass.php', '2020-08-02 19:56:24'),
(991, 8, 'system/library/export_import/Classes/PHPExcel/Shared/trend/exponentialBestFitClass.php', '2020-08-02 19:56:24'),
(992, 8, 'system/library/export_import/Classes/PHPExcel/Shared/trend/linearBestFitClass.php', '2020-08-02 19:56:24'),
(993, 8, 'system/library/export_import/Classes/PHPExcel/Shared/trend/logarithmicBestFitClass.php', '2020-08-02 19:56:24'),
(994, 8, 'system/library/export_import/Classes/PHPExcel/Shared/trend/polynomialBestFitClass.php', '2020-08-02 19:56:24'),
(995, 8, 'system/library/export_import/Classes/PHPExcel/Shared/trend/powerBestFitClass.php', '2020-08-02 19:56:24'),
(996, 8, 'system/library/export_import/Classes/PHPExcel/Shared/trend/trendClass.php', '2020-08-02 19:56:24'),
(997, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/AutoFilter/Column', '2020-08-02 19:56:24'),
(998, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/AutoFilter/Column.php', '2020-08-02 19:56:24'),
(999, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/Drawing/Shadow.php', '2020-08-02 19:56:24'),
(1000, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/Chart.php', '2020-08-02 19:56:24'),
(1001, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/Comments.php', '2020-08-02 19:56:24'),
(1002, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/ContentTypes.php', '2020-08-02 19:56:24'),
(1003, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/DocProps.php', '2020-08-02 19:56:24'),
(1004, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/Drawing.php', '2020-08-02 19:56:24'),
(1005, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/Rels.php', '2020-08-02 19:56:24'),
(1006, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/RelsRibbon.php', '2020-08-02 19:56:24'),
(1007, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/RelsVBA.php', '2020-08-02 19:56:24'),
(1008, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/StringTable.php', '2020-08-02 19:56:24'),
(1009, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/Style.php', '2020-08-02 19:56:24'),
(1010, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/Theme.php', '2020-08-02 19:56:24'),
(1011, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/Workbook.php', '2020-08-02 19:56:24'),
(1012, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/Worksheet.php', '2020-08-02 19:56:24'),
(1013, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel2007/WriterPart.php', '2020-08-02 19:56:24'),
(1014, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel5/BIFFwriter.php', '2020-08-02 19:56:24'),
(1015, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel5/Escher.php', '2020-08-02 19:56:24'),
(1016, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel5/Font.php', '2020-08-02 19:56:24'),
(1017, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel5/Parser.php', '2020-08-02 19:56:24'),
(1018, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel5/Workbook.php', '2020-08-02 19:56:24'),
(1019, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel5/Worksheet.php', '2020-08-02 19:56:24'),
(1020, 8, 'system/library/export_import/Classes/PHPExcel/Writer/Excel5/Xf.php', '2020-08-02 19:56:24'),
(1021, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument/Cell', '2020-08-02 19:56:24'),
(1022, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument/Content.php', '2020-08-02 19:56:24'),
(1023, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument/Meta.php', '2020-08-02 19:56:24'),
(1024, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument/MetaInf.php', '2020-08-02 19:56:24'),
(1025, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument/Mimetype.php', '2020-08-02 19:56:24'),
(1026, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument/Settings.php', '2020-08-02 19:56:24'),
(1027, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument/Styles.php', '2020-08-02 19:56:24'),
(1028, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument/Thumbnails.php', '2020-08-02 19:56:24'),
(1029, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument/WriterPart.php', '2020-08-02 19:56:24'),
(1030, 8, 'system/library/export_import/Classes/PHPExcel/Writer/PDF/Core.php', '2020-08-02 19:56:24'),
(1031, 8, 'system/library/export_import/Classes/PHPExcel/Writer/PDF/DomPDF.php', '2020-08-02 19:56:24'),
(1032, 8, 'system/library/export_import/Classes/PHPExcel/Writer/PDF/mPDF.php', '2020-08-02 19:56:24'),
(1033, 8, 'system/library/export_import/Classes/PHPExcel/Writer/PDF/tcPDF.php', '2020-08-02 19:56:24'),
(1034, 8, 'system/library/export_import/Classes/PHPExcel/locale/bg/config', '2020-08-02 19:56:24'),
(1035, 8, 'system/library/export_import/Classes/PHPExcel/locale/cs/config', '2020-08-02 19:56:24'),
(1036, 8, 'system/library/export_import/Classes/PHPExcel/locale/cs/functions', '2020-08-02 19:56:24'),
(1037, 8, 'system/library/export_import/Classes/PHPExcel/locale/da/config', '2020-08-02 19:56:24'),
(1038, 8, 'system/library/export_import/Classes/PHPExcel/locale/da/functions', '2020-08-02 19:56:24'),
(1039, 8, 'system/library/export_import/Classes/PHPExcel/locale/de/config', '2020-08-02 19:56:24'),
(1040, 8, 'system/library/export_import/Classes/PHPExcel/locale/de/functions', '2020-08-02 19:56:24'),
(1041, 8, 'system/library/export_import/Classes/PHPExcel/locale/en/uk', '2020-08-02 19:56:24'),
(1042, 8, 'system/library/export_import/Classes/PHPExcel/locale/es/config', '2020-08-02 19:56:24'),
(1043, 8, 'system/library/export_import/Classes/PHPExcel/locale/es/functions', '2020-08-02 19:56:24'),
(1044, 8, 'system/library/export_import/Classes/PHPExcel/locale/fi/config', '2020-08-02 19:56:24'),
(1045, 8, 'system/library/export_import/Classes/PHPExcel/locale/fi/functions', '2020-08-02 19:56:24'),
(1046, 8, 'system/library/export_import/Classes/PHPExcel/locale/fr/config', '2020-08-02 19:56:24'),
(1047, 8, 'system/library/export_import/Classes/PHPExcel/locale/fr/functions', '2020-08-02 19:56:24'),
(1048, 8, 'system/library/export_import/Classes/PHPExcel/locale/hu/config', '2020-08-02 19:56:24'),
(1049, 8, 'system/library/export_import/Classes/PHPExcel/locale/hu/functions', '2020-08-02 19:56:24'),
(1050, 8, 'system/library/export_import/Classes/PHPExcel/locale/it/config', '2020-08-02 19:56:24'),
(1051, 8, 'system/library/export_import/Classes/PHPExcel/locale/it/functions', '2020-08-02 19:56:24'),
(1052, 8, 'system/library/export_import/Classes/PHPExcel/locale/nl/config', '2020-08-02 19:56:24'),
(1053, 8, 'system/library/export_import/Classes/PHPExcel/locale/nl/functions', '2020-08-02 19:56:24'),
(1054, 8, 'system/library/export_import/Classes/PHPExcel/locale/no/config', '2020-08-02 19:56:24'),
(1055, 8, 'system/library/export_import/Classes/PHPExcel/locale/no/functions', '2020-08-02 19:56:24'),
(1056, 8, 'system/library/export_import/Classes/PHPExcel/locale/pl/config', '2020-08-02 19:56:24'),
(1057, 8, 'system/library/export_import/Classes/PHPExcel/locale/pl/functions', '2020-08-02 19:56:24'),
(1058, 8, 'system/library/export_import/Classes/PHPExcel/locale/pt/br', '2020-08-02 19:56:24'),
(1059, 8, 'system/library/export_import/Classes/PHPExcel/locale/pt/config', '2020-08-02 19:56:24'),
(1060, 8, 'system/library/export_import/Classes/PHPExcel/locale/pt/functions', '2020-08-02 19:56:24'),
(1061, 8, 'system/library/export_import/Classes/PHPExcel/locale/ru/config', '2020-08-02 19:56:24'),
(1062, 8, 'system/library/export_import/Classes/PHPExcel/locale/ru/functions', '2020-08-02 19:56:24'),
(1063, 8, 'system/library/export_import/Classes/PHPExcel/locale/sv/config', '2020-08-02 19:56:24'),
(1064, 8, 'system/library/export_import/Classes/PHPExcel/locale/sv/functions', '2020-08-02 19:56:24'),
(1065, 8, 'system/library/export_import/Classes/PHPExcel/locale/tr/config', '2020-08-02 19:56:24'),
(1066, 8, 'system/library/export_import/Classes/PHPExcel/locale/tr/functions', '2020-08-02 19:56:24'),
(1067, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/Color/BIFF5.php', '2020-08-02 19:56:24'),
(1068, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/Color/BIFF8.php', '2020-08-02 19:56:24'),
(1069, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/Color/BuiltIn.php', '2020-08-02 19:56:24'),
(1070, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/Style/Border.php', '2020-08-02 19:56:24'),
(1071, 8, 'system/library/export_import/Classes/PHPExcel/Reader/Excel5/Style/FillPattern.php', '2020-08-02 19:56:24'),
(1072, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DgContainer/SpgrContainer', '2020-08-02 19:56:24'),
(1073, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DgContainer/SpgrContainer.php', '2020-08-02 19:56:24'),
(1074, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DggContainer/BstoreContainer', '2020-08-02 19:56:24'),
(1075, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DggContainer/BstoreContainer.php', '2020-08-02 19:56:24'),
(1076, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA/utils/Error.php', '2020-08-02 19:56:24'),
(1077, 8, 'system/library/export_import/Classes/PHPExcel/Shared/JAMA/utils/Maths.php', '2020-08-02 19:56:24'),
(1078, 8, 'system/library/export_import/Classes/PHPExcel/Shared/OLE/PPS/File.php', '2020-08-02 19:56:24'),
(1079, 8, 'system/library/export_import/Classes/PHPExcel/Shared/OLE/PPS/Root.php', '2020-08-02 19:56:24'),
(1080, 8, 'system/library/export_import/Classes/PHPExcel/Worksheet/AutoFilter/Column/Rule.php', '2020-08-02 19:56:24'),
(1081, 8, 'system/library/export_import/Classes/PHPExcel/Writer/OpenDocument/Cell/Comment.php', '2020-08-02 19:56:24'),
(1082, 8, 'system/library/export_import/Classes/PHPExcel/locale/en/uk/config', '2020-08-02 19:56:24'),
(1083, 8, 'system/library/export_import/Classes/PHPExcel/locale/pt/br/config', '2020-08-02 19:56:24'),
(1084, 8, 'system/library/export_import/Classes/PHPExcel/locale/pt/br/functions', '2020-08-02 19:56:24'),
(1085, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DgContainer/SpgrContainer/SpContainer.php', '2020-08-02 19:56:24'),
(1086, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DggContainer/BstoreContainer/BSE', '2020-08-02 19:56:24'),
(1087, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DggContainer/BstoreContainer/BSE.php', '2020-08-02 19:56:24'),
(1088, 8, 'system/library/export_import/Classes/PHPExcel/Shared/Escher/DggContainer/BstoreContainer/BSE/Blip.php', '2020-08-02 19:56:24'),
(1093, 9, 'admin/controller/extension/payment/yandex_money_b2b_sberbank.php', '2020-08-02 20:23:56'),
(1094, 9, 'admin/model/extension/payment/yandex_money', '2020-08-02 20:23:56'),
(1095, 9, 'admin/model/extension/payment/yandex_money.php', '2020-08-02 20:23:56'),
(1096, 9, 'catalog/controller/extension/payment/yandex_money.php', '2020-08-02 20:23:56'),
(1097, 9, 'catalog/controller/extension/payment/yandex_money_b2b_sberbank.php', '2020-08-02 20:23:56'),
(1098, 9, 'catalog/model/extension/payment/yandex_money', '2020-08-02 20:23:56'),
(1099, 9, 'catalog/model/extension/payment/yandex_money.php', '2020-08-02 20:23:56'),
(1100, 9, 'catalog/model/extension/payment/yandex_money_b2b_sberbank.php', '2020-08-02 20:23:56'),
(1101, 9, 'catalog/view/theme/journal3/template', '2020-08-02 20:23:56'),
(1102, 9, 'image/catalog/payment/yandex_money/alfabank.png', '2020-08-02 20:23:56'),
(1103, 9, 'image/catalog/payment/yandex_money/bank_card.png', '2020-08-02 20:23:56'),
(1104, 9, 'image/catalog/payment/yandex_money/cash.png', '2020-08-02 20:23:56'),
(1105, 9, 'image/catalog/payment/yandex_money/installments.png', '2020-08-02 20:23:56'),
(1106, 9, 'image/catalog/payment/yandex_money/ma.png', '2020-08-02 20:23:56'),
(1107, 9, 'image/catalog/payment/yandex_money/mobile.png', '2020-08-02 20:23:56'),
(1108, 9, 'image/catalog/payment/yandex_money/pb.png', '2020-08-02 20:23:56'),
(1109, 9, 'image/catalog/payment/yandex_money/qiwi.png', '2020-08-02 20:23:56'),
(1110, 9, 'image/catalog/payment/yandex_money/qp.png', '2020-08-02 20:23:56'),
(1111, 9, 'image/catalog/payment/yandex_money/sberbank.png', '2020-08-02 20:23:56'),
(1112, 9, 'image/catalog/payment/yandex_money/tinkoff_bank.png', '2020-08-02 20:23:56'),
(1113, 9, 'image/catalog/payment/yandex_money/webmoney.png', '2020-08-02 20:23:56'),
(1114, 9, 'image/catalog/payment/yandex_money/widget.png', '2020-08-02 20:23:56'),
(1115, 9, 'image/catalog/payment/yandex_money/yandex_buttons.png', '2020-08-02 20:23:56'),
(1116, 9, 'image/catalog/payment/yandex_money/yandex_money.png', '2020-08-02 20:23:56'),
(1117, 9, 'image/catalog/payment/yandex_money/yandex_money_logo.png', '2020-08-02 20:23:56'),
(1118, 9, 'admin/language/en-gb/extension/payment/yandex_money.php', '2020-08-02 20:23:56'),
(1119, 9, 'admin/language/en-gb/extension/payment/yandex_money_b2b_sberbank.php', '2020-08-02 20:23:56'),
(1120, 9, 'admin/language/ru-ru/extension/payment/yandex_money.php', '2020-08-02 20:23:56'),
(1121, 9, 'admin/language/ru-ru/extension/payment/yandex_money_b2b_sberbank.php', '2020-08-02 20:23:56'),
(1122, 9, 'admin/model/extension/payment/yandex_money/Updater', '2020-08-02 20:23:56'),
(1123, 9, 'admin/model/extension/payment/yandex_money/YandexMoneyBillingModel.php', '2020-08-02 20:23:56'),
(1124, 9, 'admin/model/extension/payment/yandex_money/YandexMoneyKassaModel.php', '2020-08-02 20:23:56'),
(1125, 9, 'admin/model/extension/payment/yandex_money/YandexMoneyMarketModel.php', '2020-08-02 20:23:56'),
(1126, 9, 'admin/model/extension/payment/yandex_money/YandexMoneyMetrikaModel.php', '2020-08-02 20:23:56'),
(1127, 9, 'admin/model/extension/payment/yandex_money/YandexMoneyWalletModel.php', '2020-08-02 20:23:56'),
(1128, 9, 'admin/model/extension/payment/yandex_money/opencart-3.map', '2020-08-02 20:23:56'),
(1129, 9, 'admin/view/template/extension/payment/yandex_money', '2020-08-02 20:23:56'),
(1130, 9, 'admin/view/template/extension/payment/yandex_money.twig', '2020-08-02 20:23:56'),
(1131, 9, 'catalog/language/en-gb/extension/payment/yandex_money.php', '2020-08-02 20:23:56'),
(1132, 9, 'catalog/language/ru-ru/extension/payment/yandex_money.php', '2020-08-02 20:23:56'),
(1133, 9, 'catalog/model/extension/payment/yandex_money/Model', '2020-08-02 20:23:56'),
(1134, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket', '2020-08-02 20:23:56'),
(1135, 9, 'catalog/model/extension/payment/yandex_money/autoload.php', '2020-08-02 20:23:56'),
(1136, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php', '2020-08-02 20:23:56'),
(1137, 9, 'catalog/view/theme/journal3/template/extension', '2020-08-02 20:23:56'),
(1138, 9, 'admin/model/extension/payment/yandex_money/Updater/Archive', '2020-08-02 20:23:56'),
(1139, 9, 'admin/model/extension/payment/yandex_money/Updater/GitHubConnector.php', '2020-08-02 20:23:56'),
(1140, 9, 'admin/model/extension/payment/yandex_money/Updater/ProjectStructure', '2020-08-02 20:23:56'),
(1141, 9, 'admin/view/template/extension/payment/yandex_money/billing.twig', '2020-08-02 20:23:56'),
(1142, 9, 'admin/view/template/extension/payment/yandex_money/capture.twig', '2020-08-02 20:23:56'),
(1143, 9, 'admin/view/template/extension/payment/yandex_money/invoice_list.twig', '2020-08-02 20:23:56'),
(1144, 9, 'admin/view/template/extension/payment/yandex_money/invoice_message.twig', '2020-08-02 20:23:56'),
(1145, 9, 'admin/view/template/extension/payment/yandex_money/kassa.twig', '2020-08-02 20:23:56'),
(1146, 9, 'admin/view/template/extension/payment/yandex_money/kassa_payments_list.twig', '2020-08-02 20:23:56'),
(1147, 9, 'admin/view/template/extension/payment/yandex_money/logs.twig', '2020-08-02 20:23:56'),
(1148, 9, 'admin/view/template/extension/payment/yandex_money/market.twig', '2020-08-02 20:23:56'),
(1149, 9, 'admin/view/template/extension/payment/yandex_money/metrika.twig', '2020-08-02 20:23:56'),
(1150, 9, 'admin/view/template/extension/payment/yandex_money/refund.twig', '2020-08-02 20:23:56'),
(1151, 9, 'admin/view/template/extension/payment/yandex_money/updater.twig', '2020-08-02 20:23:56'),
(1152, 9, 'admin/view/template/extension/payment/yandex_money/wallet.twig', '2020-08-02 20:23:56'),
(1153, 9, 'catalog/model/extension/payment/yandex_money/Model/AbstractPaymentModel.php', '2020-08-02 20:23:56'),
(1154, 9, 'catalog/model/extension/payment/yandex_money/Model/BillingModel.php', '2020-08-02 20:23:56'),
(1155, 9, 'catalog/model/extension/payment/yandex_money/Model/CBRAgent.php', '2020-08-02 20:23:56'),
(1156, 9, 'catalog/model/extension/payment/yandex_money/Model/KassaModel.php', '2020-08-02 20:23:56'),
(1157, 9, 'catalog/model/extension/payment/yandex_money/Model/KassaSecondReceiptModel.php', '2020-08-02 20:23:56'),
(1158, 9, 'catalog/model/extension/payment/yandex_money/Model/MarketModel.php', '2020-08-02 20:23:56'),
(1159, 9, 'catalog/model/extension/payment/yandex_money/Model/WalletModel.php', '2020-08-02 20:23:56'),
(1160, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/ArbitraryYmlBuilder.php', '2020-08-02 20:23:56'),
(1161, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/CategoryTreeBuilder.php', '2020-08-02 20:23:56'),
(1162, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/Currency.php', '2020-08-02 20:23:56'),
(1163, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/DeliveryOption.php', '2020-08-02 20:23:56'),
(1164, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/MarketObject.php', '2020-08-02 20:23:56'),
(1165, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/Offer.php', '2020-08-02 20:23:56'),
(1166, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/ParameterList.php', '2020-08-02 20:23:56'),
(1167, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/ProductCategory.php', '2020-08-02 20:23:56'),
(1168, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/ShopInfo.php', '2020-08-02 20:23:56'),
(1169, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/SimpleYmlBuilder.php', '2020-08-02 20:23:56'),
(1170, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/YandexMarket.php', '2020-08-02 20:23:56'),
(1171, 9, 'catalog/model/extension/payment/yandex_money/YandexMarket/YmlBuilder.php', '2020-08-02 20:23:56'),
(1172, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib', '2020-08-02 20:23:56'),
(1173, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor', '2020-08-02 20:23:56'),
(1174, 9, 'catalog/view/theme/journal3/template/extension/payment', '2020-08-02 20:23:56'),
(1175, 9, 'admin/model/extension/payment/yandex_money/Updater/Archive/BackupZip.php', '2020-08-02 20:23:56'),
(1176, 9, 'admin/model/extension/payment/yandex_money/Updater/Archive/RestoreZip.php', '2020-08-02 20:23:56'),
(1177, 9, 'admin/model/extension/payment/yandex_money/Updater/ProjectStructure/AbstractEntry.php', '2020-08-02 20:23:56'),
(1178, 9, 'admin/model/extension/payment/yandex_money/Updater/ProjectStructure/DirectoryEntry.php', '2020-08-02 20:23:56'),
(1179, 9, 'admin/model/extension/payment/yandex_money/Updater/ProjectStructure/DirectoryEntryInterface.php', '2020-08-02 20:23:56'),
(1180, 9, 'admin/model/extension/payment/yandex_money/Updater/ProjectStructure/EntryInterface.php', '2020-08-02 20:23:56'),
(1181, 9, 'admin/model/extension/payment/yandex_money/Updater/ProjectStructure/FileEntry.php', '2020-08-02 20:23:56'),
(1182, 9, 'admin/model/extension/payment/yandex_money/Updater/ProjectStructure/FileEntryInterface.php', '2020-08-02 20:23:56'),
(1183, 9, 'admin/model/extension/payment/yandex_money/Updater/ProjectStructure/ProjectStructureReader.php', '2020-08-02 20:23:56'),
(1184, 9, 'admin/model/extension/payment/yandex_money/Updater/ProjectStructure/ProjectStructureWriter.php', '2020-08-02 20:23:56'),
(1185, 9, 'admin/model/extension/payment/yandex_money/Updater/ProjectStructure/RootDirectory.php', '2020-08-02 20:23:56'),
(1186, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Client', '2020-08-02 20:23:56'),
(1187, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Client.php', '2020-08-02 20:23:56'),
(1188, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common', '2020-08-02 20:23:56'),
(1189, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Helpers', '2020-08-02 20:23:56'),
(1190, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model', '2020-08-02 20:23:56'),
(1191, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request', '2020-08-02 20:23:56'),
(1192, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/autoload.php', '2020-08-02 20:23:56'),
(1193, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/configuration.json', '2020-08-02 20:23:56'),
(1194, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr', '2020-08-02 20:23:56'),
(1195, 9, 'catalog/view/theme/default/template/extension/payment/yandex_money', '2020-08-02 20:23:56'),
(1196, 9, 'catalog/view/theme/default/template/extension/payment/yandex_money_failure_status.tpl', '2020-08-02 20:23:56'),
(1197, 9, 'catalog/view/theme/default/template/extension/payment/yandex_money_success_status.tpl', '2020-08-02 20:23:56'),
(1198, 9, 'catalog/view/theme/journal3/template/extension/payment/yandex_money', '2020-08-02 20:23:56'),
(1199, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Client/ApiClientInterface.php', '2020-08-02 20:23:56'),
(1200, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Client/BaseClient.php', '2020-08-02 20:23:56'),
(1201, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Client/CurlClient.php', '2020-08-02 20:23:56'),
(1202, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Client/StreamClient.php', '2020-08-02 20:23:56'),
(1203, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Client/UserAgent.php', '2020-08-02 20:23:56'),
(1204, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Client/YandexMoneyApi.php', '2020-08-02 20:23:56'),
(1205, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/AbstractEnum.php', '2020-08-02 20:23:56'),
(1206, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/AbstractObject.php', '2020-08-02 20:23:56'),
(1207, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/AbstractPaymentRequest.php', '2020-08-02 20:23:56'),
(1208, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/AbstractPaymentRequestBuilder.php', '2020-08-02 20:23:56'),
(1209, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/AbstractRequest.php', '2020-08-02 20:23:56'),
(1210, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/AbstractRequestBuilder.php', '2020-08-02 20:23:56'),
(1211, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions', '2020-08-02 20:23:56'),
(1212, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/HttpVerb.php', '2020-08-02 20:23:56'),
(1213, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/LoggerWrapper.php', '2020-08-02 20:23:56'),
(1214, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/RequestObjectInterface.php', '2020-08-02 20:23:56'),
(1215, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/ResponseObject.php', '2020-08-02 20:23:56'),
(1216, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/legacy_json_serializable.php', '2020-08-02 20:23:56'),
(1217, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Helpers/Config', '2020-08-02 20:23:56'),
(1218, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Helpers/Random.php', '2020-08-02 20:23:56'),
(1219, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Helpers/RawHeadersParser.php', '2020-08-02 20:23:56'),
(1220, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Helpers/StringObject.php', '2020-08-02 20:23:56'),
(1221, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Helpers/TypeCast.php', '2020-08-02 20:23:56'),
(1222, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Helpers/UUID.php', '2020-08-02 20:23:56'),
(1223, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Airline.php', '2020-08-02 20:23:56'),
(1224, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/AirlineInterface.php', '2020-08-02 20:23:56'),
(1225, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/AmountInterface.php', '2020-08-02 20:23:56'),
(1226, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/AuthorizationDetails.php', '2020-08-02 20:23:56'),
(1227, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/AuthorizationDetailsInterface.php', '2020-08-02 20:23:56'),
(1228, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/CancellationDetails.php', '2020-08-02 20:23:56'),
(1229, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/CancellationDetailsInterface.php', '2020-08-02 20:23:56'),
(1230, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/CancellationDetailsPartyCode.php', '2020-08-02 20:23:56'),
(1231, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/CancellationDetailsReasonCode.php', '2020-08-02 20:23:56'),
(1232, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Confirmation', '2020-08-02 20:23:56'),
(1233, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ConfirmationAttributes', '2020-08-02 20:23:56'),
(1234, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ConfirmationType.php', '2020-08-02 20:23:56'),
(1235, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/CurrencyCode.php', '2020-08-02 20:23:56'),
(1236, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Leg.php', '2020-08-02 20:23:56'),
(1237, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/LegInterface.php', '2020-08-02 20:23:56'),
(1238, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Metadata.php', '2020-08-02 20:23:56'),
(1239, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/MonetaryAmount.php', '2020-08-02 20:23:56'),
(1240, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Notification', '2020-08-02 20:23:56'),
(1241, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/NotificationEventType.php', '2020-08-02 20:23:56'),
(1242, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/NotificationType.php', '2020-08-02 20:23:56'),
(1243, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Order.php', '2020-08-02 20:23:56'),
(1244, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/OrderInterface.php', '2020-08-02 20:23:56'),
(1245, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Passenger.php', '2020-08-02 20:23:56'),
(1246, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PassengerInterface.php', '2020-08-02 20:23:56'),
(1247, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Payment.php', '2020-08-02 20:23:56'),
(1248, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData', '2020-08-02 20:23:56'),
(1249, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentError.php', '2020-08-02 20:23:56'),
(1250, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentErrorCode.php', '2020-08-02 20:23:56'),
(1251, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentErrorInterface.php', '2020-08-02 20:23:56'),
(1252, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentInterface.php', '2020-08-02 20:23:56'),
(1253, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod', '2020-08-02 20:23:56'),
(1254, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethodType.php', '2020-08-02 20:23:56'),
(1255, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentStatus.php', '2020-08-02 20:23:56'),
(1256, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Receipt', '2020-08-02 20:23:56'),
(1257, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Receipt.php', '2020-08-02 20:23:56'),
(1258, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ReceiptCustomer.php', '2020-08-02 20:23:56'),
(1259, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ReceiptCustomerInterface.php', '2020-08-02 20:23:56'),
(1260, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ReceiptInterface.php', '2020-08-02 20:23:56'),
(1261, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ReceiptItem.php', '2020-08-02 20:23:56'),
(1262, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ReceiptItemInterface.php', '2020-08-02 20:23:56'),
(1263, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ReceiptRegistrationStatus.php', '2020-08-02 20:23:56'),
(1264, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ReceiptType.php', '2020-08-02 20:23:56'),
(1265, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Recipient.php', '2020-08-02 20:23:56'),
(1266, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/RecipientInterface.php', '2020-08-02 20:23:56'),
(1267, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Refund.php', '2020-08-02 20:23:56'),
(1268, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/RefundError.php', '2020-08-02 20:23:56'),
(1269, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/RefundErrorInterface.php', '2020-08-02 20:23:56'),
(1270, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/RefundInterface.php', '2020-08-02 20:23:56'),
(1271, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/RefundStatus.php', '2020-08-02 20:23:56'),
(1272, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Requestor.php', '2020-08-02 20:23:56'),
(1273, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/RequestorInterface.php', '2020-08-02 20:23:56'),
(1274, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Settlement.php', '2020-08-02 20:23:56'),
(1275, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/SettlementInterface.php', '2020-08-02 20:23:56'),
(1276, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Source.php', '2020-08-02 20:23:56'),
(1277, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/SourceInterface.php', '2020-08-02 20:23:56'),
(1278, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Status.php', '2020-08-02 20:23:56'),
(1279, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Supplier.php', '2020-08-02 20:23:56'),
(1280, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/SupplierInterface.php', '2020-08-02 20:23:56'),
(1281, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Transfer.php', '2020-08-02 20:23:56'),
(1282, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/TransferInterface.php', '2020-08-02 20:23:56'),
(1283, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/TransferStatus.php', '2020-08-02 20:23:56'),
(1284, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Webhook', '2020-08-02 20:23:56'),
(1285, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/PaymentOptionsRequest.php', '2020-08-02 20:23:56'),
(1286, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/PaymentOptionsRequestBuilder.php', '2020-08-02 20:23:56'),
(1287, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/PaymentOptionsRequestInterface.php', '2020-08-02 20:23:56'),
(1288, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/PaymentOptionsRequestSerializer.php', '2020-08-02 20:23:56'),
(1289, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/PaymentOptionsResponse.php', '2020-08-02 20:23:56'),
(1290, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/PaymentOptionsResponseItem.php', '2020-08-02 20:23:56'),
(1291, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments', '2020-08-02 20:23:56'),
(1292, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts', '2020-08-02 20:23:56'),
(1293, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds', '2020-08-02 20:23:56'),
(1294, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/StateUnknownResponse.php', '2020-08-02 20:23:56'),
(1295, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Webhook', '2020-08-02 20:23:56'),
(1296, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log', '2020-08-02 20:23:56'),
(1297, 9, 'catalog/view/theme/default/template/extension/payment/yandex_money/billing_form.twig', '2020-08-02 20:23:56'),
(1298, 9, 'catalog/view/theme/default/template/extension/payment/yandex_money/kassa_form.twig', '2020-08-02 20:23:56'),
(1299, 9, 'catalog/view/theme/default/template/extension/payment/yandex_money/kassa_form_b2b.twig', '2020-08-02 20:23:56'),
(1300, 9, 'catalog/view/theme/default/template/extension/payment/yandex_money/wallet_form.twig', '2020-08-02 20:23:56'),
(1301, 9, 'catalog/view/theme/journal3/template/extension/payment/yandex_money/kassa_form.twig', '2020-08-02 20:23:56'),
(1302, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/ApiConnectionException.php', '2020-08-02 20:23:56'),
(1303, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/ApiException.php', '2020-08-02 20:23:56'),
(1304, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/AuthorizeException.php', '2020-08-02 20:23:56'),
(1305, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/BadApiRequestException.php', '2020-08-02 20:23:56'),
(1306, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/EmptyPropertyValueException.php', '2020-08-02 20:23:56'),
(1307, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/ExtensionNotFoundException.php', '2020-08-02 20:23:56'),
(1308, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/ForbiddenException.php', '2020-08-02 20:23:56'),
(1309, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/InternalServerError.php', '2020-08-02 20:23:56'),
(1310, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/InvalidPropertyException.php', '2020-08-02 20:23:56'),
(1311, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/InvalidPropertyValueException.php', '2020-08-02 20:23:56'),
(1312, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/InvalidPropertyValueTypeException.php', '2020-08-02 20:23:56'),
(1313, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/InvalidRequestException.php', '2020-08-02 20:23:56'),
(1314, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/JsonException.php', '2020-08-02 20:23:56'),
(1315, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/NotFoundException.php', '2020-08-02 20:23:56'),
(1316, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/ResponseProcessingException.php', '2020-08-02 20:23:56'),
(1317, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/TechnicalError.php', '2020-08-02 20:23:56'),
(1318, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/TooManyRequestsException.php', '2020-08-02 20:23:56'),
(1319, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Common/Exceptions/UnauthorizedException.php', '2020-08-02 20:23:56'),
(1320, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Helpers/Config/ConfigurationLoader.php', '2020-08-02 20:23:56'),
(1321, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Helpers/Config/ConfigurationLoaderInterface.php', '2020-08-02 20:23:56'),
(1322, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Confirmation/AbstractConfirmation.php', '2020-08-02 20:23:56'),
(1323, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Confirmation/ConfirmationCodeVerification.php', '2020-08-02 20:23:56'),
(1324, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Confirmation/ConfirmationDeepLink.php', '2020-08-02 20:23:56'),
(1325, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Confirmation/ConfirmationEmbedded.php', '2020-08-02 20:23:56'),
(1326, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Confirmation/ConfirmationExternal.php', '2020-08-02 20:23:56'),
(1327, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Confirmation/ConfirmationFactory.php', '2020-08-02 20:23:56'),
(1328, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Confirmation/ConfirmationQr.php', '2020-08-02 20:23:56'),
(1329, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Confirmation/ConfirmationRedirect.php', '2020-08-02 20:23:56'),
(1330, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ConfirmationAttributes/AbstractConfirmationAttributes.php', '2020-08-02 20:23:56'),
(1331, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ConfirmationAttributes/ConfirmationAttributesCodeVerification.php', '2020-08-02 20:23:56'),
(1332, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ConfirmationAttributes/ConfirmationAttributesDeepLink.php', '2020-08-02 20:23:56'),
(1333, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ConfirmationAttributes/ConfirmationAttributesEmbedded.php', '2020-08-02 20:23:56');
INSERT INTO `oc_extension_path` (`extension_path_id`, `extension_install_id`, `path`, `date_added`) VALUES
(1334, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ConfirmationAttributes/ConfirmationAttributesExternal.php', '2020-08-02 20:23:56'),
(1335, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ConfirmationAttributes/ConfirmationAttributesFactory.php', '2020-08-02 20:23:56'),
(1336, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ConfirmationAttributes/ConfirmationAttributesQr.php', '2020-08-02 20:23:56'),
(1337, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/ConfirmationAttributes/ConfirmationAttributesRedirect.php', '2020-08-02 20:23:56'),
(1338, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Notification/AbstractNotification.php', '2020-08-02 20:23:56'),
(1339, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Notification/NotificationCanceled.php', '2020-08-02 20:23:56'),
(1340, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Notification/NotificationFactory.php', '2020-08-02 20:23:56'),
(1341, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Notification/NotificationRefundSucceeded.php', '2020-08-02 20:23:56'),
(1342, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Notification/NotificationSucceeded.php', '2020-08-02 20:23:56'),
(1343, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Notification/NotificationWaitingForCapture.php', '2020-08-02 20:23:56'),
(1344, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/AbstractPaymentData.php', '2020-08-02 20:23:56'),
(1345, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/B2b', '2020-08-02 20:23:56'),
(1346, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataAlfabank.php', '2020-08-02 20:23:56'),
(1347, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataAndroidPay.php', '2020-08-02 20:23:56'),
(1348, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataApplePay.php', '2020-08-02 20:23:56'),
(1349, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataB2bSberbank.php', '2020-08-02 20:23:56'),
(1350, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataBankCard.php', '2020-08-02 20:23:56'),
(1351, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataBankCardCard.php', '2020-08-02 20:23:56'),
(1352, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataCash.php', '2020-08-02 20:23:56'),
(1353, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataFactory.php', '2020-08-02 20:23:56'),
(1354, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataGooglePay.php', '2020-08-02 20:23:56'),
(1355, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataInstallments.php', '2020-08-02 20:23:56'),
(1356, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataMobileBalance.php', '2020-08-02 20:23:56'),
(1357, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataQiwi.php', '2020-08-02 20:23:56'),
(1358, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataSberbank.php', '2020-08-02 20:23:56'),
(1359, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataTinkoffBank.php', '2020-08-02 20:23:56'),
(1360, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataWebmoney.php', '2020-08-02 20:23:56'),
(1361, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataWechat.php', '2020-08-02 20:23:56'),
(1362, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/PaymentDataYandexWallet.php', '2020-08-02 20:23:56'),
(1363, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/AbstractPaymentMethod.php', '2020-08-02 20:23:56'),
(1364, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/B2b', '2020-08-02 20:23:56'),
(1365, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/BankCardSource.php', '2020-08-02 20:23:56'),
(1366, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodAlfaBank.php', '2020-08-02 20:23:56'),
(1367, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodAndroidPay.php', '2020-08-02 20:23:56'),
(1368, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodApplePay.php', '2020-08-02 20:23:56'),
(1369, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodB2bSberbank.php', '2020-08-02 20:23:56'),
(1370, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodBankCard.php', '2020-08-02 20:23:56'),
(1371, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodCardType.php', '2020-08-02 20:23:56'),
(1372, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodCash.php', '2020-08-02 20:23:56'),
(1373, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodFactory.php', '2020-08-02 20:23:56'),
(1374, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodGooglePay.php', '2020-08-02 20:23:56'),
(1375, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodInstallments.php', '2020-08-02 20:23:56'),
(1376, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodMobileBalance.php', '2020-08-02 20:23:56'),
(1377, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodPsb.php', '2020-08-02 20:23:56'),
(1378, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodQiwi.php', '2020-08-02 20:23:56'),
(1379, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodSberbank.php', '2020-08-02 20:23:56'),
(1380, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodTinkoffBank.php', '2020-08-02 20:23:56'),
(1381, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodWebmoney.php', '2020-08-02 20:23:56'),
(1382, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodWechat.php', '2020-08-02 20:23:56'),
(1383, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/PaymentMethodYandexWallet.php', '2020-08-02 20:23:56'),
(1384, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Receipt/AgentType.php', '2020-08-02 20:23:56'),
(1385, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Receipt/PaymentMode.php', '2020-08-02 20:23:56'),
(1386, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Receipt/PaymentSubject.php', '2020-08-02 20:23:56'),
(1387, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Receipt/ReceiptItemAmount.php', '2020-08-02 20:23:56'),
(1388, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Receipt/SettlementType.php', '2020-08-02 20:23:56'),
(1389, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/Webhook/Webhook.php', '2020-08-02 20:23:56'),
(1390, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/AbstractPaymentResponse.php', '2020-08-02 20:23:56'),
(1391, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/CreatePaymentRequest.php', '2020-08-02 20:23:56'),
(1392, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/CreatePaymentRequestBuilder.php', '2020-08-02 20:23:56'),
(1393, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/CreatePaymentRequestInterface.php', '2020-08-02 20:23:56'),
(1394, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/CreatePaymentRequestSerializer.php', '2020-08-02 20:23:56'),
(1395, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/CreatePaymentResponse.php', '2020-08-02 20:23:56'),
(1396, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/Payment', '2020-08-02 20:23:56'),
(1397, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/PaymentResponse.php', '2020-08-02 20:23:56'),
(1398, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/PaymentsRequest.php', '2020-08-02 20:23:56'),
(1399, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/PaymentsRequestBuilder.php', '2020-08-02 20:23:56'),
(1400, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/PaymentsRequestInterface.php', '2020-08-02 20:23:56'),
(1401, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/PaymentsRequestSerializer.php', '2020-08-02 20:23:56'),
(1402, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/PaymentsResponse.php', '2020-08-02 20:23:56'),
(1403, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/AbstractReceiptResponse.php', '2020-08-02 20:23:56'),
(1404, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/CreatePostReceiptRequest.php', '2020-08-02 20:23:56'),
(1405, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/CreatePostReceiptRequestBuilder.php', '2020-08-02 20:23:56'),
(1406, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/CreatePostReceiptRequestInterface.php', '2020-08-02 20:23:56'),
(1407, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/CreatePostReceiptRequestSerializer.php', '2020-08-02 20:23:56'),
(1408, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/PaymentReceiptResponse.php', '2020-08-02 20:23:56'),
(1409, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/ReceiptResponseFactory.php', '2020-08-02 20:23:56'),
(1410, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/ReceiptResponseInterface.php', '2020-08-02 20:23:56'),
(1411, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/ReceiptResponseItem.php', '2020-08-02 20:23:56'),
(1412, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/ReceiptResponseItemInterface.php', '2020-08-02 20:23:56'),
(1413, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/ReceiptsResponse.php', '2020-08-02 20:23:56'),
(1414, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Receipts/RefundReceiptResponse.php', '2020-08-02 20:23:56'),
(1415, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/AbstractRefundResponse.php', '2020-08-02 20:23:56'),
(1416, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/CreateRefundRequest.php', '2020-08-02 20:23:56'),
(1417, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/CreateRefundRequestBuilder.php', '2020-08-02 20:23:56'),
(1418, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/CreateRefundRequestInterface.php', '2020-08-02 20:23:56'),
(1419, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/CreateRefundRequestSerializer.php', '2020-08-02 20:23:56'),
(1420, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/CreateRefundResponse.php', '2020-08-02 20:23:56'),
(1421, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/RefundResponse.php', '2020-08-02 20:23:56'),
(1422, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/RefundsRequest.php', '2020-08-02 20:23:56'),
(1423, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/RefundsRequestBuilder.php', '2020-08-02 20:23:56'),
(1424, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/RefundsRequestInterface.php', '2020-08-02 20:23:56'),
(1425, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/RefundsRequestSerializer.php', '2020-08-02 20:23:56'),
(1426, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Refunds/RefundsResponse.php', '2020-08-02 20:23:56'),
(1427, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Webhook/WebhookListResponse.php', '2020-08-02 20:23:56'),
(1428, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/LICENSE', '2020-08-02 20:23:56'),
(1429, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr', '2020-08-02 20:23:56'),
(1430, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/README.md', '2020-08-02 20:23:56'),
(1431, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/composer.json', '2020-08-02 20:23:56'),
(1432, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/B2b/Sberbank', '2020-08-02 20:23:56'),
(1433, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/B2b/Sberbank', '2020-08-02 20:23:56'),
(1434, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/Payment/CancelResponse.php', '2020-08-02 20:23:56'),
(1435, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/Payment/CreateCaptureRequest.php', '2020-08-02 20:23:56'),
(1436, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/Payment/CreateCaptureRequestBuilder.php', '2020-08-02 20:23:56'),
(1437, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/Payment/CreateCaptureRequestInterface.php', '2020-08-02 20:23:56'),
(1438, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/Payment/CreateCaptureRequestSerializer.php', '2020-08-02 20:23:56'),
(1439, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Request/Payments/Payment/CreateCaptureResponse.php', '2020-08-02 20:23:56'),
(1440, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log', '2020-08-02 20:23:56'),
(1441, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/B2b/Sberbank/VatData.php', '2020-08-02 20:23:56'),
(1442, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/B2b/Sberbank/VatDataInterface.php', '2020-08-02 20:23:56'),
(1443, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/B2b/Sberbank/VatDataRate.php', '2020-08-02 20:23:56'),
(1444, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentData/B2b/Sberbank/VatDataType.php', '2020-08-02 20:23:56'),
(1445, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/B2b/Sberbank/PayerBankDetails.php', '2020-08-02 20:23:56'),
(1446, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/lib/Model/PaymentMethod/B2b/Sberbank/PayerBankDetailsInterface.php', '2020-08-02 20:23:56'),
(1447, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log/AbstractLogger.php', '2020-08-02 20:23:56'),
(1448, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log/InvalidArgumentException.php', '2020-08-02 20:23:56'),
(1449, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log/LogLevel.php', '2020-08-02 20:23:56'),
(1450, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log/LoggerAwareInterface.php', '2020-08-02 20:23:56'),
(1451, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log/LoggerAwareTrait.php', '2020-08-02 20:23:56'),
(1452, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log/LoggerInterface.php', '2020-08-02 20:23:56'),
(1453, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log/LoggerTrait.php', '2020-08-02 20:23:56'),
(1454, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log/NullLogger.php', '2020-08-02 20:23:56'),
(1455, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log/Test', '2020-08-02 20:23:56'),
(1456, 9, 'catalog/model/extension/payment/yandex_money/yandex-checkout-sdk-php/vendor/psr/log/Psr/Log/Test/LoggerInterfaceTest.php', '2020-08-02 20:23:56');

-- --------------------------------------------------------

--
-- Table structure for table `oc_filter`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_filter`;
CREATE TABLE `oc_filter` (
  `filter_id` int(11) NOT NULL,
  `filter_group_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_filter_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_filter_description`;
CREATE TABLE `oc_filter_description` (
  `filter_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `filter_group_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_filter_group`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_filter_group`;
CREATE TABLE `oc_filter_group` (
  `filter_group_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_filter_group_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_filter_group_description`;
CREATE TABLE `oc_filter_group_description` (
  `filter_group_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_geo_zone`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_geo_zone`;
CREATE TABLE `oc_geo_zone` (
  `geo_zone_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_geo_zone`
--

INSERT INTO `oc_geo_zone` (`geo_zone_id`, `name`, `description`, `date_added`, `date_modified`) VALUES
(3, 'UK VAT Zone', 'UK VAT', '2009-01-06 23:26:25', '2010-02-26 22:33:24'),
(4, 'UK Shipping', 'UK Shipping Zones', '2009-06-23 01:14:53', '2010-12-15 15:18:13');

-- --------------------------------------------------------

--
-- Table structure for table `oc_information`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_information`;
CREATE TABLE `oc_information` (
  `information_id` int(11) NOT NULL,
  `bottom` int(1) NOT NULL DEFAULT '0',
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_information`
--

INSERT INTO `oc_information` (`information_id`, `bottom`, `sort_order`, `status`) VALUES
(3, 1, 3, 1),
(4, 1, 1, 1),
(5, 1, 4, 1),
(6, 1, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_information_description`
--
-- Creation: Aug 02, 2020 at 10:54 AM
-- Last update: Aug 02, 2020 at 10:54 AM
--

DROP TABLE IF EXISTS `oc_information_description`;
CREATE TABLE `oc_information_description` (
  `information_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(64) NOT NULL,
  `description` mediumtext NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  `seo_h1` varchar(255) NOT NULL,
  `seo_h2` varchar(255) NOT NULL,
  `seo_h3` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_information_description`
--

INSERT INTO `oc_information_description` (`information_id`, `language_id`, `title`, `description`, `meta_title`, `meta_description`, `meta_keyword`, `seo_keyword`, `seo_h1`, `seo_h2`, `seo_h3`) VALUES
(3, 1, 'Privacy Policy', '&lt;p&gt;\r\n	Privacy Policy&lt;/p&gt;\r\n', 'Privacy Policy', '', '', '', '', '', ''),
(6, 1, 'Delivery Information', '&lt;p&gt;\r\n	Delivery Information&lt;/p&gt;\r\n', 'Delivery Information', '', '', '', '', '', ''),
(4, 2, 'О компании', '&lt;p&gt;\r\n	About Us&lt;/p&gt;\r\n', 'About Us', '', '', '', '', '', ''),
(5, 2, 'Пользовательское соглашение', '    &lt;h1&gt;&lt;span style=&quot;font-size: 13px;&quot;&gt;Настоящее пользовательское соглашение (далее — «Соглашение») заключается между Пользователем\r\n        (ИП или юридическим лицом, прошедшим регистрацию и/или оформившим заказ на сайте Интернет-магазина) и\r\n        Администратором Интернет-магазина — ООО «Тэкма», юридический и фактический адрес — 150003, Ярославль,\r\n        ул. Полушкина Роща, 9, ОГРН ***************** — и регулирует порядок использования Пользователем сайта\r\n        Интернет-магазина, в том числе порядок заказа товаров в Интернет-магазине. Настоящее Соглашение не является\r\n        договором купли-продажи товара.&lt;/span&gt;&lt;br&gt;&lt;/h1&gt;\r\n\r\n    &lt;ol&gt;\r\n        &lt;li&gt;\r\n            &lt;p&gt;\r\n                Использование Интернет-магазина\r\n            &lt;/p&gt;\r\n\r\n            &lt;ol&gt;\r\n                &lt;li&gt;\r\n                    Под Интернет-магазином в настоящем Соглашении понимается сервис, предоставляемый Пользователю в сети\r\n                    Интернет на сайте, находящемся по адресу http://fomas.ru/ (далее — «Сайт»), и позволяющий\r\n                    Пользователю знакомиться с ассортиментом предлагаемых Администратором товаров, условиями их\r\n                    приобретения, а также заказывать товары дистанционным способом.\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    Для идентификации в качестве стороны Соглашения и оформления заказов товара на Сайте Пользователь\r\n                    указывает свои личные и контактные данные, в точности, если Пользователь — ИП: фамилию, имя,\r\n                    отчество, название компании, ИНН, электронную почту, телефон, адрес доставки; если Пользователь —\r\n                    юридическое лицо: название компании, ИНН, контактное лицо, электронную почту, телефон, адрес\r\n                    доставки.\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    Пользователь разрешает Администратору осуществлять обработку своих персональных данных, сообщенных\r\n                    Пользователем в ходе регистрации и/или оформлении заказа на Сайте согласно п. 1.2 настоящего\r\n                    Соглашения, в целях исполнения Соглашения, заключения договора купли-продажи товаров, заказанных\r\n                    Пользователем в Интернет-магазине, и в статистических целях, а также разрешает передачу (сообщение)\r\n                    Администратором указанных данных третьим лицам (контрагентам), привлекаемым Администратором в целях\r\n                    надлежащего исполнения своих обязательств по Соглашению, в том числе в целях осуществления\r\n                    обслуживания и технической поддержки Сайта, формирования заказов и т.п.\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    Заказ товара осуществляется Пользователем путем выбора товара из каталога на Сайте. Выбранный\r\n                    Пользователем товар отображается в пользовательской корзине и после оформления заказа в личном\r\n                    кабинете Пользователя.\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    При оформлении заказа Пользователь подтверждает свое согласие с окончательной ценой товара,\r\n                    включающей в себя стоимость доставки, которая может зависеть от количества заказанного товара, его\r\n                    объема (веса), удаленности региона, в который требуется осуществить доставку товара, и иных\r\n                    обстоятельств, а также со сроком доставки, который может зависеть от наличия или отсутствия товара\r\n                    на складе в момент оформления заказа, удаленности региона доставки, способа доставки и иных\r\n                    обстоятельств.\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    Оформление заказа завершается в момент отображения на соответствующей странице сайта сообщения о\r\n                    подтверждении заказа.\r\n                &lt;/li&gt;\r\n            &lt;/ol&gt;\r\n        &lt;/li&gt;\r\n\r\n        &lt;li&gt;\r\n            &lt;p&gt;\r\n                Права и обязанности сторон\r\n            &lt;/p&gt;\r\n\r\n            &lt;ol&gt;\r\n                &lt;li&gt;\r\n                    &lt;p&gt;\r\n                        Пользователь обязуется:\r\n                    &lt;/p&gt;\r\n\r\n                    &lt;ol&gt;\r\n                        &lt;li&gt;\r\n                            указывать при регистрации и/или оформлении заказа на Сайте достоверную информацию;\r\n                        &lt;/li&gt;\r\n                        &lt;li&gt;\r\n                            если Пользователь зарегистрирован на Сайте, своевременно изменять информацию о Пользователе на\r\n                            Сайте в случае изменения адреса, телефона и иных контактных данных Пользователя;\r\n                        &lt;/li&gt;\r\n                        &lt;li&gt;\r\n                            сохранять конфиденциальность своих логина и пароля для доступа к аккаунту Пользователя на Сайте;\r\n                        &lt;/li&gt;\r\n                        &lt;li&gt;\r\n                            в случае осуществления неправомерного доступа к аккаунту Пользователя на Сайте третьими лицами\r\n                            или наличия у Пользователя достаточных оснований полагать, что такой доступ был осуществлен, —\r\n                            незамедлительно сообщить Администратору об указанных обстоятельствах.\r\n                        &lt;/li&gt;\r\n                    &lt;/ol&gt;\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    &lt;p&gt;\r\n                        Администратор обязуется:\r\n                    &lt;/p&gt;\r\n\r\n                    &lt;ol&gt;\r\n                        &lt;li&gt;\r\n                            указывать в каталоге Интернет-магазина достоверную информацию об основных потребительских\r\n                            свойствах товара, месте изготовления товара, цене и иных условиях приобретения товара;\r\n                        &lt;/li&gt;\r\n                        &lt;li&gt;\r\n                            обеспечивать конфиденциальность персональных данных о Пользователе в соответствии с\r\n                            законодательством РФ в области персональных данных;\r\n                        &lt;/li&gt;\r\n                        &lt;li&gt;\r\n                            при обработке персональных данных Пользователя принимать необходимые организационные и\r\n                            технические меры для их защиты от неправомерного или случайного доступа, уничтожения, изменения,\r\n                            блокирования, копирования, распространения, а также от иных неправомерных действий.\r\n                        &lt;/li&gt;\r\n                    &lt;/ol&gt;\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    &lt;p&gt;\r\n                        Пользователь вправе:\r\n                    &lt;/p&gt;\r\n\r\n                    &lt;ol&gt;\r\n                        &lt;li&gt;\r\n                            в любое время удалить свой аккаунт на Сайте и потребовать от Администратора прекращения\r\n                            обработки своих персональных данных;\r\n                        &lt;/li&gt;\r\n                        &lt;li&gt;\r\n                            запрашивать и получать у Администратора дополнительную информацию о товаре, внесенном в каталог\r\n                            Интернет-магазина.\r\n                        &lt;/li&gt;\r\n                    &lt;/ol&gt;\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    &lt;p&gt;\r\n                        Администратор вправе в любое время без предварительного предупреждения Пользователя вносить\r\n                        изменения в работу Сайта, в том числе изменять пользовательский интерфейс Сайта, ассортимент товара\r\n                        в Интернет-магазине, описание товара в каталоге, правила оформления заказа товара и т.п.\r\n                    &lt;/p&gt;\r\n                &lt;/li&gt;\r\n            &lt;/ol&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;p&gt;\r\n                Интеллектуальные права и информационная безопасность\r\n            &lt;/p&gt;\r\n\r\n            &lt;ol&gt;\r\n                &lt;li&gt;\r\n                    Пользователь признает, что контент Сайта и его отдельные элементы являются объектами интеллектуальной\r\n                    собственности Администратора или третьих лиц и обязуется не осуществлять копирование, воспроизведение,\r\n                    распространение и иное использование указанных объектов без получения надлежащего разрешения от\r\n                    соответствующего правообладателя.\r\n                &lt;/li&gt;\r\n\r\n                &lt;li&gt;\r\n                    Сервис Интернет-магазина предназначен исключительно для ознакомления Пользователя с ассортиментом\r\n                    товаров, предлагаемых к продаже Администратором, условиями их приобретения и для последующего заказа\r\n                    товара и не может использоваться Пользователем в иных целях, противоречащих назначению сервиса, — в\r\n                    частности, в целях распространения рекламы любого рода, загрузки и распространения компьютерных вирусов\r\n                    и иного вредоносного программного обеспечения, совершения иных действий, нарушающих права и законные\r\n                    интересы третьих лиц и положения действующего законодательства РФ либо противоречащих общепринятым\r\n                    принципам морали и нравственности.\r\n                &lt;/li&gt;\r\n            &lt;/ol&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;p&gt;\r\n                Ответственность сторон\r\n            &lt;/p&gt;\r\n\r\n            &lt;ol&gt;\r\n                &lt;li&gt;\r\n                    За неисполнение или ненадлежащее исполнение своих обязательств по настоящему Соглашению стороны несут\r\n                    ответственность в соответствии с условиями Соглашения и действующим законодательством РФ.\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    Стороны не несут ответственности за неисполнение или ненадлежащее исполнение своих обязанностей по\r\n                    Соглашению, явившееся следствием действия обстоятельств непреодолимой силы (войны, стихийные бедствия,\r\n                    запретительные действия властей и т. п.).\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    Администратор не несет ответственности за возможные последствия сообщения Пользователем данных своего\r\n                    аккаунта на Сайте (логина и пароля) третьим лицам.\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    Администратор не несет ответственности за возможные перебои и технические неполадки в работе Сайта,\r\n                    временную невозможность доступа к Сайту или его отдельным разделам и опциям, невозможность заказа товара\r\n                    в связи с его исключением из ассортимента Интернет-магазина либо снятия с производства производителем\r\n                    соответствующего товара.\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    В случае нарушения Пользователем условий использования Сайта, установленных настоящим Соглашением,\r\n                    Администратор оставляет за собой право без предварительного предупреждения удалить с Сайта аккаунт\r\n                    Пользователя. Удаление Администратором аккаунта Пользователя рассматривается как односторонний отказ\r\n                    Администратора от исполнения Соглашения и является основанием для прекращения действия Соглашения.\r\n                &lt;/li&gt;\r\n            &lt;/ol&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;p&gt;\r\n                Заключительные положения\r\n            &lt;/p&gt;\r\n\r\n            &lt;ol&gt;\r\n                &lt;li&gt;\r\n                    Выбирая опцию «Я принимаю условия Пользовательского соглашения», Пользователь присоединяется к\r\n                    настоящему Соглашению и принимает в качестве обязательных для себя все его условия.\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    Настоящее Соглашения вступает в силу с момента принятия Пользователем его условий (п. 5.1 Соглашения) и\r\n                    действует до момента удаления с Сайта аккаунта Пользователя либо до момента прекращения действия\r\n                    Соглашения по иным основаниям, предусмотренным действующим законодательством РФ.\r\n                &lt;/li&gt;\r\n                &lt;li&gt;\r\n                    Любые споры и разногласия, возникающие в связи с использованием Сайта, разрешаются сторонами путем\r\n                    направления друг другу претензионных писем. В случае неполучения ответа на претензию в разумный срок\r\n                    сторона, полагающая свои права и законные интересы нарушенными, может обратиться в суд по месту\r\n                    нахождения Администратора с соответствующими требованиями.\r\n                &lt;/li&gt;\r\n            &lt;/ol&gt;\r\n        &lt;/li&gt;\r\n    &lt;/ol&gt;', 'Пользовательское соглашение', '', '', '', '', '', ''),
(3, 2, 'Privacy Policy', '&lt;p&gt;\r\n	Privacy Policy&lt;/p&gt;\r\n', 'Privacy Policy', '', '', '', '', '', ''),
(6, 2, 'Delivery Information', '&lt;p&gt;\r\n	Delivery Information&lt;/p&gt;\r\n', 'Delivery Information', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_information_to_layout`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 07:01 AM
--

DROP TABLE IF EXISTS `oc_information_to_layout`;
CREATE TABLE `oc_information_to_layout` (
  `information_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_information_to_layout`
--

INSERT INTO `oc_information_to_layout` (`information_id`, `store_id`, `layout_id`) VALUES
(4, 0, 0),
(5, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_information_to_store`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 07:01 AM
--

DROP TABLE IF EXISTS `oc_information_to_store`;
CREATE TABLE `oc_information_to_store` (
  `information_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_information_to_store`
--

INSERT INTO `oc_information_to_store` (`information_id`, `store_id`) VALUES
(3, 0),
(4, 0),
(5, 0),
(6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_language`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:24 AM
--

DROP TABLE IF EXISTS `oc_language`;
CREATE TABLE `oc_language` (
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `code` varchar(5) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `image` varchar(64) NOT NULL,
  `directory` varchar(32) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_language`
--

INSERT INTO `oc_language` (`language_id`, `name`, `code`, `locale`, `image`, `directory`, `sort_order`, `status`) VALUES
(2, 'Русский', 'ru-ru', 'ru-RU,ru_RU.UTF-8,ru_RU,ru-ru,russian', '', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_layout`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 11:43 AM
--

DROP TABLE IF EXISTS `oc_layout`;
CREATE TABLE `oc_layout` (
  `layout_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_layout`
--

INSERT INTO `oc_layout` (`layout_id`, `name`) VALUES
(1, 'Home'),
(2, 'Product'),
(3, 'Category'),
(4, 'Default'),
(5, 'Manufacturer'),
(6, 'Account'),
(7, 'Checkout'),
(8, 'Contact'),
(9, 'Sitemap'),
(10, 'Affiliate'),
(11, 'Information'),
(12, 'Compare'),
(13, 'Search'),
(14, 'Custom Quick Checkout');

-- --------------------------------------------------------

--
-- Table structure for table `oc_layout_module`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 10:51 AM
--

DROP TABLE IF EXISTS `oc_layout_module`;
CREATE TABLE `oc_layout_module` (
  `layout_module_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `position` varchar(14) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_layout_module`
--

INSERT INTO `oc_layout_module` (`layout_module_id`, `layout_id`, `code`, `position`, `sort_order`) VALUES
(2, 4, '0', 'content_top', 0),
(3, 4, '0', 'content_top', 1),
(20, 5, '0', 'column_left', 2),
(69, 10, 'account', 'column_right', 1),
(68, 6, 'account', 'column_right', 1),
(67, 1, 'carousel.29', 'content_top', 3),
(66, 1, 'slideshow.27', 'content_top', 1),
(65, 1, 'featured.28', 'content_top', 2),
(75, 3, 'ocfilter', 'column_left', 2),
(74, 3, 'category', 'column_left', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_layout_route`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 11:43 AM
--

DROP TABLE IF EXISTS `oc_layout_route`;
CREATE TABLE `oc_layout_route` (
  `layout_route_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `route` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_layout_route`
--

INSERT INTO `oc_layout_route` (`layout_route_id`, `layout_id`, `store_id`, `route`) VALUES
(38, 6, 0, 'account/%'),
(17, 10, 0, 'affiliate/%'),
(54, 3, 0, 'product/category'),
(42, 1, 0, 'common/home'),
(20, 2, 0, 'product/product'),
(24, 11, 0, 'information/information'),
(23, 7, 0, 'checkout/%'),
(31, 8, 0, 'information/contact'),
(32, 9, 0, 'information/sitemap'),
(34, 4, 0, ''),
(45, 5, 0, 'product/manufacturer'),
(52, 12, 0, 'product/compare'),
(53, 13, 0, 'product/search'),
(55, 14, 0, 'extension/quickcheckout/checkout');

-- --------------------------------------------------------

--
-- Table structure for table `oc_length_class`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_length_class`;
CREATE TABLE `oc_length_class` (
  `length_class_id` int(11) NOT NULL,
  `value` decimal(15,8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_length_class`
--

INSERT INTO `oc_length_class` (`length_class_id`, `value`) VALUES
(1, '1.00000000'),
(2, '10.00000000'),
(3, '0.39370000');

-- --------------------------------------------------------

--
-- Table structure for table `oc_length_class_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:24 AM
--

DROP TABLE IF EXISTS `oc_length_class_description`;
CREATE TABLE `oc_length_class_description` (
  `length_class_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(32) NOT NULL,
  `unit` varchar(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_length_class_description`
--

INSERT INTO `oc_length_class_description` (`length_class_id`, `language_id`, `title`, `unit`) VALUES
(3, 1, 'Inch', 'in'),
(1, 2, 'Сантиметр', 'см'),
(2, 2, 'Миллиметр', 'мм'),
(3, 2, 'Inch', 'in');

-- --------------------------------------------------------

--
-- Table structure for table `oc_location`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_location`;
CREATE TABLE `oc_location` (
  `location_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `address` text NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `fax` varchar(32) NOT NULL,
  `geocode` varchar(32) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `open` text NOT NULL,
  `comment` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_manufacturer`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_manufacturer`;
CREATE TABLE `oc_manufacturer` (
  `manufacturer_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_manufacturer`
--

INSERT INTO `oc_manufacturer` (`manufacturer_id`, `name`, `image`, `sort_order`) VALUES
(5, 'HTC', 'catalog/demo/htc_logo.jpg', 0),
(6, 'Palm', 'catalog/demo/palm_logo.jpg', 0),
(7, 'Hewlett-Packard', 'catalog/demo/hp_logo.jpg', 0),
(8, 'Apple', 'catalog/demo/apple_logo.jpg', 0),
(9, 'Canon', 'catalog/demo/canon_logo.jpg', 0),
(10, 'Sony', 'catalog/demo/sony_logo.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_manufacturer_to_store`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_manufacturer_to_store`;
CREATE TABLE `oc_manufacturer_to_store` (
  `manufacturer_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_manufacturer_to_store`
--

INSERT INTO `oc_manufacturer_to_store` (`manufacturer_id`, `store_id`) VALUES
(5, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_marketing`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_marketing`;
CREATE TABLE `oc_marketing` (
  `marketing_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` text NOT NULL,
  `code` varchar(64) NOT NULL,
  `clicks` int(5) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_modification`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 05:23 PM
--

DROP TABLE IF EXISTS `oc_modification`;
CREATE TABLE `oc_modification` (
  `modification_id` int(11) NOT NULL,
  `extension_install_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `code` varchar(64) NOT NULL,
  `author` varchar(64) NOT NULL,
  `version` varchar(32) NOT NULL,
  `link` varchar(255) NOT NULL,
  `xml` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_modification`
--

INSERT INTO `oc_modification` (`modification_id`, `extension_install_id`, `name`, `code`, `author`, `version`, `link`, `xml`, `status`, `date_added`) VALUES
(1, 2, 'Localcopy OCMOD Install Fix', 'localcopy-oc3', 'opencart3x.ru', '1.0', 'https://opencart3x.ru', '<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<modification>\n  <name>Localcopy OCMOD Install Fix</name>\n  <code>localcopy-oc3</code>\n  <version>1.0</version>\n  <author>opencart3x.ru</author>\n  <link>https://opencart3x.ru</link>\n\n  <file path=\"admin/controller/marketplace/install.php\">\n	<operation>\n      <search>\n        <![CDATA[if ($safe) {]]>\n      </search>\n      <add position=\"before\">\n        <![CDATA[		\n		    $safe = true;\n		    ]]>\n      </add>\n    </operation>\n    <operation>\n      <search>\n        <![CDATA[if (is_dir($file) && !is_dir($path)) {]]>\n      </search>\n      <add position=\"before\">\n        <![CDATA[		\n			  if ($path == \'\') {\n  				$app_root = explode(\'/\',DIR_APPLICATION);\n  				unset($app_root[count($app_root)-2]);\n  				$app_root = implode(\'/\',$app_root);\n  				$path = $app_root . $destination;\n			  }\n		    ]]>\n      </add>\n    </operation>\n  </file> \n</modification>\n', 1, '2020-08-02 09:21:41'),
(2, 5, 'OCFilter Modification', 'ocfilter-product-filter', 'prowebber.ru', '4.7.5', 'https://prowebber.ru/', '<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<modification>\r\n  <name>OCFilter Modification</name>\r\n  <code>ocfilter-product-filter</code>\r\n  <version>4.7.5</version>\r\n  <author>prowebber.ru</author>\r\n  <link>https://prowebber.ru/</link>\r\n\r\n  <!-- CONTROLLER -->\r\n	<file path=\"admin/controller/catalog/product.php\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[function getForm() {]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n    // OCFilter start\r\n    $this->document->addStyle(\'view/stylesheet/ocfilter/ocfilter.css\');\r\n    $this->document->addScript(\'view/javascript/ocfilter/ocfilter.js\');\r\n    // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[$this->language->get(\'tab_general\');]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n    // OCFilter start\r\n    $data[\'tab_ocfilter\'] = $this->language->get(\'tab_ocfilter\');\r\n    $data[\'entry_values\'] = $this->language->get(\'entry_values\');\r\n    $data[\'ocfilter_select_category\'] = $this->language->get(\'ocfilter_select_category\');\r\n    // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n	<file path=\"admin/controller/common/column_left.php\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[if ($this->user->hasPermission(\'access\', \'catalog/filter\')) {]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n      // OCFilter start\r\n			$ocfilter = array();\r\n\r\n			if ($this->user->hasPermission(\'access\', \'extension/module/ocfilter\')) {\r\n				$ocfilter[] = array(\r\n					\'name\'     => $this->language->get(\'text_ocfilter_option\'),\r\n					\'href\'     => $this->url->link(\'extension/module/ocfilter/filter\', \'user_token=\' . $this->session->data[\'user_token\'], true),\r\n					\'children\' => array()\r\n				);\r\n			}\r\n\r\n			if ($this->user->hasPermission(\'access\', \'extension/module/ocfilter\')) {\r\n				$ocfilter[] = array(\r\n					\'name\'	   => $this->language->get(\'text_ocfilter_page\'),\r\n					\'href\'     => $this->url->link(\'extension/module/ocfilter/page\', \'user_token=\' . $this->session->data[\'user_token\'], true),\r\n					\'children\' => array()\r\n				);\r\n			}\r\n\r\n			if ($ocfilter) {\r\n				$catalog[] = array(\r\n					\'name\'	   => $this->language->get(\'text_ocfilter\'),\r\n					\'href\'     => \'\',\r\n					\'children\' => $ocfilter\r\n				);\r\n			}\r\n		  // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file><!-- /admin/controller/common/column_left.php -->\r\n  <!-- /CONTROLLER -->\r\n\r\n  <!-- LANGUAGE -->\r\n	<file path=\"admin/language/{en}*/catalog/product.php\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[$_[\'text_success\']]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n// OCFilter start\r\n$_[\'entry_values\']          		= \'Add the values ​​for this option.\';\r\n$_[\'tab_ocfilter\']          		= \'OCFilter Options\';\r\n$_[\'ocfilter_select_category\'] 	= \'To start, select a category for this product.\';\r\n// OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n	<file path=\"admin/language/{ru}*/catalog/product.php\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[$_[\'text_success\']]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n// OCFilter start\r\n$_[\'entry_values\']          		= \'Добавьте значения для этой опции.\';\r\n$_[\'tab_ocfilter\']          		= \'Опции фильтра\';\r\n$_[\'ocfilter_select_category\'] 	= \'Для начала, выберите категории для этого товара.\';\r\n// OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n	<file path=\"admin/language/{en}*/common/column_left.php\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[$_[\'text_option\']]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n// OCFilter start\r\n$_[\'text_ocfilter\']                    = \'OCFilter\';\r\n$_[\'text_ocfilter_option\']             = \'Filters\';\r\n$_[\'text_ocfilter_page\']               = \'SEO Pages\';\r\n$_[\'text_ocfilter_setting\']            = \'Settings\';\r\n// OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n	<file path=\"admin/language/{ru}*/common/column_left.php\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[$_[\'text_option\']]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n// OCFilter start\r\n$_[\'text_ocfilter\']                    = \'OCFilter\';\r\n$_[\'text_ocfilter_option\']             = \'Фильтры\';\r\n$_[\'text_ocfilter_page\']               = \'Страницы\';\r\n$_[\'text_ocfilter_setting\']            = \'Настройки\';\r\n// OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n  <!-- /LANGUAGE -->\r\n\r\n  <!-- MODEL -->\r\n	<file path=\"admin/model/catalog/product.php\">\r\n    <operation error=\"skip\">\r\n      <search index=\"0\"><![CDATA[if (isset($data[\'product_recurring\'])) {]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n    // OCFilter start\r\n		if (isset($data[\'ocfilter_product_option\'])) {\r\n			foreach ($data[\'ocfilter_product_option\'] as $option_id => $values) {\r\n				foreach ($values[\'values\'] as $value_id => $value) {\r\n					if (isset($value[\'selected\'])) {\r\n						$this->db->query(\"INSERT INTO \" . DB_PREFIX . \"ocfilter_option_value_to_product SET product_id = \'\" . (int)$product_id . \"\', option_id = \'\" . (int)$option_id . \"\', value_id = \'\" . (string)$value_id . \"\', slide_value_min = \'\" . (isset($value[\'slide_value_min\']) ? (float)$value[\'slide_value_min\'] : 0) . \"\', slide_value_max = \'\" . (isset($value[\'slide_value_max\']) ? (float)$value[\'slide_value_max\'] : 0) . \"\'\");\r\n					}\r\n				}\r\n			}\r\n		}\r\n		// OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n    <operation error=\"skip\">\r\n      <search index=\"1\"><![CDATA[if (isset($data[\'product_recurring\'])) {]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n    // OCFilter start\r\n    $this->db->query(\"DELETE FROM \" . DB_PREFIX . \"ocfilter_option_value_to_product WHERE product_id = \'\" . (int)$product_id . \"\'\");\r\n\r\n		if (isset($data[\'ocfilter_product_option\'])) {\r\n			foreach ($data[\'ocfilter_product_option\'] as $option_id => $values) {\r\n				foreach ($values[\'values\'] as $value_id => $value) {\r\n					if (isset($value[\'selected\'])) {\r\n						$this->db->query(\"INSERT INTO \" . DB_PREFIX . \"ocfilter_option_value_to_product SET product_id = \'\" . (int)$product_id . \"\', option_id = \'\" . (int)$option_id . \"\', value_id = \'\" . (string)$value_id . \"\', slide_value_min = \'\" . (isset($value[\'slide_value_min\']) ? (float)$value[\'slide_value_min\'] : 0) . \"\', slide_value_max = \'\" . (isset($value[\'slide_value_max\']) ? (float)$value[\'slide_value_max\'] : 0) . \"\'\");\r\n					}\r\n				}\r\n			}\r\n		}\r\n		// OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[$data[\'product_attribute\'] = $this->getProductAttributes($product_id);]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n 		// OCFilter start\r\n		$this->load->model(\'catalog/ocfilter\');\r\n\r\n		$data[\'ocfilter_product_option\'] = $this->model_catalog_ocfilter->getProductOCFilterValues($product_id);\r\n		// OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[$this->db->query(\"DELETE FROM \" . DB_PREFIX . \"product WHERE product_id = \'\" . (int)$product_id . \"\'\");]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n		// OCFilter start\r\n		$this->db->query(\"DELETE FROM \" . DB_PREFIX . \"ocfilter_option_value_to_product WHERE product_id = \'\" . (int)$product_id . \"\'\");\r\n		// OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file><!-- /admin/model/catalog/product.php -->\r\n\r\n  <!-- /MODEL -->\r\n\r\n  <!-- VIEW -->\r\n	<file path=\"admin/view/template/catalog/product_form.twig\">\r\n    <operation error=\"skip\">\r\n      <search index=\"0\"><![CDATA[</script></div>]]></search>\r\n      <add position=\"replace\"><![CDATA[\r\n  </script>\r\n  <!-- OCFilter start -->\r\n  <script type=\"text/javascript\"><!--\r\n  ocfilter.php = {\r\n  	text_select: \'{{ text_select }}\',\r\n  	ocfilter_select_category: \'{{ ocfilter_select_category }}\',\r\n  	entry_values: \'{{ entry_values }}\',\r\n  	tab_ocfilter: \'{{ tab_ocfilter }}\'\r\n  };\r\n\r\n  ocfilter.php.languages = [];\r\n\r\n  {% for language in languages %}\r\n  ocfilter.php.languages.push({\r\n  	\'language_id\': {{ language.language_id }},\r\n  	\'name\': \'{{ language.name }}\',\r\n    \'image\': \'{{ language.image }}\'\r\n  });\r\n  {% endfor %}\r\n  //--></script>\r\n  <!-- OCFilter end -->\r\n  </div>\r\n      ]]></add>\r\n    </operation>\r\n  </file><!-- /admin/view/template/catalog/product_form.twig -->\r\n  <!-- /VIEW -->\r\n\r\n  <!-- CATALOG -->\r\n\r\n  <file path=\"catalog/controller/startup/startup.php\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[Cart($this->registry));]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n		// OCFilter\r\n		$this->registry->set(\'ocfilter\', new OCFilter($this->registry));\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n	<file path=\"catalog/controller/startup/seo_url.php\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[$this->url->addRewrite($this);]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n      // OCFilter start\r\n      if ($this->registry->has(\'ocfilter\')) {\r\n  			$this->url->addRewrite($this->ocfilter);\r\n  		}\r\n      // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n	<file path=\"catalog/controller/{common,startup}/seo_pro.php\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[$this->url->addRewrite($this);]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n      // OCFilter start\r\n      if ($this->registry->has(\'ocfilter\')) {\r\n  			$this->url->addRewrite($this->ocfilter);\r\n  		}\r\n      // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n	<file path=\"catalog/controller/{common,startup}/seo_pro.php\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[$this->url->addRewrite($this, $lang_data);]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n      // OCFilter start\r\n      if ($this->registry->has(\'ocfilter\')) {\r\n  			$this->url->addRewrite($this->ocfilter);\r\n  		}\r\n      // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n	<file path=\"catalog/model/catalog/product.php\">\r\n    <operation error=\"abort\">\r\n      <search><![CDATA[$sql .= \" LEFT JOIN \" . DB_PREFIX . \"product_description]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n		// OCFilter start\r\n		if (!empty($data[\'filter_ocfilter\'])) {\r\n    	$this->load->model(\'extension/module/ocfilter\');\r\n\r\n      $ocfilter_product_sql = $this->model_extension_module_ocfilter->getSearchSQL($data[\'filter_ocfilter\']);\r\n		} else {\r\n      $ocfilter_product_sql = false;\r\n    }\r\n\r\n    if ($ocfilter_product_sql && $ocfilter_product_sql->join) {\r\n    	$sql .= $ocfilter_product_sql->join;\r\n    }\r\n    // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n\r\n    <operation error=\"abort\">\r\n      <search><![CDATA[if (!empty($data[\'filter_manufacturer_id]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n    // OCFilter start\r\n    if (!empty($ocfilter_product_sql) && $ocfilter_product_sql->where) {\r\n    	$sql .= $ocfilter_product_sql->where;\r\n    }\r\n    // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n	<file path=\"catalog/controller/product/category.php\">\r\n    <operation error=\"abort\">\r\n      <search index=\"0\"><![CDATA[$data[\'breadcrumbs\'] = array();]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n		// OCFilter start\r\n    if (isset($this->request->get[\'filter_ocfilter\'])) {\r\n      $filter_ocfilter = $this->request->get[\'filter_ocfilter\'];\r\n    } else {\r\n      $filter_ocfilter = \'\';\r\n    }\r\n		// OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n\r\n    <!-- Filter params to product model -->\r\n\r\n    <operation error=\"abort\">\r\n      <search><![CDATA[$product_total =]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n  		// OCFilter start\r\n  		$filter_data[\'filter_ocfilter\'] = $filter_ocfilter;\r\n  		// OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n\r\n    <!-- Add url -->\r\n\r\n    <operation error=\"skip\">\r\n      <search index=\"2\"><![CDATA[if (isset($this->request->get[\'filter\'])) {]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n      // OCFilter start\r\n			if (isset($this->request->get[\'filter_ocfilter\'])) {\r\n				$url .= \'&filter_ocfilter=\' . $this->request->get[\'filter_ocfilter\'];\r\n			}\r\n      // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n\r\n    <operation error=\"skip\">\r\n      <search index=\"3\"><![CDATA[if (isset($this->request->get[\'filter\'])) {]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n      // OCFilter start\r\n			if (isset($this->request->get[\'filter_ocfilter\'])) {\r\n				$url .= \'&filter_ocfilter=\' . $this->request->get[\'filter_ocfilter\'];\r\n			}\r\n      // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n\r\n    <operation error=\"skip\">\r\n      <search index=\"4\"><![CDATA[if (isset($this->request->get[\'filter\'])) {]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n      // OCFilter start\r\n			if (isset($this->request->get[\'filter_ocfilter\'])) {\r\n				$url .= \'&filter_ocfilter=\' . $this->request->get[\'filter_ocfilter\'];\r\n			}\r\n      // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n\r\n    <operation error=\"skip\">\r\n      <search limit=\"1\"><![CDATA[$data[\'limit\'] = $limit;]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n      // OCFilter Start\r\n      if ($this->ocfilter->getParams()) {\r\n        if (isset($product_total) && !$product_total) {\r\n      	  $this->response->redirect($this->url->link(\'product/category\', \'path=\' . $this->request->get[\'path\']));\r\n        }\r\n\r\n        $this->document->setTitle($this->ocfilter->getPageMetaTitle($this->document->getTitle()));\r\n			  $this->document->setDescription($this->ocfilter->getPageMetaDescription($this->document->getDescription()));\r\n        $this->document->setKeywords($this->ocfilter->getPageMetaKeywords($this->document->getKeywords()));\r\n\r\n        $data[\'heading_title\'] = $this->ocfilter->getPageHeadingTitle($data[\'heading_title\']);\r\n        $data[\'description\'] = $this->ocfilter->getPageDescription();\r\n\r\n        if (!trim(strip_tags(html_entity_decode($data[\'description\'], ENT_QUOTES, \'UTF-8\')))) {\r\n        	$data[\'thumb\'] = \'\';\r\n        }\r\n\r\n        $breadcrumb = $this->ocfilter->getPageBreadCrumb();\r\n\r\n        if ($breadcrumb) {\r\n  			  $data[\'breadcrumbs\'][] = $breadcrumb;\r\n        }\r\n\r\n        $this->document->deleteLink(\'canonical\');\r\n      }\r\n      // OCFilter End\r\n      ]]></add>\r\n    </operation>\r\n  </file><!-- /catalog/controller/product/category.php -->\r\n\r\n  <!-- Document Noindex & Canonical -->\r\n\r\n	<file path=\"system/library/document.php\">\r\n    <operation error=\"abort\">\r\n      <search index=\"0\"><![CDATA[public function getLinks]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n  // OCFilter canonical fix start\r\n	public function deleteLink($rel) {\r\n    foreach ($this->links as $href => $link) {\r\n      if ($link[\'rel\'] == $rel) {\r\n      	unset($this->links[$href]);\r\n      }\r\n    }\r\n	}\r\n  // OCFilter canonical fix end\r\n      ]]></add>\r\n    </operation>\r\n\r\n    <operation error=\"abort\">\r\n      <search><![CDATA[private $keywords;]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n  // OCFilter start\r\n  private $noindex = false;\r\n  // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n\r\n    <operation error=\"abort\">\r\n      <search><![CDATA[public function setTitle($title) {]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n  // OCFilter start\r\n  public function setNoindex($state = false) {\r\n  	$this->noindex = $state;\r\n  }\r\n\r\n	public function isNoindex() {\r\n		return $this->noindex;\r\n	}\r\n  // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n	<file path=\"catalog/controller/common/header.php\">\r\n    <operation error=\"abort\">\r\n      <search><![CDATA[$data[\'scripts\'] = $this->document->getScripts]]></search>\r\n      <add position=\"before\"><![CDATA[\r\n    // OCFilter start\r\n    $data[\'noindex\'] = $this->document->isNoindex();\r\n    // OCFilter end\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n\r\n  <file path=\"catalog/view/theme/*/template/common/header.twig\">\r\n    <operation error=\"skip\">\r\n      <search><![CDATA[</title>]]></search>\r\n      <add position=\"after\"><![CDATA[\r\n{% if noindex %}\r\n<!-- OCFilter Start -->\r\n<meta name=\"robots\" content=\"noindex,nofollow\" />\r\n<!-- OCFilter End -->\r\n{% endif %}\r\n      ]]></add>\r\n    </operation>\r\n  </file>\r\n</modification>', 1, '2020-08-02 13:48:51'),
(3, 6, 'Упрощенный заказ [Custom Quick Checkout]', 'quickcheckout_oc3', 'opencart3x.ru', '1.9', 'https://opencart3x.ru', '<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<modification>\n	<name>Упрощенный заказ [Custom Quick Checkout]</name>\n	<code>quickcheckout_oc3</code>\n	<version>1.9</version>\n	<author>opencart3x.ru</author>\n	<link>https://opencart3x.ru</link>\n	<file path=\"catalog/controller/checkout/cart.php\">\n		<operation>\n			<search><![CDATA[public function index() {]]></search>\n			<add position=\"after\"><![CDATA[		\n			if ($this->cart->hasProducts() && $this->config->get(\'quickcheckout_skip_cart\')){\n				$this->response->redirect($this->url->link(\'extension/quickcheckout/checkout\'));\n			}\n            ]]></add>\n		</operation>\n	</file>\n  	<file path=\"catalog/model/setting/extension.php\">\n		<operation>\n			<search trim=\"true\" index=\"0\"><![CDATA[\n				SELECT * FROM \" . DB_PREFIX . \"extension WHERE `type` =\n			]]></search>\n			<add position=\"after\" trim=\"false\" offset=\"0\"><![CDATA[\n				if ($type == \'payment\' && isset($this->session->data[\'shipping_method\'][\'code\']) && $this->config->get(\'quickcheckout_shipping_reload\')) {\n					$payments = $query->rows;\n\n					$rules = array();\n\n					foreach ($this->config->get(\'quickcheckout_payment2shipping_shippings\') as $shippings) {\n						if (strpos($this->session->data[\'shipping_method\'][\'code\'], $shippings[\'shipping\']) === 0) {\n							$rules[] = $shippings[\'payment\'];\n						}\n					}\n\n					if (!empty($rules)) {\n						foreach ($payments as $idx => $payment) {\n							if (!in_array($payment[\'code\'], $rules)) {\n								unset($payments[$idx]);\n							}\n						}\n\n						$query->rows = $payments;\n					}\n\n					//echo \'<pre>\'.__METHOD__.\' [\'.__LINE__.\']: \'; print_r($rules); echo \'</pre>\';\n					//echo \'<pre>\'.__METHOD__.\' [\'.__LINE__.\']: \'; print_r($this->session->data[\'shipping_method\']); echo \'</pre>\';\n					//echo \'<pre>\'.__METHOD__.\' [\'.__LINE__.\']: \'; print_r($query->rows); echo \'</pre>\';\n				}\n			]]></add>\n		</operation>\n	</file>\n</modification>', 1, '2020-08-02 14:43:19');
INSERT INTO `oc_modification` (`modification_id`, `extension_install_id`, `name`, `code`, `author`, `version`, `link`, `xml`, `status`, `date_added`) VALUES
(6, 9, 'Y.CMS for Opencart 3.x', 'ycms.2.0', 'Yandex.Money', '1.6.1', '', '<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<modification>\r\n    <name>Y.CMS for Opencart 3.x</name>\r\n    <code>ycms.2.0</code>\r\n    <version>1.6.1</version>\r\n    <author>Yandex.Money</author>\r\n    <!-- Вставка кнопки в историю заказов-->\r\n    <file path=\"catalog/controller/account/order.php\">\r\n        <operation error=\"skip\">\r\n            <search><![CDATA[// History]]></search>\r\n            <add position=\"before\"><![CDATA[\r\n            $this->language->load(\'extension/payment/yandex_money\');\r\n            $data[\'heading_title\'] = $this->language->get(\'text_order\');\r\n            if ($order_info[\'payment_method\'] == $this->language->get(\'kassa_title\') || $order_info[\'payment_method\'] == $this->language->get(\'p2p_title\')) {\r\n               $this->session->data[\'order_id\'] = $this->request->get[\'order_id\'];\r\n               $data[\'yandex_money\'] = $this->load->controller(\'extension/payment/yandex_money\');\r\n            }]]></add>\r\n        </operation>\r\n    </file>\r\n    <file path=\"catalog/view/theme/*/template/account/order_info.twig\">\r\n        <operation error=\"skip\">\r\n            <search><![CDATA[</tfoot>]]></search>\r\n            <add position=\"before\"><![CDATA[\r\n            {% if yandex_money is defined and yandex_money %}\r\n            <tr>\r\n                <td colspan=\"{{ products ? \'6\' : \'5\' }}\">{{ yandex_money }}</td>\r\n            </tr>\r\n            {% endif %}\r\n        ]]></add>\r\n        </operation>\r\n    </file>\r\n    <!-- загружаем вместе с заказами код способа оплаты -->\r\n    <file path=\"admin/model/sale/order.php\">\r\n        <operation error=\"skip\">\r\n            <search regex=\"true\"><![CDATA[~o.date_added, o.date_modified FROM~]]></search>\r\n            <add><![CDATA[o.date_added, o.date_modified, o.payment_code, o.email, o.order_status_id FROM]]></add>\r\n        </operation>\r\n        <operation error=\"skip\">\r\n            <search regex=\"true\"><![CDATA[/\\$query\\s=\\s\\$this->db->query\\(\\$sql\\);\\s+return\\s\\$query->rows;/]]></search>\r\n            <add><![CDATA[\r\n        $query = $this->db->query($sql);\r\n\r\n        $result = array();\r\n        $orderIds = array();\r\n        foreach ($query->rows as $record) {\r\n            if ($record[\'payment_code\'] === \'yandex_money\') {\r\n                $orderIds[] = $record[\'order_id\'];\r\n            }\r\n            $result[$record[\'order_id\']] = $record;\r\n        }\r\n        if (!empty($orderIds)) {\r\n            $sql = \'SELECT `order_id`, `payment_id`, `status` FROM `\' . DB_PREFIX . \'ya_money_payment` WHERE `order_id` IN (\' . implode(\',\', $orderIds) . \')\';\r\n            $recordSet = $this->db->query($sql);\r\n            foreach ($recordSet->rows as $record) {\r\n                $result[$record[\'order_id\']][\'yandex_money_payment_id\'] = $record[\'payment_id\'];\r\n                $result[$record[\'order_id\']][\'yandex_money_payment_status\'] = $record[\'status\'];\r\n            }\r\n            $sql = \'SELECT `order_id`, `refund_id`, `status`, `amount` FROM `\' . DB_PREFIX . \'ya_money_refunds` WHERE `order_id` IN (\' . implode(\',\', $orderIds) . \') AND `status` <> \\\'canceled\\\'\';\r\n            $recordSet = $this->db->query($sql);\r\n            foreach ($recordSet->rows as $record) {\r\n                if (!isset($result[$record[\'order_id\']][\'refund_amount\'])) {\r\n                    $result[$record[\'order_id\']][\'refund_amount\'] = 0;\r\n                }\r\n                $result[$record[\'order_id\']][\'refund_amount\'] += $record[\'amount\'];\r\n            }\r\n        }\r\n\r\n        return array_values($result);\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <file path=\"admin/language/{english,russian,en-gb,ru-ru}/sale/order.php\">\r\n        <operation error=\"skip\">\r\n            <search regex=\"true\"><![CDATA[~(\\$_\\[\\\'text_add\\\'\\])~]]></search>\r\n            <add><![CDATA[\r\n                $_[\'button_invoice_kassa\'] = \'Выставление счета\';\r\n                $_[\'text_add\']\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <file path=\"system/library/mail.php\">\r\n        <operation error=\"skip\">\r\n            <search><![CDATA[basename(urlencode($attachment))]]></search>\r\n            <add><![CDATA[urlencode(basename($attachment))]]></add>\r\n        </operation>\r\n    </file>\r\n    <!-- -->\r\n    <file path=\"admin/controller/sale/order.php\">\r\n        <operation error=\"skip\">\r\n            <search><![CDATA[\'shipping_code\' => $result[\'shipping_code\'],]]></search>\r\n            <add position=\"after\"><![CDATA[\r\n                \'payment_code\'   => (isset($result[\'payment_code\']) && $this->config->get(\'yandex_money_kassa_enabled\') && $this->config->get(\'yandex_money_kassa_invoice\') && $result[\'order_status_id\'] == 1) ? $result[\'payment_code\'] : \'\',\r\n                \'payment_status\' => (isset($result[\'yandex_money_payment_status\']) ? $result[\'yandex_money_payment_status\'] : \'\'),\r\n                \'email\'          => (isset($result[\'email\']) && $this->config->get(\'yandex_money_kassa_enabled\')) ? $result[\'email\'] : \'\',\r\n                \'refund_amount\'  => (isset($result[\'refund_amount\']) ? $result[\'refund_amount\'] : \'\'),\r\n                \'refund_url\'     => (isset($result[\'payment_code\']) && $result[\'payment_code\'] == \'yandex_money\') ? $this->url->link(\'extension/payment/yandex_money/refund\', \'order_id=\'.$result[\'order_id\'].\'&user_token=\'.$this->session->data[\'user_token\'], true) : \'\',\r\n                \'capture_url\'    => (isset($result[\'payment_code\']) && $result[\'payment_code\'] == \'yandex_money\') ? $this->url->link(\'extension/payment/yandex_money/capture\', \'order_id=\'.$result[\'order_id\'].\'&user_token=\'.$this->session->data[\'user_token\'], true) : \'\',\r\n            ]]></add>\r\n        </operation>\r\n        <operation error=\"skip\">\r\n            <search><![CDATA[$data[\'user_token\'] = $this->session->data[\'user_token\'];]]></search>\r\n            <add position=\"after\"><![CDATA[\r\n        if ($this->config->get(\'yandex_money_kassa_enabled\')) {\r\n            $data[\'button_invoice_kassa\'] = $this->language->get(\'button_invoice_kassa\');\r\n            $data[\'store_url\'] = $this->request->server[\'HTTPS\'] ? HTTPS_CATALOG : HTTP_CATALOG;\r\n        }\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <file path=\"admin/view/template/sale/order_list.twig\">\r\n        <operation error=\"skip\">\r\n            <search>\r\n                <![CDATA[<li><a href=\"{{ order.edit }}\"><i class=\"fa fa-pencil\"></i> {{ button_edit }}</a></li>]]></search>\r\n            <add position=\"after\"><![CDATA[\r\n                {% if order.payment_code is defined and order.payment_code == \'yandex_money\' %}\r\n                    <li><a href=\"javascript://\" class=\"invoice-button\" data-order_id=\"{{ order.order_id }}\" data-customer=\"{{ order.customer }}\" data-email=\"{{ order.email }}\"><i class=\"fa fa-envelope\"></i> Выставить счёт</a></li>\r\n                {% endif %}\r\n                {% if order.payment_status is defined and order.payment_status == \'succeeded\' %}\r\n                    <li><a href=\"{{ order.refund_url }}\"><i class=\"fa fa-repeat\"></i> Возвраты</a></li>\r\n                {% endif %}\r\n                {% if order.payment_status is defined and order.payment_status == \'waiting_for_capture\' %}\r\n                    <li><a href=\"{{ order.capture_url }}\"><i class=\"fa fa-check\"></i> Подтверждение платежа</a></li>\r\n                {% endif %}\r\n            ]]></add>\r\n        </operation>\r\n        <operation error=\"skip\">\r\n            <search><![CDATA[$(\'input[name^=\\\'selected\\\']:first\').trigger(\'change\');]]></search>\r\n            <add position=\"after\"><![CDATA[//\r\n            jQuery(\'.invoice-button\').click(function(e) {\r\n                var node = this;\r\n                var text = \'Вы действительно хотите отправить счёт пользователю \' + node.dataset.customer + \' на адрес \' + node.dataset.email + \'?\';\r\n                if (confirm(text)) {\r\n                    jQuery.ajax({\r\n                        url: \'{{ store_url }}admin/index.php?route=extension/payment/yandex_money/sendmail&user_token={{ user_token }}&order_id=\' + node.dataset.order_id,\r\n                        dataType: \'json\',\r\n                        crossDomain: true,\r\n                        beforeSend: function() {\r\n                            jQuery(node).button(\'loading\');\r\n                        },\r\n                        complete: function() {\r\n                            jQuery(node).button(\'reset\');\r\n                        },\r\n                        success: function(json_main) {\r\n                            jQuery(\'.alert\').remove();\r\n                            if (json_main[\'error\']) {\r\n                                $(\'#content > .container-fluid\').prepend(\'<div class=\"alert alert-danger\"><i class=\"fa fa-exclamation-circle\"></i> \' + json_main[\'error\'] + \' <button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>\');\r\n                            }\r\n                            if (json_main[\'success\']) {\r\n                                $(\'#content > .container-fluid\').prepend(\'<div class=\"alert alert-success\"><i class=\"fa fa-check-circle\"></i> \' + json_main[\'success\'] + \' <button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>\');\r\n                                var token = \'\';\r\n                                $.ajax({\r\n                                    url: \'{{ store_url }}index.php?route=api/login\',\r\n                                    type: \'post\',\r\n                                    data: \'key={{ api_key }}\',\r\n                                    dataType: \'json\',\r\n                                    crossDomain: true,\r\n                                    success: function(json) {\r\n                                        if (json[\'error\']) {\r\n                                            if (json[\'error\'][\'key\']) {\r\n                                                $(\'#content > .container-fluid\').prepend(\'<div class=\"alert alert-danger\"><i class=\"fa fa-exclamation-circle\"></i> \' + json[\'error\'][\'key\'] + \' <button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>\');\r\n                                            }\r\n                                            if (json[\'error\'][\'ip\']) {\r\n                                                $(\'#content > .container-fluid\').prepend(\'<div class=\"alert alert-danger\"><i class=\"fa fa-exclamation-circle\"></i> \' + json[\'error\'][\'ip\'] + \' <button type=\"button\" id=\"button-ip-add\" data-loading-text=\"{{ text_loading }}\" class=\"btn btn-danger btn-xs pull-right\"><i class=\"fa fa-plus\"></i> {{ button_ip_add }}</button></div>\');\r\n                                            }\r\n                                        }\r\n                                        if (json[\'token\']) {\r\n                                            token = json[\'token\'];\r\n                                            $.ajax({\r\n                                                url: \'{{ store_url }}index.php?route=api/order/history&user_token=\'+ token +\'&order_id=\' + $(node).val(),\r\n                                                type: \'post\',\r\n                                                data: \'order_status_id=1&notify=0&override=0&append=0&comment=\'+json_main[\'success\'],\r\n                                                dataType: \'json\',\r\n                                                error: function(xhr, ajaxOptions, thrownError) {\r\n                                                    alert(thrownError + \" \" + xhr.statusText + \" \" + xhr.responseText);\r\n                                                }\r\n                                            });\r\n                                        }\r\n                                    },\r\n                                    error: function(xhr, ajaxOptions, thrownError) {\r\n                                        alert(thrownError + \" \" + xhr.statusText + \" \" + xhr.responseText);\r\n                                    }\r\n                                });\r\n                            }\r\n                        },\r\n                        error: function(xhr, ajaxOptions, thrownError) {\r\n                            alert(thrownError + \" \" + xhr.statusText + \" \" + xhr.responseText);\r\n                        }\r\n                    });\r\n                }\r\n            });\r\n            //\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <file path=\"catalog/controller/common/footer.php\">\r\n        <operation error=\"skip\">\r\n            <search><![CDATA[$data[\'newsletter\'] = $this->url->link(\'account/newsletter\']]></search>\r\n            <add position=\"after\"><![CDATA[\r\n            $data[\'yandex_metrika_html_code\'] = $this->config->get(\'yandex_money_metrika_active\') && $this->config->get(\'yandex_money_metrika_code\')\r\n                ? html_entity_decode($this->config->get(\'yandex_money_metrika_code\'), ENT_QUOTES, \'UTF-8\')\r\n                : \'\';\r\n            $data[\'yandex_money_kassa_show_in_footer\'] = $this->config->get(\'yandex_money_kassa_enabled\') && $this->config->get(\'yandex_money_kassa_show_in_footer\');\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <file path=\"catalog/controller/checkout/success.php\">\r\n        <operation>\r\n            <search><![CDATA[if (isset($this->session->data[\'order_id\'])) {]]></search>\r\n            <add position=\"after\"><![CDATA[\r\n                $this->load->model(\'extension/payment/yandex_money\');\r\n                $data[\'script_order\'] = $this->model_extension_payment_yandex_money->getMetricsJavaScript($this->session->data[\'order_id\']);\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <file path=\"catalog/view/theme/*/template/common/success.twig\">\r\n        <operation>\r\n            <search position=\"replace\"><![CDATA[{{ footer }}]]></search>\r\n            <add><![CDATA[\r\n            {% if script_order is defined %}\r\n            {{ script_order }}\r\n            {% endif %}\r\n            {{ footer }}\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <file path=\"catalog/view/theme/*/template/common/footer.twig\">\r\n        <operation>\r\n            <search><![CDATA[<footer]]></search>\r\n            <add position=\"before\"><![CDATA[\r\n            {{ yandex_metrika_html_code }}\r\n            <script type=\"text/javascript\">\r\n                window.dataLayer = window.dataLayer || [];\r\n                function sendEcommerceAdd(id, quantity) {\r\n                   $.ajax({\r\n                        url: \'index.php?route=extension/payment/yandex_money/productInfo\',\r\n                        type: \'post\',\r\n                        data: \'id=\' + id,\r\n                        dataType: \'json\',\r\n                        success: function(json) {\r\n                            json.quantity = quantity;\r\n                            dataLayer.push({ecommerce: {add: {products: [json]}}});\r\n                        }\r\n                    });\r\n                }\r\n                $(window).on(\"load\", function () {\r\n                    var opencartCartAdd = cart.add;\r\n                    cart.add = function (product_id, quantity) {\r\n                        opencartCartAdd(product_id, quantity);\r\n                        sendEcommerceAdd(product_id, typeof(quantity) !== \'undefined\' ? parseInt(quantity) : 1);\r\n                    };\r\n\r\n                    $(\'#button-cart\').on(\'click\', function() {\r\n                        var ecommerce_product = new Array();\r\n                        sendEcommerceAdd($(\'#product input[name=\"product_id\"]\').val(), parseInt($(\'#product input[name=\"quantity\"]\').val()));\r\n                    });\r\n                });\r\n            </script>\r\n            ]]></add>\r\n        </operation>\r\n        <operation>\r\n            <search><![CDATA[<p>{{ powered }}</p>]]></search>\r\n            <add position=\"after\"><![CDATA[\r\n            {% if yandex_money_kassa_show_in_footer is defined and yandex_money_kassa_show_in_footer %}\r\n            <p><a href=\"https://kassa.yandex.ru/?_openstat=promo;merchants;opencart2\">Работает Яндекс.Касса</a></p>\r\n            {% endif %}\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <!-- Проброс конфига в шаблон header -->\r\n    <file path=\"catalog/controller/common/header.php\" error=\"skip\">\r\n        <operation>\r\n            <search><![CDATA[$data[\'menu\'] = $this->load->controller(\'common/menu\');]]></search>\r\n            <add position=\"after\"><![CDATA[\r\n                $data[\'config\'] = $this->config;\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <!-- Вставка скрипта кнопки \"Заплатить по частям\" -->\r\n    <file path=\"catalog/view/theme/*/template/common/header.twig\" error=\"skip\">\r\n        <operation>\r\n            <search><![CDATA[</head>]]></search>\r\n            <add position=\"before\"><![CDATA[\r\n                {% if config is defined and config.get(\'yandex_money_kassa_enabled\') and (config.get(\'yandex_money_kassa_use_installments_button\') or config.get(\'yandex_money_kassa_add_installments_block\')) %}\r\n                <script src=\"https://static.yandex.net/kassa/pay-in-parts/ui/v1/\"></script>\r\n                {% endif %}\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <!-- Получение данных для виджета \"Заплатить по частям\" -->\r\n    <file path=\"catalog/controller/product/product.php\" error=\"skip\">\r\n        <operation>\r\n            <search trim=\"true\"><![CDATA[if ($product_info) {]]></search>\r\n            <add position=\"after\"><![CDATA[\r\n                $showInstallmentsBlock = $this->config->get(\'yandex_money_kassa_enabled\')\r\n                    && $this->config->get(\'yandex_money_kassa_add_installments_block\');\r\n\r\n                $data[\'yamoney_showInstallmentsBlock\'] = $showInstallmentsBlock;\r\n                $data[\'yamoney_shop_id\'] = $this->config->get(\'yandex_money_kassa_shop_id\');\r\n                $data[\'yamoney_language_code\'] = $this->language->get(\'code\');\r\n\r\n                $data[\'ymm_option\'][\'color_enabled\'] = $this->config->get(\'yandex_money_market_option_color_enabled\');\r\n                $data[\'ymm_option\'][\'size_enabled\'] = $this->config->get(\'yandex_money_market_option_size_enabled\');\r\n                $color_option = $this->config->get(\'yandex_money_market_option_color_option_id\');\r\n                $data[\'ymm_option\'][\'color\'] = !empty($color_option) ? $color_option : \'-\';\r\n                $size_option = $this->config->get(\'yandex_money_market_option_size_option_id\');\r\n                $data[\'ymm_option\'][\'size\'] = !empty($size_option) ? $size_option : \'-\';\r\n            ]]></add>\r\n        </operation>\r\n        <operation>\r\n            <search trim=\"true\">\r\n                <![CDATA[$data[\'price\'] = $this->currency->format($this->tax->calculate($product_info[\'price\'], $product_info[\'tax_class_id\'], $this->config->get(\'config_tax\')), $this->session->data[\'currency\']);]]></search>\r\n            <add position=\"after\"><![CDATA[\r\n                $cost = $this->tax->calculate($product_info[\'price\'], $product_info[\'tax_class_id\'], $this->config->get(\'config_tax\'));\r\n                if ($this->currency->has(\'RUB\')) {\r\n                    $data[\'cost\'] = sprintf(\'%.2f\', $this->currency->format($cost, \'RUB\', \'\', false));\r\n                } else {\r\n                    $data[\'cost\'] = $this->getModel()->convertFromCbrf(array(\'total\' => $cost), \'RUB\');\r\n                }\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <!-- Отображение виджета \"Заплатить по частям\" -->\r\n    <file path=\"catalog/view/theme/*/template/product/product.twig\" error=\"skip\">\r\n        <operation error=\"skip\" info=\"Product installments\">\r\n            <search><![CDATA[<div id=\"product\"> {% if options %}]]></search>\r\n            <add position=\"before\"><![CDATA[\r\n                {% if yamoney_showInstallmentsBlock %}\r\n                    <ul class=\"list-unstyled\"><li class=\"installments-info\"></li></ul>\r\n                {% endif %}\r\n            ]]></add>\r\n        </operation>\r\n        <operation error=\"skip\" info=\"Product footer\">\r\n            <search><![CDATA[{{ footer }}]]></search>\r\n            <add position=\"before\"><![CDATA[\r\n                <script>\r\n                    {% if yamoney_showInstallmentsBlock %}\r\n                        if (typeof YandexCheckoutCreditUI !== \"undefined\") {\r\n                            const yamoneyCheckoutCreditUI = YandexCheckoutCreditUI({\r\n                                shopId: \'{{ yamoney_shop_id }}\',\r\n                                sum: parseFloat(\'{{ cost }}\'),\r\n                                language: \'{{ yamoney_language_code }}\'\r\n                            });\r\n                            yamoneyCheckoutCreditUI({\r\n                                type: \'info\',\r\n                                domSelector: \'.installments-info\'\r\n                            });\r\n                        }\r\n                    {% endif %}\r\n                    $(window).on(\"load\", function () {\r\n                        window.dataLayer = window.dataLayer || [];\r\n                        dataLayer.push({ecommerce: {detail: {products: [{\r\n                            id: \"{{ product_id }}\",\r\n                            name: \"{{ heading_title }}\",\r\n                            price: parseFloat(\'0\'+\'{{ price|striptags }}\'),\r\n                            brand: \"{{ manufacturer }}\",\r\n                            variant: \"{{ model }}\"\r\n                        }]}}});\r\n                    });\r\n                </script>\r\n            ]]></add>\r\n        </operation>\r\n        <operation error=\"skip\" info=\"Product select[data-option]\">\r\n            <search position=\"replace\"><![CDATA[<select name=\"option[{{ option.product_option_id }}]\" id=\"input-option{{ option.product_option_id }}\" class=\"form-control\">]]></search>\r\n            <add><![CDATA[<select name=\"option[{{ option.product_option_id }}]\" id=\"input-option{{ option.product_option_id }}\" data-option=\"{{ option.option_id }}\" class=\"form-control\">]]></add>\r\n        </operation>\r\n        <operation error=\"skip\" info=\"Product div[data-option]\">\r\n            <search position=\"replace\"><![CDATA[<div id=\"input-option{{ option.product_option_id }}\"> {% for option_value in option.product_option_value %}]]></search>\r\n            <add><![CDATA[<div id=\"input-option{{ option.product_option_id }}\" data-option=\"{{ option.option_id }}\"> {% for option_value in option.product_option_value %}]]></add>\r\n        </operation>\r\n        <operation error=\"skip\" info=\"Product Color and Size\">\r\n            <search index=\"0\"><![CDATA[$(document).ready(function() {]]></search>\r\n            <add position=\"after\"><![CDATA[\r\n    var op = { color: \'{{ ymm_option.color }}\', size: \'{{ ymm_option.size }}\' };\r\n    var h = location.hash.replace(\'#\', \'\');\r\n    var color_size = h.split(\'-\');\r\n    setTimeout(function(){\r\n        $(\'[data-option=\"\' + op.color + \'\"], \' + \'[data-option=\"\' + op.size + \'\"]\' ).each(function(i, input) {\r\n            var tag = $(input).prop(\'tagName\');\r\n            $(color_size).each(function(j, el) {\r\n                if (tag == \'SELECT\') {\r\n                    var opt = $(input).find(\'option[value=\"\'+el+\'\"]\');\r\n                    if (opt.length) {\r\n                        opt.attr(\'selected\', \'true\');\r\n                        $(input).trigger(\'change\');\r\n                    }\r\n                } else if (tag == \'DIV\') {\r\n                    var opt = $(input).find(\'input[value=\"\'+el+\'\"]\');\r\n                    if (opt.length) {\r\n                        opt.prop(\'checked\', \'true\');\r\n                        $(opt).trigger(\'click\');\r\n                    }\r\n                }\r\n            });\r\n        });\r\n    }, 500);\r\n\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n    <file path=\"admin/view/template/catalog/product_form.twig\" error=\"skip\">\r\n        <operation error=\"skip\" info=\"Add Product Properties\">\r\n            <search position=\"after\"><![CDATA[<input type=\"text\" name=\"sort_order\" value=\"{{ sort_order }}\" placeholder=\"{{ entry_sort_order }}\" id=\"input-sort-order\" class=\"form-control\" />]]></search>\r\n            <add><![CDATA[\r\n                    <input type=\"text\" name=\"sort_order\" value=\"{{ sort_order }}\" placeholder=\"{{ entry_sort_order }}\" id=\"input-sort-order\" class=\"form-control\" />\r\n                 </div>\r\n              </div>\r\n              <div class=\"form-group\">\r\n                <label class=\"col-sm-2 control-label\" for=\"input-ym_payment_mode\"><span data-toggle=\"tooltip\" title=\"\">Признак способа расчета</span></label>\r\n                <div class=\"col-sm-10\">\r\n                  <select name=\"ym_payment_mode\" id=\"ym_payment_mode\" class=\"form-control\">\r\n\r\n                    {% for pmValue,pmTitle in paymentModeEnum %}\r\n\r\n                    <option value=\"{{ pmValue }}\" {{ product_ym_payment_mode == pmValue ? \' selected\' : \'\' }}>{{ pmTitle }}</option>\r\n\r\n                    {% endfor %}\r\n\r\n                  </select>\r\n                </div>\r\n              </div>\r\n              <div class=\"form-group\">\r\n                <label class=\"col-sm-2 control-label\" for=\"ym_payment_subject\"><span data-toggle=\"tooltip\" title=\"\">Признак предмета расчета</span></label>\r\n                <div class=\"col-sm-10\">\r\n                  <select name=\"ym_payment_subject\" id=\"ym_payment_subject\" class=\"form-control\">\r\n\r\n                    {% for psValue,psTitle in paymentSubjectEnum %}\r\n\r\n                    <option value=\"{{ psValue }}\" {{ product_ym_payment_subject == psValue ? \' selected\' : \'\' }}>{{ psTitle }}</option>\r\n\r\n                    {% endfor %}\r\n\r\n                  </select>\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n\r\n    <file path=\"admin/controller/catalog/product.php\" error=\"skip\">\r\n        <operation error=\"skip\" info=\"Add Capture Link\">\r\n            <search position=\"after\"><![CDATA[$data[\'layouts\'] = $this->model_design_layout->getLayouts();]]></search>\r\n            <add><![CDATA[\r\n                $data[\'layouts\'] = $this->model_design_layout->getLayouts();\r\n                if(!empty($this->request->get[\'product_id\'])) {\r\n                    $res = $this->db->query(\'SELECT * FROM `\'.DB_PREFIX.\'ya_money_product_properties` WHERE product_id=\'.$this->request->get[\'product_id\']);\r\n                    $productProp = $res->row;\r\n                }\r\n                $data[\'product_ym_payment_mode\'] = !empty($productProp[\'payment_mode\']) ? $productProp[\'payment_mode\'] : \'\';\r\n                $data[\'product_ym_payment_subject\'] = !empty($productProp[\'payment_subject\']) ? $productProp[\'payment_subject\'] : \'\';\r\n\r\n                $data[\'paymentModeEnum\'] = array(\r\n                    \'full_prepayment\'    => \'Полная предоплата (\\\'full_prepayment\\\')\',\r\n                    \'partial_prepayment\' => \'Частичная предоплата (\\\'partial_prepayment\\\')\',\r\n                    \'advance\'            => \'Аванс (\\\'advance\\\')\',\r\n                    \'full_payment\'       => \'Полный расчет (\\\'full_payment\\\')\',\r\n                    \'partial_payment\'    => \'Частичный расчет и кредит (\\\'partial_payment\\\')\',\r\n                    \'credit\'             => \'Кредит (\\\'credit\\\')\',\r\n                    \'credit_payment\'     => \'Выплата по кредиту (\\\'credit_payment\\\')\',\r\n                );\r\n                $data[\'paymentSubjectEnum\'] = array(\r\n                    \'commodity\'             => \'Товар (\\\'commodity\\\')\',\r\n                    \'excise\'                => \'Подакцизный товар (\\\'excise\\\')\',\r\n                    \'job\'                   => \'Работа (\\\'job\\\')\',\r\n                    \'service\'               => \'Услуга (\\\'service\\\')\',\r\n                    \'gambling_bet\'          => \'Ставка в азартной игре (\\\'gambling_bet\\\')\',\r\n                    \'gambling_prize\'        => \'Выигрыш в азартной игре (\\\'gambling_prize\\\')\',\r\n                    \'lottery\'               => \'Лотерейный билет (\\\'lottery\\\')\',\r\n                    \'lottery_prize\'         => \'Выигрыш в лотерею (\\\'lottery_prize\\\')\',\r\n                    \'intellectual_activity\' => \'Результаты интеллектуальной деятельности (\\\'intellectual_activity\\\')\',\r\n                    \'payment\'               => \'Платеж (\\\'payment\\\')\',\r\n                    \'agent_commission\'      => \'Агентское вознаграждение (\\\'agent_commission\\\')\',\r\n                    \'composite\'             => \'Несколько вариантов (\\\'composite\\\')\',\r\n                    \'another\'               => \'Другое (\\\'another\\\')\',\r\n                );\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n\r\n    <file path=\"admin/controller/catalog/product.php\" error=\"skip\">\r\n        <operation error=\"skip\" info=\"Add Capture Link\">\r\n            <search position=\"after\"><![CDATA[$this->model_catalog_product->editProduct($this->request->get[\'product_id\'], $this->request->post);]]></search>\r\n            <add><![CDATA[\r\n                $this->model_catalog_product->editProduct($this->request->get[\'product_id\'], $this->request->post);\r\n                if(!empty($this->request->post[\'ym_payment_mode\']) && !empty($this->request->post[\'ym_payment_subject\'])) {\r\n                    $res = $this->db->query(\'INSERT INTO `\'.DB_PREFIX.\'ya_money_product_properties` (product_id, payment_mode, payment_subject)\r\n                        VALUES(\'.$this->request->get[\'product_id\'].\', \"\'.$this->request->post[\'ym_payment_mode\'].\'\", \"\'.$this->request->post[\'ym_payment_subject\'].\'\")\r\n                        ON DUPLICATE KEY UPDATE  payment_mode=\"\'.$this->request->post[\'ym_payment_mode\'].\'\", payment_subject=\"\'.$this->request->post[\'ym_payment_subject\'].\'\"\'\r\n                    );\r\n                }\r\n            ]]></add>\r\n        </operation>\r\n    </file>\r\n</modification>', 1, '2020-08-02 20:23:56'),
(5, 8, 'Export/Import Tool (V3.22) for OpenCart 3.x', 'Export/Import Tool (V3.22) for OpenCart 3.x', 'mhccorp.com', '3.x-3.22', 'https://www.mhccorp.com', '<modification>\n	<name>Export/Import Tool (V3.22) for OpenCart 3.x</name>\n	<code>Export/Import Tool (V3.22) for OpenCart 3.x</code>\n	<version>3.x-3.22</version>\n	<author>mhccorp.com</author>\n	<link>https://www.mhccorp.com</link>\n	<file path=\"admin/controller/common/column_left.php\">\n		<operation>\n			<search><![CDATA[if ($this->user->hasPermission(\'access\', \'tool/upload\')) {]]></search>\n			<add position=\"before\"><![CDATA[\n			if ($this->user->hasPermission(\'access\', \'extension/export_import\')) {\n				$maintenance[] = array(\n					\'name\'	   => $this->language->get(\'text_export_import\'),\n					\'href\'     => $this->url->link(\'extension/export_import\', \'user_token=\' . $this->session->data[\'user_token\'], true),\n					\'children\' => array()		\n				);\n			}\n			]]></add>\n		</operation>\n	</file>\n	<file path=\"admin/language/en{*}/common/column_left.php\">\n		<operation>\n			<search><![CDATA[$_[\'text_backup\']]]></search>\n			<add position=\"after\"><![CDATA[\n$_[\'text_export_import\']             = \'Export / Import\';\n			]]></add>\n		</operation>\n	</file>\n	<file path=\"admin/language/ru{*}/common/column_left.php\">\n		<operation>\n			<search><![CDATA[$_[\'text_backup\']]]></search>\n			<add position=\"after\"><![CDATA[\n$_[\'text_export_import\']             = \'Экспорт / Импорт\';\n			]]></add>\n		</operation>\n	</file>\n</modification>\n', 1, '2020-08-02 19:56:24');

-- --------------------------------------------------------

--
-- Table structure for table `oc_module`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_module`;
CREATE TABLE `oc_module` (
  `module_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `code` varchar(32) NOT NULL,
  `setting` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_module`
--

INSERT INTO `oc_module` (`module_id`, `name`, `code`, `setting`) VALUES
(30, 'Category', 'banner', '{\"name\":\"Category\",\"banner_id\":\"6\",\"width\":\"182\",\"height\":\"182\",\"status\":\"1\"}'),
(29, 'Home Page', 'carousel', '{\"name\":\"Home Page\",\"banner_id\":\"8\",\"width\":\"130\",\"height\":\"100\",\"status\":\"1\"}'),
(28, 'Home Page', 'featured', '{\"name\":\"Home Page\",\"product\":[\"43\",\"40\",\"42\",\"30\"],\"limit\":\"4\",\"width\":\"200\",\"height\":\"200\",\"status\":\"1\"}'),
(27, 'Home Page', 'slideshow', '{\"name\":\"Home Page\",\"banner_id\":\"7\",\"width\":\"1140\",\"height\":\"380\",\"status\":\"1\"}'),
(31, 'Banner 1', 'banner', '{\"name\":\"Banner 1\",\"banner_id\":\"6\",\"width\":\"182\",\"height\":\"182\",\"status\":\"1\"}');

-- --------------------------------------------------------

--
-- Table structure for table `oc_ocfilter_option`
--
-- Creation: Aug 02, 2020 at 10:49 AM
-- Last update: Aug 02, 2020 at 10:49 AM
--

DROP TABLE IF EXISTS `oc_ocfilter_option`;
CREATE TABLE `oc_ocfilter_option` (
  `option_id` int(11) NOT NULL,
  `type` varchar(16) NOT NULL DEFAULT 'checkbox',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `selectbox` tinyint(1) NOT NULL DEFAULT '0',
  `grouping` tinyint(2) NOT NULL DEFAULT '0',
  `color` tinyint(1) NOT NULL DEFAULT '0',
  `image` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ocfilter_option_description`
--
-- Creation: Aug 02, 2020 at 10:49 AM
-- Last update: Aug 02, 2020 at 10:49 AM
--

DROP TABLE IF EXISTS `oc_ocfilter_option_description`;
CREATE TABLE `oc_ocfilter_option_description` (
  `option_id` int(11) NOT NULL,
  `language_id` tinyint(2) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `postfix` varchar(32) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ocfilter_option_to_category`
--
-- Creation: Aug 02, 2020 at 10:49 AM
-- Last update: Aug 02, 2020 at 10:49 AM
--

DROP TABLE IF EXISTS `oc_ocfilter_option_to_category`;
CREATE TABLE `oc_ocfilter_option_to_category` (
  `option_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ocfilter_option_to_store`
--
-- Creation: Aug 02, 2020 at 10:49 AM
-- Last update: Aug 02, 2020 at 10:49 AM
--

DROP TABLE IF EXISTS `oc_ocfilter_option_to_store`;
CREATE TABLE `oc_ocfilter_option_to_store` (
  `option_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ocfilter_option_value`
--
-- Creation: Aug 02, 2020 at 10:49 AM
-- Last update: Aug 02, 2020 at 10:49 AM
--

DROP TABLE IF EXISTS `oc_ocfilter_option_value`;
CREATE TABLE `oc_ocfilter_option_value` (
  `value_id` bigint(20) NOT NULL,
  `option_id` int(11) NOT NULL DEFAULT '0',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `color` varchar(6) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ocfilter_option_value_description`
--
-- Creation: Aug 02, 2020 at 10:49 AM
-- Last update: Aug 02, 2020 at 10:49 AM
--

DROP TABLE IF EXISTS `oc_ocfilter_option_value_description`;
CREATE TABLE `oc_ocfilter_option_value_description` (
  `value_id` bigint(20) NOT NULL,
  `option_id` int(11) NOT NULL,
  `language_id` tinyint(2) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ocfilter_option_value_to_product`
--
-- Creation: Aug 02, 2020 at 10:49 AM
-- Last update: Aug 02, 2020 at 10:49 AM
--

DROP TABLE IF EXISTS `oc_ocfilter_option_value_to_product`;
CREATE TABLE `oc_ocfilter_option_value_to_product` (
  `ocfilter_option_value_to_product_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `value_id` bigint(20) NOT NULL,
  `slide_value_min` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `slide_value_max` decimal(15,4) NOT NULL DEFAULT '0.0000'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ocfilter_option_value_to_product_description`
--
-- Creation: Aug 02, 2020 at 10:49 AM
-- Last update: Aug 02, 2020 at 10:49 AM
--

DROP TABLE IF EXISTS `oc_ocfilter_option_value_to_product_description`;
CREATE TABLE `oc_ocfilter_option_value_to_product_description` (
  `product_id` int(11) NOT NULL,
  `value_id` bigint(20) NOT NULL,
  `option_id` int(11) NOT NULL,
  `language_id` tinyint(2) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ocfilter_page`
--
-- Creation: Aug 02, 2020 at 10:49 AM
-- Last update: Aug 02, 2020 at 10:49 AM
--

DROP TABLE IF EXISTS `oc_ocfilter_page`;
CREATE TABLE `oc_ocfilter_page` (
  `ocfilter_page_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `keyword` varchar(255) NOT NULL,
  `params` varchar(255) NOT NULL,
  `over` set('domain','category') NOT NULL DEFAULT 'category',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ocfilter_page_description`
--
-- Creation: Aug 02, 2020 at 10:49 AM
-- Last update: Aug 02, 2020 at 10:49 AM
--

DROP TABLE IF EXISTS `oc_ocfilter_page_description`;
CREATE TABLE `oc_ocfilter_page_description` (
  `ocfilter_page_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '0',
  `meta_title` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `title` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_option`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_option`;
CREATE TABLE `oc_option` (
  `option_id` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_option`
--

INSERT INTO `oc_option` (`option_id`, `type`, `sort_order`) VALUES
(1, 'radio', 1),
(2, 'checkbox', 2),
(4, 'text', 3),
(5, 'select', 4),
(6, 'textarea', 5),
(7, 'file', 6),
(8, 'date', 7),
(9, 'time', 8),
(10, 'datetime', 9),
(11, 'select', 10),
(12, 'date', 11);

-- --------------------------------------------------------

--
-- Table structure for table `oc_option_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_option_description`;
CREATE TABLE `oc_option_description` (
  `option_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_option_description`
--

INSERT INTO `oc_option_description` (`option_id`, `language_id`, `name`) VALUES
(1, 1, 'Radio'),
(2, 1, 'Checkbox'),
(4, 1, 'Text'),
(6, 1, 'Textarea'),
(8, 1, 'Date'),
(7, 1, 'File'),
(5, 1, 'Select'),
(9, 1, 'Time'),
(10, 1, 'Date &amp; Time'),
(12, 1, 'Delivery Date'),
(11, 1, 'Size'),
(1, 2, 'Radio'),
(2, 2, 'Checkbox'),
(4, 2, 'Text'),
(6, 2, 'Textarea'),
(8, 2, 'Date'),
(7, 2, 'File'),
(5, 2, 'Select'),
(9, 2, 'Time'),
(10, 2, 'Date &amp; Time'),
(12, 2, 'Delivery Date'),
(11, 2, 'Size');

-- --------------------------------------------------------

--
-- Table structure for table `oc_option_value`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_option_value`;
CREATE TABLE `oc_option_value` (
  `option_value_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_option_value`
--

INSERT INTO `oc_option_value` (`option_value_id`, `option_id`, `image`, `sort_order`) VALUES
(43, 1, '', 3),
(32, 1, '', 1),
(45, 2, '', 4),
(44, 2, '', 3),
(42, 5, '', 4),
(41, 5, '', 3),
(39, 5, '', 1),
(40, 5, '', 2),
(31, 1, '', 2),
(23, 2, '', 1),
(24, 2, '', 2),
(46, 11, '', 1),
(47, 11, '', 2),
(48, 11, '', 3);

-- --------------------------------------------------------

--
-- Table structure for table `oc_option_value_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_option_value_description`;
CREATE TABLE `oc_option_value_description` (
  `option_value_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_option_value_description`
--

INSERT INTO `oc_option_value_description` (`option_value_id`, `language_id`, `option_id`, `name`) VALUES
(43, 1, 1, 'Large'),
(32, 1, 1, 'Small'),
(45, 1, 2, 'Checkbox 4'),
(44, 1, 2, 'Checkbox 3'),
(31, 1, 1, 'Medium'),
(42, 1, 5, 'Yellow'),
(41, 1, 5, 'Green'),
(39, 1, 5, 'Red'),
(40, 1, 5, 'Blue'),
(23, 1, 2, 'Checkbox 1'),
(24, 1, 2, 'Checkbox 2'),
(48, 1, 11, 'Large'),
(47, 1, 11, 'Medium'),
(46, 1, 11, 'Small'),
(43, 2, 1, 'Large'),
(32, 2, 1, 'Small'),
(45, 2, 2, 'Checkbox 4'),
(44, 2, 2, 'Checkbox 3'),
(31, 2, 1, 'Medium'),
(42, 2, 5, 'Yellow'),
(41, 2, 5, 'Green'),
(39, 2, 5, 'Red'),
(40, 2, 5, 'Blue'),
(23, 2, 2, 'Checkbox 1'),
(24, 2, 2, 'Checkbox 2'),
(48, 2, 11, 'Large'),
(47, 2, 11, 'Medium'),
(46, 2, 11, 'Small');

-- --------------------------------------------------------

--
-- Table structure for table `oc_order`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_order`;
CREATE TABLE `oc_order` (
  `order_id` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL DEFAULT '0',
  `invoice_prefix` varchar(26) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `store_name` varchar(64) NOT NULL,
  `store_url` varchar(255) NOT NULL,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `customer_group_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `fax` varchar(32) NOT NULL,
  `custom_field` text NOT NULL,
  `payment_firstname` varchar(32) NOT NULL,
  `payment_lastname` varchar(32) NOT NULL,
  `payment_company` varchar(60) NOT NULL,
  `payment_address_1` varchar(128) NOT NULL,
  `payment_address_2` varchar(128) NOT NULL,
  `payment_city` varchar(128) NOT NULL,
  `payment_postcode` varchar(10) NOT NULL,
  `payment_country` varchar(128) NOT NULL,
  `payment_country_id` int(11) NOT NULL,
  `payment_zone` varchar(128) NOT NULL,
  `payment_zone_id` int(11) NOT NULL,
  `payment_address_format` text NOT NULL,
  `payment_custom_field` text NOT NULL,
  `payment_method` varchar(128) NOT NULL,
  `payment_code` varchar(128) NOT NULL,
  `shipping_firstname` varchar(32) NOT NULL,
  `shipping_lastname` varchar(32) NOT NULL,
  `shipping_company` varchar(40) NOT NULL,
  `shipping_address_1` varchar(128) NOT NULL,
  `shipping_address_2` varchar(128) NOT NULL,
  `shipping_city` varchar(128) NOT NULL,
  `shipping_postcode` varchar(10) NOT NULL,
  `shipping_country` varchar(128) NOT NULL,
  `shipping_country_id` int(11) NOT NULL,
  `shipping_zone` varchar(128) NOT NULL,
  `shipping_zone_id` int(11) NOT NULL,
  `shipping_address_format` text NOT NULL,
  `shipping_custom_field` text NOT NULL,
  `shipping_method` varchar(128) NOT NULL,
  `shipping_code` varchar(128) NOT NULL,
  `comment` text NOT NULL,
  `total` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `order_status_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_id` int(11) NOT NULL,
  `commission` decimal(15,4) NOT NULL,
  `marketing_id` int(11) NOT NULL,
  `tracking` varchar(64) NOT NULL,
  `language_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `currency_code` varchar(3) NOT NULL,
  `currency_value` decimal(15,8) NOT NULL DEFAULT '1.00000000',
  `ip` varchar(40) NOT NULL,
  `forwarded_ip` varchar(40) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `accept_language` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_history`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_order_history`;
CREATE TABLE `oc_order_history` (
  `order_history_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_status_id` int(11) NOT NULL,
  `notify` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_option`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_order_option`;
CREATE TABLE `oc_order_option` (
  `order_option_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_product_id` int(11) NOT NULL,
  `product_option_id` int(11) NOT NULL,
  `product_option_value_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `type` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_product`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_order_product`;
CREATE TABLE `oc_order_product` (
  `order_product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `model` varchar(64) NOT NULL,
  `quantity` int(4) NOT NULL,
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `reward` int(8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_recurring`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_order_recurring`;
CREATE TABLE `oc_order_recurring` (
  `order_recurring_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `recurring_id` int(11) NOT NULL,
  `recurring_name` varchar(255) NOT NULL,
  `recurring_description` varchar(255) NOT NULL,
  `recurring_frequency` varchar(25) NOT NULL,
  `recurring_cycle` smallint(6) NOT NULL,
  `recurring_duration` smallint(6) NOT NULL,
  `recurring_price` decimal(10,4) NOT NULL,
  `trial` tinyint(1) NOT NULL,
  `trial_frequency` varchar(25) NOT NULL,
  `trial_cycle` smallint(6) NOT NULL,
  `trial_duration` smallint(6) NOT NULL,
  `trial_price` decimal(10,4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_recurring_transaction`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_order_recurring_transaction`;
CREATE TABLE `oc_order_recurring_transaction` (
  `order_recurring_transaction_id` int(11) NOT NULL,
  `order_recurring_id` int(11) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `amount` decimal(10,4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_shipment`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_order_shipment`;
CREATE TABLE `oc_order_shipment` (
  `order_shipment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `shipping_courier_id` varchar(255) NOT NULL DEFAULT '',
  `tracking_number` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_status`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_order_status`;
CREATE TABLE `oc_order_status` (
  `order_status_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_order_status`
--

INSERT INTO `oc_order_status` (`order_status_id`, `language_id`, `name`) VALUES
(2, 1, 'Processing'),
(3, 1, 'Shipped'),
(7, 1, 'Canceled'),
(5, 1, 'Complete'),
(8, 1, 'Denied'),
(9, 1, 'Canceled Reversal'),
(10, 1, 'Failed'),
(11, 1, 'Refunded'),
(12, 1, 'Reversed'),
(13, 1, 'Chargeback'),
(1, 1, 'Pending'),
(16, 1, 'Voided'),
(15, 1, 'Processed'),
(14, 1, 'Expired'),
(2, 2, 'Processing'),
(3, 2, 'Shipped'),
(7, 2, 'Canceled'),
(5, 2, 'Complete'),
(8, 2, 'Denied'),
(9, 2, 'Canceled Reversal'),
(10, 2, 'Failed'),
(11, 2, 'Refunded'),
(12, 2, 'Reversed'),
(13, 2, 'Chargeback'),
(1, 2, 'Pending'),
(16, 2, 'Voided'),
(15, 2, 'Processed'),
(14, 2, 'Expired');

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_total`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_order_total`;
CREATE TABLE `oc_order_total` (
  `order_total_id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `title` varchar(255) NOT NULL,
  `value` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_voucher`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_order_voucher`;
CREATE TABLE `oc_order_voucher` (
  `order_voucher_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `voucher_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `code` varchar(10) NOT NULL,
  `from_name` varchar(64) NOT NULL,
  `from_email` varchar(96) NOT NULL,
  `to_name` varchar(64) NOT NULL,
  `to_email` varchar(96) NOT NULL,
  `voucher_theme_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `amount` decimal(15,4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product`
--
-- Creation: Aug 02, 2020 at 10:54 AM
-- Last update: Aug 02, 2020 at 11:44 AM
--

DROP TABLE IF EXISTS `oc_product`;
CREATE TABLE `oc_product` (
  `product_id` int(11) NOT NULL,
  `model` varchar(64) NOT NULL,
  `sku` varchar(64) NOT NULL,
  `upc` varchar(12) NOT NULL,
  `ean` varchar(14) NOT NULL,
  `jan` varchar(13) NOT NULL,
  `isbn` varchar(17) NOT NULL,
  `mpn` varchar(64) NOT NULL,
  `location` varchar(128) NOT NULL,
  `quantity` int(4) NOT NULL DEFAULT '0',
  `stock_status_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `manufacturer_id` int(11) NOT NULL,
  `shipping` tinyint(1) NOT NULL DEFAULT '1',
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `points` int(8) NOT NULL DEFAULT '0',
  `tax_class_id` int(11) NOT NULL,
  `date_available` date NOT NULL DEFAULT '0000-00-00',
  `weight` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `weight_class_id` int(11) NOT NULL DEFAULT '0',
  `length` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `width` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `height` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `length_class_id` int(11) NOT NULL DEFAULT '0',
  `subtract` tinyint(1) NOT NULL DEFAULT '1',
  `minimum` int(11) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `viewed` int(5) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `meta_robots` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product`
--

INSERT INTO `oc_product` (`product_id`, `model`, `sku`, `upc`, `ean`, `jan`, `isbn`, `mpn`, `location`, `quantity`, `stock_status_id`, `image`, `manufacturer_id`, `shipping`, `price`, `points`, `tax_class_id`, `date_available`, `weight`, `weight_class_id`, `length`, `width`, `height`, `length_class_id`, `subtract`, `minimum`, `sort_order`, `status`, `viewed`, `date_added`, `date_modified`, `meta_robots`) VALUES
(28, 'Product 1', '', '', '', '', '', '', '', 939, 7, 'catalog/demo/htc_touch_hd_1.jpg', 5, 1, '100.0000', 200, 9, '2009-02-03', '146.40000000', 2, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 0, 1, 0, '2009-02-03 16:06:50', '2011-09-30 01:05:39', ''),
(29, 'Product 2', '', '', '', '', '', '', '', 999, 6, 'catalog/demo/palm_treo_pro_1.jpg', 6, 1, '279.9900', 0, 9, '2009-02-03', '133.00000000', 2, '0.00000000', '0.00000000', '0.00000000', 3, 1, 1, 0, 1, 0, '2009-02-03 16:42:17', '2011-09-30 01:06:08', ''),
(30, 'Product 3', '', '', '', '', '', '', '', 7, 6, 'catalog/demo/canon_eos_5d_1.jpg', 9, 1, '100.0000', 0, 9, '2009-02-03', '0.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 0, 1, 0, '2009-02-03 16:59:00', '2011-09-30 01:05:23', ''),
(31, 'Product 4', '', '', '', '', '', '', '', 1000, 6, 'catalog/demo/nikon_d300_1.jpg', 0, 1, '80.0000', 0, 9, '2009-02-03', '0.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 3, 1, 1, 0, 1, 0, '2009-02-03 17:00:10', '2011-09-30 01:06:00', ''),
(32, 'Product 5', '', '', '', '', '', '', '', 999, 6, 'catalog/demo/ipod_touch_1.jpg', 8, 1, '100.0000', 0, 9, '2009-02-03', '5.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 0, 1, 0, '2009-02-03 17:07:26', '2011-09-30 01:07:22', ''),
(33, 'Product 6', '', '', '', '', '', '', '', 1000, 6, 'catalog/demo/samsung_syncmaster_941bw.jpg', 0, 1, '200.0000', 0, 9, '2009-02-03', '5.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 2, 1, 1, 0, 1, 0, '2009-02-03 17:08:31', '2011-09-30 01:06:29', ''),
(34, 'Product 7', '', '', '', '', '', '', '', 1000, 6, 'catalog/demo/ipod_shuffle_1.jpg', 8, 1, '100.0000', 0, 9, '2009-02-03', '5.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 2, 1, 1, 0, 1, 0, '2009-02-03 18:07:54', '2011-09-30 01:07:17', ''),
(35, 'Product 8', '', '', '', '', '', '', '', 1000, 5, '', 0, 0, '100.0000', 0, 9, '2009-02-03', '5.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 0, 1, 0, '2009-02-03 18:08:31', '2011-09-30 01:06:17', ''),
(36, 'Product 9', '', '', '', '', '', '', '', 994, 6, 'catalog/demo/ipod_nano_1.jpg', 8, 0, '100.0000', 100, 9, '2009-02-03', '5.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 2, 1, 1, 0, 1, 0, '2009-02-03 18:09:19', '2011-09-30 01:07:12', ''),
(40, 'product 11', '', '', '', '', '', '', '', 970, 5, 'catalog/demo/iphone_1.jpg', 8, 1, '101.0000', 0, 9, '2009-02-03', '10.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 0, 1, 0, '2009-02-03 21:07:12', '2011-09-30 01:06:53', ''),
(41, 'Product 14', '', '', '', '', '', '', '', 977, 5, 'catalog/demo/imac_1.jpg', 8, 1, '100.0000', 0, 9, '2009-02-03', '5.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 0, 1, 0, '2009-02-03 21:07:26', '2011-09-30 01:06:44', ''),
(42, 'Product 15', '', '', '', '', '', '', '', 990, 5, 'catalog/demo/apple_cinema_30.jpg', 8, 1, '100.0000', 400, 9, '2009-02-04', '12.50000000', 1, '1.00000000', '2.00000000', '3.00000000', 1, 1, 2, 0, 1, 0, '2009-02-03 21:07:37', '2011-09-30 00:46:19', ''),
(43, 'Product 16', '', '', '', '', '', '', '', 929, 5, 'catalog/demo/macbook_1.jpg', 8, 0, '500.0000', 0, 9, '2009-02-03', '0.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 2, 1, 1, 0, 1, 3, '2009-02-03 21:07:49', '2011-09-30 01:05:46', ''),
(44, 'Product 17', '', '', '', '', '', '', '', 1000, 5, 'catalog/demo/macbook_air_1.jpg', 8, 1, '1000.0000', 0, 9, '2009-02-03', '0.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 2, 1, 1, 0, 1, 0, '2009-02-03 21:08:00', '2011-09-30 01:05:53', ''),
(45, 'Product 18', '', '', '', '', '', '', '', 998, 5, 'catalog/demo/macbook_pro_1.jpg', 8, 1, '2000.0000', 0, 100, '2009-02-03', '0.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 2, 1, 1, 0, 1, 0, '2009-02-03 21:08:17', '2011-09-15 22:22:01', ''),
(46, 'Product 19', '', '', '', '', '', '', '', 1000, 5, 'catalog/demo/sony_vaio_1.jpg', 10, 1, '1000.0000', 0, 9, '2009-02-03', '0.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 2, 1, 1, 0, 1, 0, '2009-02-03 21:08:29', '2011-09-30 01:06:39', ''),
(47, 'Product 21', '', '', '', '', '', '', '', 1000, 5, 'catalog/demo/hp_1.jpg', 7, 1, '100.0000', 400, 9, '2009-02-03', '1.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 0, 1, 0, 1, 1, '2009-02-03 21:08:40', '2011-09-30 01:05:28', ''),
(48, 'product 20', 'test 1', '', '', '', '', '', 'test 2', 995, 5, 'catalog/demo/ipod_classic_1.jpg', 8, 1, '100.0000', 0, 9, '2009-02-08', '1.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 2, 1, 1, 0, 1, 0, '2009-02-08 17:21:51', '2011-09-30 01:07:06', ''),
(49, 'SAM1', '', '', '', '', '', '', '', 0, 8, 'catalog/demo/samsung_tab_1.jpg', 0, 1, '199.9900', 0, 9, '2011-04-25', '0.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 1, 1, 0, '2011-04-26 08:57:34', '2011-09-30 01:06:23', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_advertise_google`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_advertise_google`;
CREATE TABLE `oc_product_advertise_google` (
  `product_advertise_google_id` int(11) UNSIGNED NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `has_issues` tinyint(1) DEFAULT NULL,
  `destination_status` enum('pending','approved','disapproved') NOT NULL DEFAULT 'pending',
  `impressions` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `conversions` int(11) NOT NULL DEFAULT '0',
  `cost` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `conversion_value` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `google_product_category` varchar(10) DEFAULT NULL,
  `condition` enum('new','refurbished','used') DEFAULT NULL,
  `adult` tinyint(1) DEFAULT NULL,
  `multipack` int(11) DEFAULT NULL,
  `is_bundle` tinyint(1) DEFAULT NULL,
  `age_group` enum('newborn','infant','toddler','kids','adult') DEFAULT NULL,
  `color` int(11) DEFAULT NULL,
  `gender` enum('male','female','unisex') DEFAULT NULL,
  `size_type` enum('regular','petite','plus','big and tall','maternity') DEFAULT NULL,
  `size_system` enum('AU','BR','CN','DE','EU','FR','IT','JP','MEX','UK','US') DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `is_modified` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_advertise_google_status`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_advertise_google_status`;
CREATE TABLE `oc_product_advertise_google_status` (
  `product_id` int(11) NOT NULL DEFAULT '0',
  `store_id` int(11) NOT NULL DEFAULT '0',
  `product_variation_id` varchar(64) NOT NULL DEFAULT '',
  `destination_statuses` text NOT NULL,
  `data_quality_issues` text NOT NULL,
  `item_level_issues` text NOT NULL,
  `google_expiration_date` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_advertise_google_target`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_advertise_google_target`;
CREATE TABLE `oc_product_advertise_google_target` (
  `product_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `advertise_google_target_id` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_attribute`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_product_attribute`;
CREATE TABLE `oc_product_attribute` (
  `product_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_attribute`
--

INSERT INTO `oc_product_attribute` (`product_id`, `attribute_id`, `language_id`, `text`) VALUES
(43, 2, 1, '1'),
(47, 4, 1, '16GB'),
(43, 4, 1, '8gb'),
(42, 3, 1, '100mhz'),
(47, 2, 1, '4'),
(43, 2, 2, '1'),
(47, 4, 2, '16GB'),
(43, 4, 2, '8gb'),
(42, 3, 2, '100mhz'),
(47, 2, 2, '4');

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_description`
--
-- Creation: Aug 02, 2020 at 10:54 AM
-- Last update: Aug 02, 2020 at 10:54 AM
--

DROP TABLE IF EXISTS `oc_product_description`;
CREATE TABLE `oc_product_description` (
  `product_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `tag` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  `seo_h1` varchar(255) NOT NULL,
  `seo_h2` varchar(255) NOT NULL,
  `seo_h3` varchar(255) NOT NULL,
  `image_title` varchar(255) NOT NULL,
  `image_alt` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_description`
--

INSERT INTO `oc_product_description` (`product_id`, `language_id`, `name`, `description`, `tag`, `meta_title`, `meta_description`, `meta_keyword`, `seo_keyword`, `seo_h1`, `seo_h2`, `seo_h3`, `image_title`, `image_alt`) VALUES
(35, 1, 'Product 8', '&lt;p&gt;\r\n	Product 8&lt;/p&gt;\r\n', '', 'Product 8', '', '', '', '', '', '', '', ''),
(48, 1, 'iPod Classic', '&lt;div class=&quot;cpt_product_description &quot;&gt;\r\n	&lt;div&gt;\r\n		&lt;p&gt;\r\n			&lt;strong&gt;More room to move.&lt;/strong&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;strong&gt;Cover Flow.&lt;/strong&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Browse through your music collection by flipping through album art. Select an album to turn it over and see the track list.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;strong&gt;Enhanced interface.&lt;/strong&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Experience a whole new way to browse and view your music and video.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;strong&gt;Sleeker design.&lt;/strong&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Beautiful, durable, and sleeker than ever, iPod classic now features an anodized aluminum and polished stainless steel enclosure with rounded edges.&lt;/p&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;!-- cpt_container_end --&gt;', '', 'iPod Classic', '', '', '', '', '', '', '', ''),
(40, 1, 'iPhone', '&lt;p class=&quot;intro&quot;&gt;\r\n	iPhone is a revolutionary new mobile phone that allows you to make a call by simply tapping a name or number in your address book, a favorites list, or a call log. It also automatically syncs all your contacts from a PC, Mac, or Internet service. And it lets you select and listen to voicemail messages in whatever order you want just like email.&lt;/p&gt;\r\n', '', 'iPhone', '', '', '', '', '', '', '', ''),
(28, 1, 'HTC Touch HD', '&lt;p&gt;\r\n	HTC Touch - in High Definition. Watch music videos and streaming content in awe-inspiring high definition clarity for a mobile experience you never thought possible. Seductively sleek, the HTC Touch HD provides the next generation of mobile functionality, all at a simple touch. Fully integrated with Windows Mobile Professional 6.1, ultrafast 3.5G, GPS, 5MP camera, plus lots more - all delivered on a breathtakingly crisp 3.8&amp;quot; WVGA touchscreen - you can take control of your mobile world with the HTC Touch HD.&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;Features&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Processor Qualcomm&amp;reg; MSM 7201A&amp;trade; 528 MHz&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Windows Mobile&amp;reg; 6.1 Professional Operating System&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Memory: 512 MB ROM, 288 MB RAM&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Dimensions: 115 mm x 62.8 mm x 12 mm / 146.4 grams&lt;/li&gt;\r\n	&lt;li&gt;\r\n		3.8-inch TFT-LCD flat touch-sensitive screen with 480 x 800 WVGA resolution&lt;/li&gt;\r\n	&lt;li&gt;\r\n		HSDPA/WCDMA: Europe/Asia: 900/2100 MHz; Up to 2 Mbps up-link and 7.2 Mbps down-link speeds&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Quad-band GSM/GPRS/EDGE: Europe/Asia: 850/900/1800/1900 MHz (Band frequency, HSUPA availability, and data speed are operator dependent.)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Device Control via HTC TouchFLO&amp;trade; 3D &amp;amp; Touch-sensitive front panel buttons&lt;/li&gt;\r\n	&lt;li&gt;\r\n		GPS and A-GPS ready&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Bluetooth&amp;reg; 2.0 with Enhanced Data Rate and A2DP for wireless stereo headsets&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Wi-Fi&amp;reg;: IEEE 802.11 b/g&lt;/li&gt;\r\n	&lt;li&gt;\r\n		HTC ExtUSB&amp;trade; (11-pin mini-USB 2.0)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		5 megapixel color camera with auto focus&lt;/li&gt;\r\n	&lt;li&gt;\r\n		VGA CMOS color camera&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Built-in 3.5 mm audio jack, microphone, speaker, and FM radio&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Ring tone formats: AAC, AAC+, eAAC+, AMR-NB, AMR-WB, QCP, MP3, WMA, WAV&lt;/li&gt;\r\n	&lt;li&gt;\r\n		40 polyphonic and standard MIDI format 0 and 1 (SMF)/SP MIDI&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Rechargeable Lithium-ion or Lithium-ion polymer 1350 mAh battery&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Expansion Slot: microSD&amp;trade; memory card (SD 2.0 compatible)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		AC Adapter Voltage range/frequency: 100 ~ 240V AC, 50/60 Hz DC output: 5V and 1A&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Special Features: FM Radio, G-Sensor&lt;/li&gt;\r\n&lt;/ul&gt;\r\n', '', '	 HTC Touch HD', '', '', '', '', '', '', '', ''),
(44, 1, 'MacBook Air', '&lt;div&gt;\r\n	MacBook Air is ultrathin, ultraportable, and ultra unlike anything else. But you don&amp;rsquo;t lose inches and pounds overnight. It&amp;rsquo;s the result of rethinking conventions. Of multiple wireless innovations. And of breakthrough design. With MacBook Air, mobile computing suddenly has a new standard.&lt;/div&gt;\r\n', '', 'MacBook Air', '', '', '', '', '', '', '', ''),
(45, 1, 'MacBook Pro', '&lt;div class=&quot;cpt_product_description &quot;&gt;\r\n	&lt;div&gt;\r\n		&lt;p&gt;\r\n			&lt;b&gt;Latest Intel mobile architecture&lt;/b&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Powered by the most advanced mobile processors from Intel, the new Core 2 Duo MacBook Pro is over 50% faster than the original Core Duo MacBook Pro and now supports up to 4GB of RAM.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;b&gt;Leading-edge graphics&lt;/b&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			The NVIDIA GeForce 8600M GT delivers exceptional graphics processing power. For the ultimate creative canvas, you can even configure the 17-inch model with a 1920-by-1200 resolution display.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;b&gt;Designed for life on the road&lt;/b&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Innovations such as a magnetic power connection and an illuminated keyboard with ambient light sensor put the MacBook Pro in a class by itself.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;b&gt;Connect. Create. Communicate.&lt;/b&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Quickly set up a video conference with the built-in iSight camera. Control presentations and media from up to 30 feet away with the included Apple Remote. Connect to high-bandwidth peripherals with FireWire 800 and DVI.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;b&gt;Next-generation wireless&lt;/b&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Featuring 802.11n wireless technology, the MacBook Pro delivers up to five times the performance and up to twice the range of previous-generation technologies.&lt;/p&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;!-- cpt_container_end --&gt;', '', 'MacBook Pro', '', '', '', '', '', '', '', ''),
(29, 1, 'Palm Treo Pro', '&lt;p&gt;\r\n	Redefine your workday with the Palm Treo Pro smartphone. Perfectly balanced, you can respond to business and personal email, stay on top of appointments and contacts, and use Wi-Fi or GPS when you&amp;rsquo;re out and about. Then watch a video on YouTube, catch up with news and sports on the web, or listen to a few songs. Balance your work and play the way you like it, with the Palm Treo Pro.&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;Features&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Windows Mobile&amp;reg; 6.1 Professional Edition&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Qualcomm&amp;reg; MSM7201 400MHz Processor&lt;/li&gt;\r\n	&lt;li&gt;\r\n		320x320 transflective colour TFT touchscreen&lt;/li&gt;\r\n	&lt;li&gt;\r\n		HSDPA/UMTS/EDGE/GPRS/GSM radio&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Tri-band UMTS &amp;mdash; 850MHz, 1900MHz, 2100MHz&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Quad-band GSM &amp;mdash; 850/900/1800/1900&lt;/li&gt;\r\n	&lt;li&gt;\r\n		802.11b/g with WPA, WPA2, and 801.1x authentication&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Built-in GPS&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Bluetooth Version: 2.0 + Enhanced Data Rate&lt;/li&gt;\r\n	&lt;li&gt;\r\n		256MB storage (100MB user available), 128MB RAM&lt;/li&gt;\r\n	&lt;li&gt;\r\n		2.0 megapixel camera, up to 8x digital zoom and video capture&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Removable, rechargeable 1500mAh lithium-ion battery&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Up to 5.0 hours talk time and up to 250 hours standby&lt;/li&gt;\r\n	&lt;li&gt;\r\n		MicroSDHC card expansion (up to 32GB supported)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		MicroUSB 2.0 for synchronization and charging&lt;/li&gt;\r\n	&lt;li&gt;\r\n		3.5mm stereo headset jack&lt;/li&gt;\r\n	&lt;li&gt;\r\n		60mm (W) x 114mm (L) x 13.5mm (D) / 133g&lt;/li&gt;\r\n&lt;/ul&gt;\r\n', '', 'Palm Treo Pro', '', '', '', '', '', '', '', ''),
(36, 1, 'iPod Nano', '&lt;div&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;Video in your pocket.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Its the small iPod with one very big idea: video. The worlds most popular music player now lets you enjoy movies, TV shows, and more on a two-inch display thats 65% brighter than before.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;Cover Flow.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Browse through your music collection by flipping through album art. Select an album to turn it over and see the track list.&lt;strong&gt;&amp;nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;Enhanced interface.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Experience a whole new way to browse and view your music and video.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;Sleek and colorful.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		With an anodized aluminum and polished stainless steel enclosure and a choice of five colors, iPod nano is dressed to impress.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;iTunes.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Available as a free download, iTunes makes it easy to browse and buy millions of songs, movies, TV shows, audiobooks, and games and download free podcasts all at the iTunes Store. And you can import your own music, manage your whole media library, and sync your iPod or iPhone with ease.&lt;/p&gt;\r\n&lt;/div&gt;\r\n', '', 'iPod Nano', '', '', '', '', '', '', '', ''),
(46, 1, 'Sony VAIO', '&lt;div&gt;\r\n	Unprecedented power. The next generation of processing technology has arrived. Built into the newest VAIO notebooks lies Intel&amp;#39;s latest, most powerful innovation yet: Intel&amp;reg; Centrino&amp;reg; 2 processor technology. Boasting incredible speed, expanded wireless connectivity, enhanced multimedia support and greater energy efficiency, all the high-performance essentials are seamlessly combined into a single chip.&lt;/div&gt;\r\n', '', 'Sony VAIO', '', '', '', '', '', '', '', ''),
(47, 1, 'HP LP3065', '&lt;p&gt;\r\n	Stop your co-workers in their tracks with the stunning new 30-inch diagonal HP LP3065 Flat Panel Monitor. This flagship monitor features best-in-class performance and presentation features on a huge wide-aspect screen while letting you work as comfortably as possible - you might even forget you&amp;#39;re at the office&lt;/p&gt;\r\n', '', 'HP LP3065', '', '', '', '', '', '', '', ''),
(32, 1, 'iPod Touch', '&lt;p&gt;\r\n	&lt;strong&gt;Revolutionary multi-touch interface.&lt;/strong&gt;&lt;br /&gt;\r\n	iPod touch features the same multi-touch screen technology as iPhone. Pinch to zoom in on a photo. Scroll through your songs and videos with a flick. Flip through your library by album artwork with Cover Flow.&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;Gorgeous 3.5-inch widescreen display.&lt;/strong&gt;&lt;br /&gt;\r\n	Watch your movies, TV shows, and photos come alive with bright, vivid color on the 320-by-480-pixel display.&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;Music downloads straight from iTunes.&lt;/strong&gt;&lt;br /&gt;\r\n	Shop the iTunes Wi-Fi Music Store from anywhere with Wi-Fi.1 Browse or search to find the music youre looking for, preview it, and buy it with just a tap.&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;Surf the web with Wi-Fi.&lt;/strong&gt;&lt;br /&gt;\r\n	Browse the web using Safari and watch YouTube videos on the first iPod with Wi-Fi built in&lt;br /&gt;\r\n	&amp;nbsp;&lt;/p&gt;\r\n', '', '	 iPod Touch', '', '', '', '', '', '', '', ''),
(41, 1, 'iMac', '&lt;div&gt;\r\n	Just when you thought iMac had everything, now there&acute;s even more. More powerful Intel Core 2 Duo processors. And more memory standard. Combine this with Mac OS X Leopard and iLife &acute;08, and it&acute;s more all-in-one than ever. iMac packs amazing performance into a stunningly slim space.&lt;/div&gt;\r\n', '', 'iMac', '', '', '', '', '', '', '', ''),
(33, 1, 'Samsung SyncMaster 941BW', '&lt;div&gt;\r\n	Imagine the advantages of going big without slowing down. The big 19&amp;quot; 941BW monitor combines wide aspect ratio with fast pixel response time, for bigger images, more room to work and crisp motion. In addition, the exclusive MagicBright 2, MagicColor and MagicTune technologies help deliver the ideal image in every situation, while sleek, narrow bezels and adjustable stands deliver style just the way you want it. With the Samsung 941BW widescreen analog/digital LCD monitor, it&amp;#39;s not hard to imagine.&lt;/div&gt;\r\n', '', 'Samsung SyncMaster 941BW', '', '', '', '', '', '', '', ''),
(34, 1, 'iPod Shuffle', '&lt;div&gt;\r\n	&lt;strong&gt;Born to be worn.&lt;/strong&gt;\r\n	&lt;p&gt;\r\n		Clip on the worlds most wearable music player and take up to 240 songs with you anywhere. Choose from five colors including four new hues to make your musical fashion statement.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;Random meets rhythm.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		With iTunes autofill, iPod shuffle can deliver a new musical experience every time you sync. For more randomness, you can shuffle songs during playback with the slide of a switch.&lt;/p&gt;\r\n	&lt;strong&gt;Everything is easy.&lt;/strong&gt;\r\n	&lt;p&gt;\r\n		Charge and sync with the included USB dock. Operate the iPod shuffle controls with one hand. Enjoy up to 12 hours straight of skip-free music playback.&lt;/p&gt;\r\n&lt;/div&gt;\r\n', '', 'iPod Shuffle', '', '', '', '', '', '', '', ''),
(43, 1, 'MacBook', '&lt;div&gt;\r\n	&lt;p&gt;\r\n		&lt;b&gt;Intel Core 2 Duo processor&lt;/b&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Powered by an Intel Core 2 Duo processor at speeds up to 2.16GHz, the new MacBook is the fastest ever.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;b&gt;1GB memory, larger hard drives&lt;/b&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		The new MacBook now comes with 1GB of memory standard and larger hard drives for the entire line perfect for running more of your favorite applications and storing growing media collections.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;b&gt;Sleek, 1.08-inch-thin design&lt;/b&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		MacBook makes it easy to hit the road thanks to its tough polycarbonate case, built-in wireless technologies, and innovative MagSafe Power Adapter that releases automatically if someone accidentally trips on the cord.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;b&gt;Built-in iSight camera&lt;/b&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Right out of the box, you can have a video chat with friends or family,2 record a video at your desk, or take fun pictures with Photo Booth&lt;/p&gt;\r\n&lt;/div&gt;\r\n', '', 'MacBook', '', '', '', '', '', '', '', ''),
(31, 1, 'Nikon D300', '&lt;div class=&quot;cpt_product_description &quot;&gt;\r\n	&lt;div&gt;\r\n		Engineered with pro-level features and performance, the 12.3-effective-megapixel D300 combines brand new technologies with advanced features inherited from Nikon&amp;#39;s newly announced D3 professional digital SLR camera to offer serious photographers remarkable performance combined with agility.&lt;br /&gt;\r\n		&lt;br /&gt;\r\n		Similar to the D3, the D300 features Nikon&amp;#39;s exclusive EXPEED Image Processing System that is central to driving the speed and processing power needed for many of the camera&amp;#39;s new features. The D300 features a new 51-point autofocus system with Nikon&amp;#39;s 3D Focus Tracking feature and two new LiveView shooting modes that allow users to frame a photograph using the camera&amp;#39;s high-resolution LCD monitor. The D300 shares a similar Scene Recognition System as is found in the D3; it promises to greatly enhance the accuracy of autofocus, autoexposure, and auto white balance by recognizing the subject or scene being photographed and applying this information to the calculations for the three functions.&lt;br /&gt;\r\n		&lt;br /&gt;\r\n		The D300 reacts with lightning speed, powering up in a mere 0.13 seconds and shooting with an imperceptible 45-millisecond shutter release lag time. The D300 is capable of shooting at a rapid six frames per second and can go as fast as eight frames per second when using the optional MB-D10 multi-power battery pack. In continuous bursts, the D300 can shoot up to 100 shots at full 12.3-megapixel resolution. (NORMAL-LARGE image setting, using a SanDisk Extreme IV 1GB CompactFlash card.)&lt;br /&gt;\r\n		&lt;br /&gt;\r\n		The D300 incorporates a range of innovative technologies and features that will significantly improve the accuracy, control, and performance photographers can get from their equipment. Its new Scene Recognition System advances the use of Nikon&amp;#39;s acclaimed 1,005-segment sensor to recognize colors and light patterns that help the camera determine the subject and the type of scene being photographed before a picture is taken. This information is used to improve the accuracy of autofocus, autoexposure, and auto white balance functions in the D300. For example, the camera can track moving subjects better and by identifying them, it can also automatically select focus points faster and with greater accuracy. It can also analyze highlights and more accurately determine exposure, as well as infer light sources to deliver more accurate white balance detection.&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;!-- cpt_container_end --&gt;', '', 'Nikon D300', '', '', '', '', '', '', '', ''),
(49, 1, 'Samsung Galaxy Tab 10.1', '&lt;p&gt;\r\n	Samsung Galaxy Tab 10.1, is the world&amp;rsquo;s thinnest tablet, measuring 8.6 mm thickness, running with Android 3.0 Honeycomb OS on a 1GHz dual-core Tegra 2 processor, similar to its younger brother Samsung Galaxy Tab 8.9.&lt;/p&gt;\r\n&lt;p&gt;\r\n	Samsung Galaxy Tab 10.1 gives pure Android 3.0 experience, adding its new TouchWiz UX or TouchWiz 4.0 &amp;ndash; includes a live panel, which lets you to customize with different content, such as your pictures, bookmarks, and social feeds, sporting a 10.1 inches WXGA capacitive touch screen with 1280 x 800 pixels of resolution, equipped with 3 megapixel rear camera with LED flash and a 2 megapixel front camera, HSPA+ connectivity up to 21Mbps, 720p HD video recording capability, 1080p HD playback, DLNA support, Bluetooth 2.1, USB 2.0, gyroscope, Wi-Fi 802.11 a/b/g/n, micro-SD slot, 3.5mm headphone jack, and SIM slot, including the Samsung Stick &amp;ndash; a Bluetooth microphone that can be carried in a pocket like a pen and sound dock with powered subwoofer.&lt;/p&gt;\r\n&lt;p&gt;\r\n	Samsung Galaxy Tab 10.1 will come in 16GB / 32GB / 64GB verities and pre-loaded with Social Hub, Reader&amp;rsquo;s Hub, Music Hub and Samsung Mini Apps Tray &amp;ndash; which gives you access to more commonly used apps to help ease multitasking and it is capable of Adobe Flash Player 10.2, powered by 6860mAh battery that gives you 10hours of video-playback time.&amp;nbsp;&amp;auml;&amp;ouml;&lt;/p&gt;\r\n', '', 'Samsung Galaxy Tab 10.1', '', '', '', '', '', '', '', ''),
(42, 1, 'Apple Cinema 30&quot;', '&lt;p&gt;\r\n	&lt;font face=&quot;helvetica,geneva,arial&quot; size=&quot;2&quot;&gt;&lt;font face=&quot;Helvetica&quot; size=&quot;2&quot;&gt;The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed specifically for the creative professional, this display provides more space for easier access to all the tools and palettes needed to edit, format and composite your work. Combine this display with a Mac Pro, MacBook Pro, or PowerMac G5 and there\'s no limit to what you can achieve. &lt;br&gt;\r\n	&lt;br&gt;\r\n	&lt;/font&gt;&lt;font face=&quot;Helvetica&quot; size=&quot;2&quot;&gt;The Cinema HD features an active-matrix liquid crystal display that produces flicker-free images that deliver twice the brightness, twice the sharpness and twice the contrast ratio of a typical CRT display. Unlike other flat panels, it\'s designed with a pure digital interface to deliver distortion-free images that never need adjusting. With over 4 million digital pixels, the display is uniquely suited for scientific and technical applications such as visualizing molecular structures or analyzing geological data. &lt;br&gt;\r\n	&lt;br&gt;\r\n	&lt;/font&gt;&lt;font face=&quot;Helvetica&quot; size=&quot;2&quot;&gt;Offering accurate, brilliant color performance, the Cinema HD delivers up to 16.7 million colors across a wide gamut allowing you to see subtle nuances between colors from soft pastels to rich jewel tones. A wide viewing angle ensures uniform color from edge to edge. Apple\'s ColorSync technology allows you to create custom profiles to maintain consistent color onscreen and in print. The result: You can confidently use this display in all your color-critical applications. &lt;br&gt;\r\n	&lt;br&gt;\r\n	&lt;/font&gt;&lt;font face=&quot;Helvetica&quot; size=&quot;2&quot;&gt;Housed in a new aluminum design, the display has a very thin bezel that enhances visual accuracy. Each display features two FireWire 400 ports and two USB 2.0 ports, making attachment of desktop peripherals, such as iSight, iPod, digital and still cameras, hard drives, printers and scanners, even more accessible and convenient. Taking advantage of the much thinner and lighter footprint of an LCD, the new displays support the VESA (Video Electronics Standards Association) mounting interface standard. Customers with the optional Cinema Display VESA Mount Adapter kit gain the flexibility to mount their display in locations most appropriate for their work environment. &lt;br&gt;\r\n	&lt;br&gt;\r\n	&lt;/font&gt;&lt;font face=&quot;Helvetica&quot; size=&quot;2&quot;&gt;The Cinema HD features a single cable design with elegant breakout for the USB 2.0, FireWire 400 and a pure digital connection using the industry standard Digital Video Interface (DVI) interface. The DVI connection allows for a direct pure-digital connection.&lt;br&gt;\r\n	&lt;/font&gt;&lt;/font&gt;&lt;/p&gt;\r\n&lt;h3&gt;\r\n	Features:&lt;/h3&gt;\r\n&lt;p&gt;\r\n	Unrivaled display performance&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		30-inch (viewable) active-matrix liquid crystal display provides breathtaking image quality and vivid, richly saturated color.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Support for 2560-by-1600 pixel resolution for display of high definition still and video imagery.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Wide-format design for simultaneous display of two full pages of text and graphics.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Industry standard DVI connector for direct attachment to Mac- and Windows-based desktops and notebooks&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Incredibly wide (170 degree) horizontal and vertical viewing angle for maximum visibility and color performance.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Lightning-fast pixel response for full-motion digital video playback.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Support for 16.7 million saturated colors, for use in all graphics-intensive applications.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	Simple setup and operation&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Single cable with elegant breakout for connection to DVI, USB and FireWire ports&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Built-in two-port USB 2.0 hub for easy connection of desktop peripheral devices.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Two FireWire 400 ports to support iSight and other desktop peripherals&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	Sleek, elegant design&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Huge virtual workspace, very small footprint.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Narrow Bezel design to minimize visual impact of using dual displays&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Unique hinge design for effortless adjustment&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Support for VESA mounting solutions (Apple Cinema Display VESA Mount Adapter sold separately)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h3&gt;\r\n	Technical specifications&lt;/h3&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Screen size (diagonal viewable image size)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Apple Cinema HD Display: 30 inches (29.7-inch viewable)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Screen type&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Thin film transistor (TFT) active-matrix liquid crystal display (AMLCD)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Resolutions&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		2560 x 1600 pixels (optimum resolution)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		2048 x 1280&lt;/li&gt;\r\n	&lt;li&gt;\r\n		1920 x 1200&lt;/li&gt;\r\n	&lt;li&gt;\r\n		1280 x 800&lt;/li&gt;\r\n	&lt;li&gt;\r\n		1024 x 640&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Display colors (maximum)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		16.7 million&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Viewing angle (typical)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		170° horizontal; 170° vertical&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Brightness (typical)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		30-inch Cinema HD Display: 400 cd/m2&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Contrast ratio (typical)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		700:1&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Response time (typical)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		16 ms&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Pixel pitch&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		30-inch Cinema HD Display: 0.250 mm&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Screen treatment&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Antiglare hardcoat&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;User controls (hardware and software)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Display Power,&lt;/li&gt;\r\n	&lt;li&gt;\r\n		System sleep, wake&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Brightness&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Monitor tilt&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Connectors and cables&lt;/b&gt;&lt;br&gt;\r\n	Cable&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		DVI (Digital Visual Interface)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		FireWire 400&lt;/li&gt;\r\n	&lt;li&gt;\r\n		USB 2.0&lt;/li&gt;\r\n	&lt;li&gt;\r\n		DC power (24 V)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	Connectors&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Two-port, self-powered USB 2.0 hub&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Two FireWire 400 ports&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Kensington security port&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;VESA mount adapter&lt;/b&gt;&lt;br&gt;\r\n	Requires optional Cinema Display VESA Mount Adapter (M9649G/A)&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Compatible with VESA FDMI (MIS-D, 100, C) compliant mounting solutions&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Electrical requirements&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Input voltage: 100-240 VAC 50-60Hz&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Maximum power when operating: 150W&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Energy saver mode: 3W or less&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Environmental requirements&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Operating temperature: 50° to 95° F (10° to 35° C)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Storage temperature: -40° to 116° F (-40° to 47° C)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Operating humidity: 20% to 80% noncondensing&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Maximum operating altitude: 10,000 feet&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Agency approvals&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		FCC Part 15 Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		EN55022 Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		EN55024&lt;/li&gt;\r\n	&lt;li&gt;\r\n		VCCI Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		AS/NZS 3548 Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		CNS 13438 Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		ICES-003 Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		ISO 13406 part 2&lt;/li&gt;\r\n	&lt;li&gt;\r\n		MPR II&lt;/li&gt;\r\n	&lt;li&gt;\r\n		IEC 60950&lt;/li&gt;\r\n	&lt;li&gt;\r\n		UL 60950&lt;/li&gt;\r\n	&lt;li&gt;\r\n		CSA 60950&lt;/li&gt;\r\n	&lt;li&gt;\r\n		EN60950&lt;/li&gt;\r\n	&lt;li&gt;\r\n		ENERGY STAR&lt;/li&gt;\r\n	&lt;li&gt;\r\n		TCO \'03&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Size and weight&lt;/b&gt;&lt;br&gt;\r\n	30-inch Apple Cinema HD Display&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Height: 21.3 inches (54.3 cm)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Width: 27.2 inches (68.8 cm)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Depth: 8.46 inches (21.5 cm)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Weight: 27.5 pounds (12.5 kg)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;System Requirements&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Mac Pro, all graphic options&lt;/li&gt;\r\n	&lt;li&gt;\r\n		MacBook Pro&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Power Mac G5 (PCI-X) with ATI Radeon 9650 or better or NVIDIA GeForce 6800 GT DDL or better&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Power Mac G5 (PCI Express), all graphics options&lt;/li&gt;\r\n	&lt;li&gt;\r\n		PowerBook G4 with dual-link DVI support&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Windows PC and graphics card that supports DVI ports with dual-link digital bandwidth and VESA DDC standard for plug-and-play setup&lt;/li&gt;\r\n&lt;/ul&gt;\r\n', '', 'Apple Cinema 30', '', '', '', '', '', '', '', ''),
(30, 1, 'Canon EOS 5D', '&lt;p&gt;\r\n	Canon\'s press material for the EOS 5D states that it \'defines (a) new D-SLR category\', while we\'re not typically too concerned with marketing talk this particular statement is clearly pretty accurate. The EOS 5D is unlike any previous digital SLR in that it combines a full-frame (35 mm sized) high resolution sensor (12.8 megapixels) with a relatively compact body (slightly larger than the EOS 20D, although in your hand it feels noticeably \'chunkier\'). The EOS 5D is aimed to slot in between the EOS 20D and the EOS-1D professional digital SLR\'s, an important difference when compared to the latter is that the EOS 5D doesn\'t have any environmental seals. While Canon don\'t specifically refer to the EOS 5D as a \'professional\' digital SLR it will have obvious appeal to professionals who want a high quality digital SLR in a body lighter than the EOS-1D. It will also no doubt appeal to current EOS 20D owners (although lets hope they\'ve not bought too many EF-S lenses...) äë&lt;/p&gt;\r\n', '', 'sdf', '', '', '', '', '', '', '', ''),
(35, 2, 'Product 8', '&lt;p&gt;\r\n	Product 8&lt;/p&gt;\r\n', '', 'Product 8', '', '', '', '', '', '', '', ''),
(48, 2, 'iPod Classic', '&lt;div class=&quot;cpt_product_description &quot;&gt;\r\n	&lt;div&gt;\r\n		&lt;p&gt;\r\n			&lt;strong&gt;More room to move.&lt;/strong&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;strong&gt;Cover Flow.&lt;/strong&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Browse through your music collection by flipping through album art. Select an album to turn it over and see the track list.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;strong&gt;Enhanced interface.&lt;/strong&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Experience a whole new way to browse and view your music and video.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;strong&gt;Sleeker design.&lt;/strong&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Beautiful, durable, and sleeker than ever, iPod classic now features an anodized aluminum and polished stainless steel enclosure with rounded edges.&lt;/p&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;!-- cpt_container_end --&gt;', '', 'iPod Classic', '', '', '', '', '', '', '', ''),
(40, 2, 'iPhone', '&lt;p class=&quot;intro&quot;&gt;\r\n	iPhone is a revolutionary new mobile phone that allows you to make a call by simply tapping a name or number in your address book, a favorites list, or a call log. It also automatically syncs all your contacts from a PC, Mac, or Internet service. And it lets you select and listen to voicemail messages in whatever order you want just like email.&lt;/p&gt;\r\n', '', 'iPhone', '', '', '', '', '', '', '', ''),
(28, 2, 'HTC Touch HD', '&lt;p&gt;\r\n	HTC Touch - in High Definition. Watch music videos and streaming content in awe-inspiring high definition clarity for a mobile experience you never thought possible. Seductively sleek, the HTC Touch HD provides the next generation of mobile functionality, all at a simple touch. Fully integrated with Windows Mobile Professional 6.1, ultrafast 3.5G, GPS, 5MP camera, plus lots more - all delivered on a breathtakingly crisp 3.8&amp;quot; WVGA touchscreen - you can take control of your mobile world with the HTC Touch HD.&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;Features&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Processor Qualcomm&amp;reg; MSM 7201A&amp;trade; 528 MHz&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Windows Mobile&amp;reg; 6.1 Professional Operating System&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Memory: 512 MB ROM, 288 MB RAM&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Dimensions: 115 mm x 62.8 mm x 12 mm / 146.4 grams&lt;/li&gt;\r\n	&lt;li&gt;\r\n		3.8-inch TFT-LCD flat touch-sensitive screen with 480 x 800 WVGA resolution&lt;/li&gt;\r\n	&lt;li&gt;\r\n		HSDPA/WCDMA: Europe/Asia: 900/2100 MHz; Up to 2 Mbps up-link and 7.2 Mbps down-link speeds&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Quad-band GSM/GPRS/EDGE: Europe/Asia: 850/900/1800/1900 MHz (Band frequency, HSUPA availability, and data speed are operator dependent.)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Device Control via HTC TouchFLO&amp;trade; 3D &amp;amp; Touch-sensitive front panel buttons&lt;/li&gt;\r\n	&lt;li&gt;\r\n		GPS and A-GPS ready&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Bluetooth&amp;reg; 2.0 with Enhanced Data Rate and A2DP for wireless stereo headsets&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Wi-Fi&amp;reg;: IEEE 802.11 b/g&lt;/li&gt;\r\n	&lt;li&gt;\r\n		HTC ExtUSB&amp;trade; (11-pin mini-USB 2.0)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		5 megapixel color camera with auto focus&lt;/li&gt;\r\n	&lt;li&gt;\r\n		VGA CMOS color camera&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Built-in 3.5 mm audio jack, microphone, speaker, and FM radio&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Ring tone formats: AAC, AAC+, eAAC+, AMR-NB, AMR-WB, QCP, MP3, WMA, WAV&lt;/li&gt;\r\n	&lt;li&gt;\r\n		40 polyphonic and standard MIDI format 0 and 1 (SMF)/SP MIDI&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Rechargeable Lithium-ion or Lithium-ion polymer 1350 mAh battery&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Expansion Slot: microSD&amp;trade; memory card (SD 2.0 compatible)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		AC Adapter Voltage range/frequency: 100 ~ 240V AC, 50/60 Hz DC output: 5V and 1A&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Special Features: FM Radio, G-Sensor&lt;/li&gt;\r\n&lt;/ul&gt;\r\n', '', '	 HTC Touch HD', '', '', '', '', '', '', '', ''),
(44, 2, 'MacBook Air', '&lt;div&gt;\r\n	MacBook Air is ultrathin, ultraportable, and ultra unlike anything else. But you don&amp;rsquo;t lose inches and pounds overnight. It&amp;rsquo;s the result of rethinking conventions. Of multiple wireless innovations. And of breakthrough design. With MacBook Air, mobile computing suddenly has a new standard.&lt;/div&gt;\r\n', '', 'MacBook Air', '', '', '', '', '', '', '', ''),
(45, 2, 'MacBook Pro', '&lt;div class=&quot;cpt_product_description &quot;&gt;\r\n	&lt;div&gt;\r\n		&lt;p&gt;\r\n			&lt;b&gt;Latest Intel mobile architecture&lt;/b&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Powered by the most advanced mobile processors from Intel, the new Core 2 Duo MacBook Pro is over 50% faster than the original Core Duo MacBook Pro and now supports up to 4GB of RAM.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;b&gt;Leading-edge graphics&lt;/b&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			The NVIDIA GeForce 8600M GT delivers exceptional graphics processing power. For the ultimate creative canvas, you can even configure the 17-inch model with a 1920-by-1200 resolution display.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;b&gt;Designed for life on the road&lt;/b&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Innovations such as a magnetic power connection and an illuminated keyboard with ambient light sensor put the MacBook Pro in a class by itself.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;b&gt;Connect. Create. Communicate.&lt;/b&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Quickly set up a video conference with the built-in iSight camera. Control presentations and media from up to 30 feet away with the included Apple Remote. Connect to high-bandwidth peripherals with FireWire 800 and DVI.&lt;/p&gt;\r\n		&lt;p&gt;\r\n			&lt;b&gt;Next-generation wireless&lt;/b&gt;&lt;/p&gt;\r\n		&lt;p&gt;\r\n			Featuring 802.11n wireless technology, the MacBook Pro delivers up to five times the performance and up to twice the range of previous-generation technologies.&lt;/p&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;!-- cpt_container_end --&gt;', '', 'MacBook Pro', '', '', '', '', '', '', '', ''),
(29, 2, 'Palm Treo Pro', '&lt;p&gt;\r\n	Redefine your workday with the Palm Treo Pro smartphone. Perfectly balanced, you can respond to business and personal email, stay on top of appointments and contacts, and use Wi-Fi or GPS when you&amp;rsquo;re out and about. Then watch a video on YouTube, catch up with news and sports on the web, or listen to a few songs. Balance your work and play the way you like it, with the Palm Treo Pro.&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;Features&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Windows Mobile&amp;reg; 6.1 Professional Edition&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Qualcomm&amp;reg; MSM7201 400MHz Processor&lt;/li&gt;\r\n	&lt;li&gt;\r\n		320x320 transflective colour TFT touchscreen&lt;/li&gt;\r\n	&lt;li&gt;\r\n		HSDPA/UMTS/EDGE/GPRS/GSM radio&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Tri-band UMTS &amp;mdash; 850MHz, 1900MHz, 2100MHz&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Quad-band GSM &amp;mdash; 850/900/1800/1900&lt;/li&gt;\r\n	&lt;li&gt;\r\n		802.11b/g with WPA, WPA2, and 801.1x authentication&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Built-in GPS&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Bluetooth Version: 2.0 + Enhanced Data Rate&lt;/li&gt;\r\n	&lt;li&gt;\r\n		256MB storage (100MB user available), 128MB RAM&lt;/li&gt;\r\n	&lt;li&gt;\r\n		2.0 megapixel camera, up to 8x digital zoom and video capture&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Removable, rechargeable 1500mAh lithium-ion battery&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Up to 5.0 hours talk time and up to 250 hours standby&lt;/li&gt;\r\n	&lt;li&gt;\r\n		MicroSDHC card expansion (up to 32GB supported)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		MicroUSB 2.0 for synchronization and charging&lt;/li&gt;\r\n	&lt;li&gt;\r\n		3.5mm stereo headset jack&lt;/li&gt;\r\n	&lt;li&gt;\r\n		60mm (W) x 114mm (L) x 13.5mm (D) / 133g&lt;/li&gt;\r\n&lt;/ul&gt;\r\n', '', 'Palm Treo Pro', '', '', '', '', '', '', '', ''),
(36, 2, 'iPod Nano', '&lt;div&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;Video in your pocket.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Its the small iPod with one very big idea: video. The worlds most popular music player now lets you enjoy movies, TV shows, and more on a two-inch display thats 65% brighter than before.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;Cover Flow.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Browse through your music collection by flipping through album art. Select an album to turn it over and see the track list.&lt;strong&gt;&amp;nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;Enhanced interface.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Experience a whole new way to browse and view your music and video.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;Sleek and colorful.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		With an anodized aluminum and polished stainless steel enclosure and a choice of five colors, iPod nano is dressed to impress.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;iTunes.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Available as a free download, iTunes makes it easy to browse and buy millions of songs, movies, TV shows, audiobooks, and games and download free podcasts all at the iTunes Store. And you can import your own music, manage your whole media library, and sync your iPod or iPhone with ease.&lt;/p&gt;\r\n&lt;/div&gt;\r\n', '', 'iPod Nano', '', '', '', '', '', '', '', ''),
(46, 2, 'Sony VAIO', '&lt;div&gt;\r\n	Unprecedented power. The next generation of processing technology has arrived. Built into the newest VAIO notebooks lies Intel&amp;#39;s latest, most powerful innovation yet: Intel&amp;reg; Centrino&amp;reg; 2 processor technology. Boasting incredible speed, expanded wireless connectivity, enhanced multimedia support and greater energy efficiency, all the high-performance essentials are seamlessly combined into a single chip.&lt;/div&gt;\r\n', '', 'Sony VAIO', '', '', '', '', '', '', '', ''),
(47, 2, 'HP LP3065', '&lt;p&gt;\r\n	Stop your co-workers in their tracks with the stunning new 30-inch diagonal HP LP3065 Flat Panel Monitor. This flagship monitor features best-in-class performance and presentation features on a huge wide-aspect screen while letting you work as comfortably as possible - you might even forget you&amp;#39;re at the office&lt;/p&gt;\r\n', '', 'HP LP3065', '', '', '', '', '', '', '', ''),
(32, 2, 'iPod Touch', '&lt;p&gt;\r\n	&lt;strong&gt;Revolutionary multi-touch interface.&lt;/strong&gt;&lt;br /&gt;\r\n	iPod touch features the same multi-touch screen technology as iPhone. Pinch to zoom in on a photo. Scroll through your songs and videos with a flick. Flip through your library by album artwork with Cover Flow.&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;Gorgeous 3.5-inch widescreen display.&lt;/strong&gt;&lt;br /&gt;\r\n	Watch your movies, TV shows, and photos come alive with bright, vivid color on the 320-by-480-pixel display.&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;Music downloads straight from iTunes.&lt;/strong&gt;&lt;br /&gt;\r\n	Shop the iTunes Wi-Fi Music Store from anywhere with Wi-Fi.1 Browse or search to find the music youre looking for, preview it, and buy it with just a tap.&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;Surf the web with Wi-Fi.&lt;/strong&gt;&lt;br /&gt;\r\n	Browse the web using Safari and watch YouTube videos on the first iPod with Wi-Fi built in&lt;br /&gt;\r\n	&amp;nbsp;&lt;/p&gt;\r\n', '', '	 iPod Touch', '', '', '', '', '', '', '', ''),
(41, 2, 'iMac', '&lt;div&gt;\r\n	Just when you thought iMac had everything, now there&acute;s even more. More powerful Intel Core 2 Duo processors. And more memory standard. Combine this with Mac OS X Leopard and iLife &acute;08, and it&acute;s more all-in-one than ever. iMac packs amazing performance into a stunningly slim space.&lt;/div&gt;\r\n', '', 'iMac', '', '', '', '', '', '', '', ''),
(33, 2, 'Samsung SyncMaster 941BW', '&lt;div&gt;\r\n	Imagine the advantages of going big without slowing down. The big 19&amp;quot; 941BW monitor combines wide aspect ratio with fast pixel response time, for bigger images, more room to work and crisp motion. In addition, the exclusive MagicBright 2, MagicColor and MagicTune technologies help deliver the ideal image in every situation, while sleek, narrow bezels and adjustable stands deliver style just the way you want it. With the Samsung 941BW widescreen analog/digital LCD monitor, it&amp;#39;s not hard to imagine.&lt;/div&gt;\r\n', '', 'Samsung SyncMaster 941BW', '', '', '', '', '', '', '', ''),
(34, 2, 'iPod Shuffle', '&lt;div&gt;\r\n	&lt;strong&gt;Born to be worn.&lt;/strong&gt;\r\n	&lt;p&gt;\r\n		Clip on the worlds most wearable music player and take up to 240 songs with you anywhere. Choose from five colors including four new hues to make your musical fashion statement.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;strong&gt;Random meets rhythm.&lt;/strong&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		With iTunes autofill, iPod shuffle can deliver a new musical experience every time you sync. For more randomness, you can shuffle songs during playback with the slide of a switch.&lt;/p&gt;\r\n	&lt;strong&gt;Everything is easy.&lt;/strong&gt;\r\n	&lt;p&gt;\r\n		Charge and sync with the included USB dock. Operate the iPod shuffle controls with one hand. Enjoy up to 12 hours straight of skip-free music playback.&lt;/p&gt;\r\n&lt;/div&gt;\r\n', '', 'iPod Shuffle', '', '', '', '', '', '', '', ''),
(43, 2, 'MacBook', '&lt;div&gt;\r\n	&lt;p&gt;\r\n		&lt;b&gt;Intel Core 2 Duo processor&lt;/b&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Powered by an Intel Core 2 Duo processor at speeds up to 2.16GHz, the new MacBook is the fastest ever.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;b&gt;1GB memory, larger hard drives&lt;/b&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		The new MacBook now comes with 1GB of memory standard and larger hard drives for the entire line perfect for running more of your favorite applications and storing growing media collections.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;b&gt;Sleek, 1.08-inch-thin design&lt;/b&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		MacBook makes it easy to hit the road thanks to its tough polycarbonate case, built-in wireless technologies, and innovative MagSafe Power Adapter that releases automatically if someone accidentally trips on the cord.&lt;/p&gt;\r\n	&lt;p&gt;\r\n		&lt;b&gt;Built-in iSight camera&lt;/b&gt;&lt;/p&gt;\r\n	&lt;p&gt;\r\n		Right out of the box, you can have a video chat with friends or family,2 record a video at your desk, or take fun pictures with Photo Booth&lt;/p&gt;\r\n&lt;/div&gt;\r\n', '', 'MacBook', '', '', '', '', '', '', '', ''),
(31, 2, 'Nikon D300', '&lt;div class=&quot;cpt_product_description &quot;&gt;\r\n	&lt;div&gt;\r\n		Engineered with pro-level features and performance, the 12.3-effective-megapixel D300 combines brand new technologies with advanced features inherited from Nikon&amp;#39;s newly announced D3 professional digital SLR camera to offer serious photographers remarkable performance combined with agility.&lt;br /&gt;\r\n		&lt;br /&gt;\r\n		Similar to the D3, the D300 features Nikon&amp;#39;s exclusive EXPEED Image Processing System that is central to driving the speed and processing power needed for many of the camera&amp;#39;s new features. The D300 features a new 51-point autofocus system with Nikon&amp;#39;s 3D Focus Tracking feature and two new LiveView shooting modes that allow users to frame a photograph using the camera&amp;#39;s high-resolution LCD monitor. The D300 shares a similar Scene Recognition System as is found in the D3; it promises to greatly enhance the accuracy of autofocus, autoexposure, and auto white balance by recognizing the subject or scene being photographed and applying this information to the calculations for the three functions.&lt;br /&gt;\r\n		&lt;br /&gt;\r\n		The D300 reacts with lightning speed, powering up in a mere 0.13 seconds and shooting with an imperceptible 45-millisecond shutter release lag time. The D300 is capable of shooting at a rapid six frames per second and can go as fast as eight frames per second when using the optional MB-D10 multi-power battery pack. In continuous bursts, the D300 can shoot up to 100 shots at full 12.3-megapixel resolution. (NORMAL-LARGE image setting, using a SanDisk Extreme IV 1GB CompactFlash card.)&lt;br /&gt;\r\n		&lt;br /&gt;\r\n		The D300 incorporates a range of innovative technologies and features that will significantly improve the accuracy, control, and performance photographers can get from their equipment. Its new Scene Recognition System advances the use of Nikon&amp;#39;s acclaimed 1,005-segment sensor to recognize colors and light patterns that help the camera determine the subject and the type of scene being photographed before a picture is taken. This information is used to improve the accuracy of autofocus, autoexposure, and auto white balance functions in the D300. For example, the camera can track moving subjects better and by identifying them, it can also automatically select focus points faster and with greater accuracy. It can also analyze highlights and more accurately determine exposure, as well as infer light sources to deliver more accurate white balance detection.&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;!-- cpt_container_end --&gt;', '', 'Nikon D300', '', '', '', '', '', '', '', '');
INSERT INTO `oc_product_description` (`product_id`, `language_id`, `name`, `description`, `tag`, `meta_title`, `meta_description`, `meta_keyword`, `seo_keyword`, `seo_h1`, `seo_h2`, `seo_h3`, `image_title`, `image_alt`) VALUES
(49, 2, 'Samsung Galaxy Tab 10.1', '&lt;p&gt;\r\n	Samsung Galaxy Tab 10.1, is the world&amp;rsquo;s thinnest tablet, measuring 8.6 mm thickness, running with Android 3.0 Honeycomb OS on a 1GHz dual-core Tegra 2 processor, similar to its younger brother Samsung Galaxy Tab 8.9.&lt;/p&gt;\r\n&lt;p&gt;\r\n	Samsung Galaxy Tab 10.1 gives pure Android 3.0 experience, adding its new TouchWiz UX or TouchWiz 4.0 &amp;ndash; includes a live panel, which lets you to customize with different content, such as your pictures, bookmarks, and social feeds, sporting a 10.1 inches WXGA capacitive touch screen with 1280 x 800 pixels of resolution, equipped with 3 megapixel rear camera with LED flash and a 2 megapixel front camera, HSPA+ connectivity up to 21Mbps, 720p HD video recording capability, 1080p HD playback, DLNA support, Bluetooth 2.1, USB 2.0, gyroscope, Wi-Fi 802.11 a/b/g/n, micro-SD slot, 3.5mm headphone jack, and SIM slot, including the Samsung Stick &amp;ndash; a Bluetooth microphone that can be carried in a pocket like a pen and sound dock with powered subwoofer.&lt;/p&gt;\r\n&lt;p&gt;\r\n	Samsung Galaxy Tab 10.1 will come in 16GB / 32GB / 64GB verities and pre-loaded with Social Hub, Reader&amp;rsquo;s Hub, Music Hub and Samsung Mini Apps Tray &amp;ndash; which gives you access to more commonly used apps to help ease multitasking and it is capable of Adobe Flash Player 10.2, powered by 6860mAh battery that gives you 10hours of video-playback time.&amp;nbsp;&amp;auml;&amp;ouml;&lt;/p&gt;\r\n', '', 'Samsung Galaxy Tab 10.1', '', '', '', '', '', '', '', ''),
(42, 2, 'Apple Cinema 30&quot;', '&lt;p&gt;\r\n	&lt;font face=&quot;helvetica,geneva,arial&quot; size=&quot;2&quot;&gt;&lt;font face=&quot;Helvetica&quot; size=&quot;2&quot;&gt;The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed specifically for the creative professional, this display provides more space for easier access to all the tools and palettes needed to edit, format and composite your work. Combine this display with a Mac Pro, MacBook Pro, or PowerMac G5 and there\'s no limit to what you can achieve. &lt;br&gt;\r\n	&lt;br&gt;\r\n	&lt;/font&gt;&lt;font face=&quot;Helvetica&quot; size=&quot;2&quot;&gt;The Cinema HD features an active-matrix liquid crystal display that produces flicker-free images that deliver twice the brightness, twice the sharpness and twice the contrast ratio of a typical CRT display. Unlike other flat panels, it\'s designed with a pure digital interface to deliver distortion-free images that never need adjusting. With over 4 million digital pixels, the display is uniquely suited for scientific and technical applications such as visualizing molecular structures or analyzing geological data. &lt;br&gt;\r\n	&lt;br&gt;\r\n	&lt;/font&gt;&lt;font face=&quot;Helvetica&quot; size=&quot;2&quot;&gt;Offering accurate, brilliant color performance, the Cinema HD delivers up to 16.7 million colors across a wide gamut allowing you to see subtle nuances between colors from soft pastels to rich jewel tones. A wide viewing angle ensures uniform color from edge to edge. Apple\'s ColorSync technology allows you to create custom profiles to maintain consistent color onscreen and in print. The result: You can confidently use this display in all your color-critical applications. &lt;br&gt;\r\n	&lt;br&gt;\r\n	&lt;/font&gt;&lt;font face=&quot;Helvetica&quot; size=&quot;2&quot;&gt;Housed in a new aluminum design, the display has a very thin bezel that enhances visual accuracy. Each display features two FireWire 400 ports and two USB 2.0 ports, making attachment of desktop peripherals, such as iSight, iPod, digital and still cameras, hard drives, printers and scanners, even more accessible and convenient. Taking advantage of the much thinner and lighter footprint of an LCD, the new displays support the VESA (Video Electronics Standards Association) mounting interface standard. Customers with the optional Cinema Display VESA Mount Adapter kit gain the flexibility to mount their display in locations most appropriate for their work environment. &lt;br&gt;\r\n	&lt;br&gt;\r\n	&lt;/font&gt;&lt;font face=&quot;Helvetica&quot; size=&quot;2&quot;&gt;The Cinema HD features a single cable design with elegant breakout for the USB 2.0, FireWire 400 and a pure digital connection using the industry standard Digital Video Interface (DVI) interface. The DVI connection allows for a direct pure-digital connection.&lt;br&gt;\r\n	&lt;/font&gt;&lt;/font&gt;&lt;/p&gt;\r\n&lt;h3&gt;\r\n	Features:&lt;/h3&gt;\r\n&lt;p&gt;\r\n	Unrivaled display performance&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		30-inch (viewable) active-matrix liquid crystal display provides breathtaking image quality and vivid, richly saturated color.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Support for 2560-by-1600 pixel resolution for display of high definition still and video imagery.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Wide-format design for simultaneous display of two full pages of text and graphics.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Industry standard DVI connector for direct attachment to Mac- and Windows-based desktops and notebooks&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Incredibly wide (170 degree) horizontal and vertical viewing angle for maximum visibility and color performance.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Lightning-fast pixel response for full-motion digital video playback.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Support for 16.7 million saturated colors, for use in all graphics-intensive applications.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	Simple setup and operation&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Single cable with elegant breakout for connection to DVI, USB and FireWire ports&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Built-in two-port USB 2.0 hub for easy connection of desktop peripheral devices.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Two FireWire 400 ports to support iSight and other desktop peripherals&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	Sleek, elegant design&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Huge virtual workspace, very small footprint.&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Narrow Bezel design to minimize visual impact of using dual displays&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Unique hinge design for effortless adjustment&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Support for VESA mounting solutions (Apple Cinema Display VESA Mount Adapter sold separately)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h3&gt;\r\n	Technical specifications&lt;/h3&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Screen size (diagonal viewable image size)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Apple Cinema HD Display: 30 inches (29.7-inch viewable)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Screen type&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Thin film transistor (TFT) active-matrix liquid crystal display (AMLCD)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Resolutions&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		2560 x 1600 pixels (optimum resolution)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		2048 x 1280&lt;/li&gt;\r\n	&lt;li&gt;\r\n		1920 x 1200&lt;/li&gt;\r\n	&lt;li&gt;\r\n		1280 x 800&lt;/li&gt;\r\n	&lt;li&gt;\r\n		1024 x 640&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Display colors (maximum)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		16.7 million&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Viewing angle (typical)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		170° horizontal; 170° vertical&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Brightness (typical)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		30-inch Cinema HD Display: 400 cd/m2&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Contrast ratio (typical)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		700:1&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Response time (typical)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		16 ms&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Pixel pitch&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		30-inch Cinema HD Display: 0.250 mm&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Screen treatment&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Antiglare hardcoat&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;User controls (hardware and software)&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Display Power,&lt;/li&gt;\r\n	&lt;li&gt;\r\n		System sleep, wake&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Brightness&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Monitor tilt&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Connectors and cables&lt;/b&gt;&lt;br&gt;\r\n	Cable&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		DVI (Digital Visual Interface)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		FireWire 400&lt;/li&gt;\r\n	&lt;li&gt;\r\n		USB 2.0&lt;/li&gt;\r\n	&lt;li&gt;\r\n		DC power (24 V)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	Connectors&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Two-port, self-powered USB 2.0 hub&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Two FireWire 400 ports&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Kensington security port&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;VESA mount adapter&lt;/b&gt;&lt;br&gt;\r\n	Requires optional Cinema Display VESA Mount Adapter (M9649G/A)&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Compatible with VESA FDMI (MIS-D, 100, C) compliant mounting solutions&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Electrical requirements&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Input voltage: 100-240 VAC 50-60Hz&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Maximum power when operating: 150W&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Energy saver mode: 3W or less&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Environmental requirements&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Operating temperature: 50° to 95° F (10° to 35° C)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Storage temperature: -40° to 116° F (-40° to 47° C)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Operating humidity: 20% to 80% noncondensing&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Maximum operating altitude: 10,000 feet&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Agency approvals&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		FCC Part 15 Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		EN55022 Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		EN55024&lt;/li&gt;\r\n	&lt;li&gt;\r\n		VCCI Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		AS/NZS 3548 Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		CNS 13438 Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		ICES-003 Class B&lt;/li&gt;\r\n	&lt;li&gt;\r\n		ISO 13406 part 2&lt;/li&gt;\r\n	&lt;li&gt;\r\n		MPR II&lt;/li&gt;\r\n	&lt;li&gt;\r\n		IEC 60950&lt;/li&gt;\r\n	&lt;li&gt;\r\n		UL 60950&lt;/li&gt;\r\n	&lt;li&gt;\r\n		CSA 60950&lt;/li&gt;\r\n	&lt;li&gt;\r\n		EN60950&lt;/li&gt;\r\n	&lt;li&gt;\r\n		ENERGY STAR&lt;/li&gt;\r\n	&lt;li&gt;\r\n		TCO \'03&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;Size and weight&lt;/b&gt;&lt;br&gt;\r\n	30-inch Apple Cinema HD Display&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Height: 21.3 inches (54.3 cm)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Width: 27.2 inches (68.8 cm)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Depth: 8.46 inches (21.5 cm)&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Weight: 27.5 pounds (12.5 kg)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;\r\n	&lt;b&gt;System Requirements&lt;/b&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n	&lt;li&gt;\r\n		Mac Pro, all graphic options&lt;/li&gt;\r\n	&lt;li&gt;\r\n		MacBook Pro&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Power Mac G5 (PCI-X) with ATI Radeon 9650 or better or NVIDIA GeForce 6800 GT DDL or better&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Power Mac G5 (PCI Express), all graphics options&lt;/li&gt;\r\n	&lt;li&gt;\r\n		PowerBook G4 with dual-link DVI support&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Windows PC and graphics card that supports DVI ports with dual-link digital bandwidth and VESA DDC standard for plug-and-play setup&lt;/li&gt;\r\n&lt;/ul&gt;\r\n', '', 'Apple Cinema 30', '', '', '', '', '', '', '', ''),
(30, 2, 'Canon EOS 5D', '&lt;p&gt;\r\n	Canon\'s press material for the EOS 5D states that it \'defines (a) new D-SLR category\', while we\'re not typically too concerned with marketing talk this particular statement is clearly pretty accurate. The EOS 5D is unlike any previous digital SLR in that it combines a full-frame (35 mm sized) high resolution sensor (12.8 megapixels) with a relatively compact body (slightly larger than the EOS 20D, although in your hand it feels noticeably \'chunkier\'). The EOS 5D is aimed to slot in between the EOS 20D and the EOS-1D professional digital SLR\'s, an important difference when compared to the latter is that the EOS 5D doesn\'t have any environmental seals. While Canon don\'t specifically refer to the EOS 5D as a \'professional\' digital SLR it will have obvious appeal to professionals who want a high quality digital SLR in a body lighter than the EOS-1D. It will also no doubt appeal to current EOS 20D owners (although lets hope they\'ve not bought too many EF-S lenses...) äë&lt;/p&gt;\r\n', '', 'sdf', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_discount`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_discount`;
CREATE TABLE `oc_product_discount` (
  `product_discount_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `quantity` int(4) NOT NULL DEFAULT '0',
  `priority` int(5) NOT NULL DEFAULT '1',
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_discount`
--

INSERT INTO `oc_product_discount` (`product_discount_id`, `product_id`, `customer_group_id`, `quantity`, `priority`, `price`, `date_start`, `date_end`) VALUES
(440, 42, 1, 30, 1, '66.0000', '0000-00-00', '0000-00-00'),
(439, 42, 1, 20, 1, '77.0000', '0000-00-00', '0000-00-00'),
(438, 42, 1, 10, 1, '88.0000', '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_filter`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_filter`;
CREATE TABLE `oc_product_filter` (
  `product_id` int(11) NOT NULL,
  `filter_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_image`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_image`;
CREATE TABLE `oc_product_image` (
  `product_image_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_image`
--

INSERT INTO `oc_product_image` (`product_image_id`, `product_id`, `image`, `sort_order`) VALUES
(2345, 30, 'catalog/demo/canon_eos_5d_2.jpg', 0),
(2321, 47, 'catalog/demo/hp_3.jpg', 0),
(2035, 28, 'catalog/demo/htc_touch_hd_2.jpg', 0),
(2351, 41, 'catalog/demo/imac_3.jpg', 0),
(1982, 40, 'catalog/demo/iphone_6.jpg', 0),
(2001, 36, 'catalog/demo/ipod_nano_5.jpg', 0),
(2000, 36, 'catalog/demo/ipod_nano_4.jpg', 0),
(2005, 34, 'catalog/demo/ipod_shuffle_5.jpg', 0),
(2004, 34, 'catalog/demo/ipod_shuffle_4.jpg', 0),
(2011, 32, 'catalog/demo/ipod_touch_7.jpg', 0),
(2010, 32, 'catalog/demo/ipod_touch_6.jpg', 0),
(2009, 32, 'catalog/demo/ipod_touch_5.jpg', 0),
(1971, 43, 'catalog/demo/macbook_5.jpg', 0),
(1970, 43, 'catalog/demo/macbook_4.jpg', 0),
(1974, 44, 'catalog/demo/macbook_air_4.jpg', 0),
(1973, 44, 'catalog/demo/macbook_air_2.jpg', 0),
(1977, 45, 'catalog/demo/macbook_pro_2.jpg', 0),
(1976, 45, 'catalog/demo/macbook_pro_3.jpg', 0),
(1986, 31, 'catalog/demo/nikon_d300_3.jpg', 0),
(1985, 31, 'catalog/demo/nikon_d300_2.jpg', 0),
(1988, 29, 'catalog/demo/palm_treo_pro_3.jpg', 0),
(1995, 46, 'catalog/demo/sony_vaio_5.jpg', 0),
(1994, 46, 'catalog/demo/sony_vaio_4.jpg', 0),
(1991, 48, 'catalog/demo/ipod_classic_4.jpg', 0),
(1990, 48, 'catalog/demo/ipod_classic_3.jpg', 0),
(1981, 40, 'catalog/demo/iphone_2.jpg', 0),
(1980, 40, 'catalog/demo/iphone_5.jpg', 0),
(2344, 30, 'catalog/demo/canon_eos_5d_3.jpg', 0),
(2320, 47, 'catalog/demo/hp_2.jpg', 0),
(2034, 28, 'catalog/demo/htc_touch_hd_3.jpg', 0),
(2350, 41, 'catalog/demo/imac_2.jpg', 0),
(1979, 40, 'catalog/demo/iphone_3.jpg', 0),
(1978, 40, 'catalog/demo/iphone_4.jpg', 0),
(1989, 48, 'catalog/demo/ipod_classic_2.jpg', 0),
(1999, 36, 'catalog/demo/ipod_nano_2.jpg', 0),
(1998, 36, 'catalog/demo/ipod_nano_3.jpg', 0),
(2003, 34, 'catalog/demo/ipod_shuffle_2.jpg', 0),
(2002, 34, 'catalog/demo/ipod_shuffle_3.jpg', 0),
(2008, 32, 'catalog/demo/ipod_touch_2.jpg', 0),
(2007, 32, 'catalog/demo/ipod_touch_3.jpg', 0),
(2006, 32, 'catalog/demo/ipod_touch_4.jpg', 0),
(1969, 43, 'catalog/demo/macbook_2.jpg', 0),
(1968, 43, 'catalog/demo/macbook_3.jpg', 0),
(1972, 44, 'catalog/demo/macbook_air_3.jpg', 0),
(1975, 45, 'catalog/demo/macbook_pro_4.jpg', 0),
(1984, 31, 'catalog/demo/nikon_d300_4.jpg', 0),
(1983, 31, 'catalog/demo/nikon_d300_5.jpg', 0),
(1987, 29, 'catalog/demo/palm_treo_pro_2.jpg', 0),
(1993, 46, 'catalog/demo/sony_vaio_2.jpg', 0),
(1992, 46, 'catalog/demo/sony_vaio_3.jpg', 0),
(2327, 49, 'catalog/demo/samsung_tab_7.jpg', 0),
(2326, 49, 'catalog/demo/samsung_tab_6.jpg', 0),
(2325, 49, 'catalog/demo/samsung_tab_5.jpg', 0),
(2324, 49, 'catalog/demo/samsung_tab_4.jpg', 0),
(2323, 49, 'catalog/demo/samsung_tab_3.jpg', 0),
(2322, 49, 'catalog/demo/samsung_tab_2.jpg', 0),
(2317, 42, 'catalog/demo/canon_logo.jpg', 0),
(2316, 42, 'catalog/demo/hp_1.jpg', 0),
(2315, 42, 'catalog/demo/compaq_presario.jpg', 0),
(2314, 42, 'catalog/demo/canon_eos_5d_1.jpg', 0),
(2313, 42, 'catalog/demo/canon_eos_5d_2.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_option`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_option`;
CREATE TABLE `oc_product_option` (
  `product_option_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `required` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_option`
--

INSERT INTO `oc_product_option` (`product_option_id`, `product_id`, `option_id`, `value`, `required`) VALUES
(224, 35, 11, '', 1),
(225, 47, 12, '2011-04-22', 1),
(223, 42, 2, '', 1),
(217, 42, 5, '', 1),
(209, 42, 6, '', 1),
(218, 42, 1, '', 1),
(208, 42, 4, 'test', 1),
(219, 42, 8, '2011-02-20', 1),
(222, 42, 7, '', 1),
(221, 42, 9, '22:25', 1),
(220, 42, 10, '2011-02-20 22:25', 1),
(226, 30, 5, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_option_value`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_option_value`;
CREATE TABLE `oc_product_option_value` (
  `product_option_value_id` int(11) NOT NULL,
  `product_option_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `option_value_id` int(11) NOT NULL,
  `quantity` int(3) NOT NULL,
  `subtract` tinyint(1) NOT NULL,
  `price` decimal(15,4) NOT NULL,
  `price_prefix` varchar(1) NOT NULL,
  `points` int(8) NOT NULL,
  `points_prefix` varchar(1) NOT NULL,
  `weight` decimal(15,8) NOT NULL,
  `weight_prefix` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_option_value`
--

INSERT INTO `oc_product_option_value` (`product_option_value_id`, `product_option_id`, `product_id`, `option_id`, `option_value_id`, `quantity`, `subtract`, `price`, `price_prefix`, `points`, `points_prefix`, `weight`, `weight_prefix`) VALUES
(1, 217, 42, 5, 41, 100, 0, '1.0000', '+', 0, '+', '1.00000000', '+'),
(6, 218, 42, 1, 31, 146, 1, '20.0000', '+', 2, '-', '20.00000000', '+'),
(7, 218, 42, 1, 43, 300, 1, '30.0000', '+', 3, '+', '30.00000000', '+'),
(5, 218, 42, 1, 32, 96, 1, '10.0000', '+', 1, '+', '10.00000000', '+'),
(4, 217, 42, 5, 39, 92, 1, '4.0000', '+', 0, '+', '4.00000000', '+'),
(2, 217, 42, 5, 42, 200, 1, '2.0000', '+', 0, '+', '2.00000000', '+'),
(3, 217, 42, 5, 40, 300, 0, '3.0000', '+', 0, '+', '3.00000000', '+'),
(8, 223, 42, 2, 23, 48, 1, '10.0000', '+', 0, '+', '10.00000000', '+'),
(10, 223, 42, 2, 44, 2696, 1, '30.0000', '+', 0, '+', '30.00000000', '+'),
(9, 223, 42, 2, 24, 194, 1, '20.0000', '+', 0, '+', '20.00000000', '+'),
(11, 223, 42, 2, 45, 3998, 1, '40.0000', '+', 0, '+', '40.00000000', '+'),
(12, 224, 35, 11, 46, 0, 1, '5.0000', '+', 0, '+', '0.00000000', '+'),
(13, 224, 35, 11, 47, 10, 1, '10.0000', '+', 0, '+', '0.00000000', '+'),
(14, 224, 35, 11, 48, 15, 1, '15.0000', '+', 0, '+', '0.00000000', '+'),
(16, 226, 30, 5, 40, 5, 1, '0.0000', '+', 0, '+', '0.00000000', '+'),
(15, 226, 30, 5, 39, 2, 1, '0.0000', '+', 0, '+', '0.00000000', '+');

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_recurring`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_recurring`;
CREATE TABLE `oc_product_recurring` (
  `product_id` int(11) NOT NULL,
  `recurring_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_related`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_related`;
CREATE TABLE `oc_product_related` (
  `product_id` int(11) NOT NULL,
  `related_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_related`
--

INSERT INTO `oc_product_related` (`product_id`, `related_id`) VALUES
(40, 42),
(41, 42),
(42, 40),
(42, 41);

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_reward`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_reward`;
CREATE TABLE `oc_product_reward` (
  `product_reward_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `customer_group_id` int(11) NOT NULL DEFAULT '0',
  `points` int(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_reward`
--

INSERT INTO `oc_product_reward` (`product_reward_id`, `product_id`, `customer_group_id`, `points`) VALUES
(515, 42, 1, 100),
(519, 47, 1, 300),
(379, 28, 1, 400),
(329, 43, 1, 600),
(339, 29, 1, 0),
(343, 48, 1, 0),
(335, 40, 1, 0),
(539, 30, 1, 200),
(331, 44, 1, 700),
(333, 45, 1, 800),
(337, 31, 1, 0),
(425, 35, 1, 0),
(345, 33, 1, 0),
(347, 46, 1, 0),
(545, 41, 1, 0),
(351, 36, 1, 0),
(353, 34, 1, 0),
(355, 32, 1, 0),
(521, 49, 1, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_special`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_special`;
CREATE TABLE `oc_product_special` (
  `product_special_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `priority` int(5) NOT NULL DEFAULT '1',
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_special`
--

INSERT INTO `oc_product_special` (`product_special_id`, `product_id`, `customer_group_id`, `priority`, `price`, `date_start`, `date_end`) VALUES
(419, 42, 1, 1, '90.0000', '0000-00-00', '0000-00-00'),
(439, 30, 1, 2, '90.0000', '0000-00-00', '0000-00-00'),
(438, 30, 1, 1, '80.0000', '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_to_category`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_to_category`;
CREATE TABLE `oc_product_to_category` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_to_category`
--

INSERT INTO `oc_product_to_category` (`product_id`, `category_id`) VALUES
(28, 20),
(28, 24),
(29, 20),
(29, 24),
(30, 20),
(30, 33),
(31, 33),
(32, 34),
(33, 20),
(33, 28),
(34, 34),
(35, 20),
(36, 34),
(40, 20),
(40, 24),
(41, 27),
(42, 20),
(42, 28),
(43, 18),
(43, 20),
(44, 18),
(44, 20),
(45, 18),
(46, 18),
(46, 20),
(47, 18),
(47, 20),
(48, 20),
(48, 34),
(49, 57);

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_to_download`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_to_download`;
CREATE TABLE `oc_product_to_download` (
  `product_id` int(11) NOT NULL,
  `download_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_to_layout`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_to_layout`;
CREATE TABLE `oc_product_to_layout` (
  `product_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_to_store`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_product_to_store`;
CREATE TABLE `oc_product_to_store` (
  `product_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_to_store`
--

INSERT INTO `oc_product_to_store` (`product_id`, `store_id`) VALUES
(28, 0),
(29, 0),
(30, 0),
(31, 0),
(32, 0),
(33, 0),
(34, 0),
(35, 0),
(36, 0),
(40, 0),
(41, 0),
(42, 0),
(43, 0),
(44, 0),
(45, 0),
(46, 0),
(47, 0),
(48, 0),
(49, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_recurring`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_recurring`;
CREATE TABLE `oc_recurring` (
  `recurring_id` int(11) NOT NULL,
  `price` decimal(10,4) NOT NULL,
  `frequency` enum('day','week','semi_month','month','year') NOT NULL,
  `duration` int(10) UNSIGNED NOT NULL,
  `cycle` int(10) UNSIGNED NOT NULL,
  `trial_status` tinyint(4) NOT NULL,
  `trial_price` decimal(10,4) NOT NULL,
  `trial_frequency` enum('day','week','semi_month','month','year') NOT NULL,
  `trial_duration` int(10) UNSIGNED NOT NULL,
  `trial_cycle` int(10) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL,
  `sort_order` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_recurring_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_recurring_description`;
CREATE TABLE `oc_recurring_description` (
  `recurring_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_return`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_return`;
CREATE TABLE `oc_return` (
  `return_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `product` varchar(255) NOT NULL,
  `model` varchar(64) NOT NULL,
  `quantity` int(4) NOT NULL,
  `opened` tinyint(1) NOT NULL,
  `return_reason_id` int(11) NOT NULL,
  `return_action_id` int(11) NOT NULL,
  `return_status_id` int(11) NOT NULL,
  `comment` text,
  `date_ordered` date NOT NULL DEFAULT '0000-00-00',
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_return_action`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_return_action`;
CREATE TABLE `oc_return_action` (
  `return_action_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_return_action`
--

INSERT INTO `oc_return_action` (`return_action_id`, `language_id`, `name`) VALUES
(1, 1, 'Refunded'),
(2, 1, 'Credit Issued'),
(3, 1, 'Replacement Sent'),
(1, 2, 'Refunded'),
(2, 2, 'Credit Issued'),
(3, 2, 'Replacement Sent');

-- --------------------------------------------------------

--
-- Table structure for table `oc_return_history`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_return_history`;
CREATE TABLE `oc_return_history` (
  `return_history_id` int(11) NOT NULL,
  `return_id` int(11) NOT NULL,
  `return_status_id` int(11) NOT NULL,
  `notify` tinyint(1) NOT NULL,
  `comment` text NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_return_reason`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_return_reason`;
CREATE TABLE `oc_return_reason` (
  `return_reason_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_return_reason`
--

INSERT INTO `oc_return_reason` (`return_reason_id`, `language_id`, `name`) VALUES
(1, 1, 'Dead On Arrival'),
(2, 1, 'Received Wrong Item'),
(3, 1, 'Order Error'),
(4, 1, 'Faulty, please supply details'),
(5, 1, 'Other, please supply details'),
(1, 2, 'Dead On Arrival'),
(2, 2, 'Received Wrong Item'),
(3, 2, 'Order Error'),
(4, 2, 'Faulty, please supply details'),
(5, 2, 'Other, please supply details');

-- --------------------------------------------------------

--
-- Table structure for table `oc_return_status`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_return_status`;
CREATE TABLE `oc_return_status` (
  `return_status_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_return_status`
--

INSERT INTO `oc_return_status` (`return_status_id`, `language_id`, `name`) VALUES
(1, 1, 'Pending'),
(3, 1, 'Complete'),
(2, 1, 'Awaiting Products'),
(1, 2, 'Pending'),
(3, 2, 'Complete'),
(2, 2, 'Awaiting Products');

-- --------------------------------------------------------

--
-- Table structure for table `oc_review`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_review`;
CREATE TABLE `oc_review` (
  `review_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `author` varchar(64) NOT NULL,
  `text` text NOT NULL,
  `rating` int(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_seo_url`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 11:50 AM
--

DROP TABLE IF EXISTS `oc_seo_url`;
CREATE TABLE `oc_seo_url` (
  `seo_url_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `query` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_seo_url`
--

INSERT INTO `oc_seo_url` (`seo_url_id`, `store_id`, `language_id`, `query`, `keyword`) VALUES
(2097, 0, 2, 'category_id=55', 'test-23'),
(2096, 0, 2, 'category_id=54', 'test-22'),
(2095, 0, 2, 'category_id=53', 'test-21'),
(2094, 0, 2, 'category_id=52', 'test-20'),
(2046, 0, 2, 'product_id=34', 'ipod-shuffle'),
(2093, 0, 2, 'category_id=51', 'test-19'),
(2092, 0, 2, 'category_id=50', 'test-18'),
(2091, 0, 2, 'category_id=49', 'test-17'),
(2090, 0, 2, 'category_id=48', 'test-16'),
(2089, 0, 2, 'category_id=47', 'test-15'),
(2088, 0, 2, 'category_id=46', 'macs'),
(2087, 0, 2, 'category_id=45', 'windows'),
(2086, 0, 2, 'category_id=44', 'test-12'),
(2085, 0, 2, 'category_id=43', 'test-11'),
(2084, 0, 2, 'category_id=42', 'test-9'),
(2083, 0, 2, 'category_id=41', 'test-8'),
(2082, 0, 2, 'category_id=40', 'test-7'),
(2081, 0, 2, 'category_id=39', 'test-6'),
(2080, 0, 2, 'category_id=38', 'test-4'),
(2079, 0, 2, 'category_id=37', 'test-5'),
(2078, 0, 2, 'category_id=36', 'test-2'),
(2077, 0, 2, 'category_id=35', 'test-1'),
(2076, 0, 2, 'category_id=34', 'mp3-players'),
(2075, 0, 2, 'category_id=33', 'cameras'),
(2074, 0, 2, 'category_id=32', 'web-cameras'),
(2073, 0, 2, 'category_id=31', 'scanners'),
(2072, 0, 2, 'category_id=30', 'printers'),
(2071, 0, 2, 'category_id=29', 'mice-and-trackballs'),
(2070, 0, 2, 'category_id=28', 'monitors'),
(2069, 0, 2, 'category_id=27', 'mac'),
(2068, 0, 2, 'category_id=26', 'pc'),
(2067, 0, 2, 'category_id=25', 'components'),
(2066, 0, 2, 'category_id=24', 'phones-pdas'),
(2065, 0, 2, 'category_id=20', 'desktops'),
(2064, 0, 2, 'category_id=18', 'laptops-notebooks'),
(2063, 0, 2, 'category_id=17', 'software'),
(2062, 0, 2, 'information_id=6', 'delivery-information'),
(2061, 0, 2, 'information_id=5', 'polzovatelskoe-soglashenie'),
(2060, 0, 2, 'information_id=4', 'o-kompanii'),
(2059, 0, 2, 'information_id=3', 'privacy-policy'),
(2058, 0, 2, 'product_id=49', 'samsung-galaxy-tab-10.1'),
(2057, 0, 2, 'product_id=48', 'ipod-classic'),
(2056, 0, 2, 'product_id=47', 'hp-lp3065'),
(2055, 0, 2, 'product_id=46', 'sony-vaio'),
(2054, 0, 2, 'product_id=45', 'macbook-pro'),
(2053, 0, 2, 'product_id=44', 'macbook-air'),
(2052, 0, 2, 'product_id=43', 'macbook'),
(2051, 0, 2, 'product_id=42', 'apple-cinema-30'),
(2050, 0, 2, 'product_id=41', 'imac'),
(2049, 0, 2, 'product_id=40', 'iphone'),
(2048, 0, 2, 'product_id=36', 'ipod-nano'),
(2047, 0, 2, 'product_id=35', 'product-8'),
(2045, 0, 2, 'product_id=33', 'samsung-syncmaster-941bw'),
(2044, 0, 2, 'product_id=32', 'ipod-touch'),
(2043, 0, 2, 'product_id=31', 'nikon-d300'),
(2042, 0, 2, 'product_id=30', 'canon-eos-5d'),
(2041, 0, 2, 'product_id=29', 'palm-treo-pro'),
(2007, 0, 2, 'checkout/cart', 'cart'),
(2006, 0, 2, 'product/search', 'search'),
(2005, 0, 2, 'product/compare', 'compare-products'),
(2004, 0, 2, 'product/manufacturer', 'brands'),
(2003, 0, 2, 'product/special', 'specials'),
(2002, 0, 2, 'information/sitemap', 'sitemap'),
(2001, 0, 2, 'information/contact', 'contact'),
(2040, 0, 2, 'product_id=28', 'htc-touch-hd'),
(845, 0, 2, 'common/home', '/'),
(2008, 0, 2, 'checkout/checkout', 'checkout'),
(2020, 0, 2, 'account/transaction', 'transactions'),
(2019, 0, 2, 'account/return', 'returns'),
(2018, 0, 2, 'account/download', 'downloads'),
(2017, 0, 2, 'account/forgotten', 'forgot-password'),
(2016, 0, 2, 'account/return/add', 'return-add'),
(2015, 0, 2, 'account/newsletter', 'newsletter'),
(2014, 0, 2, 'account/order', 'order-history'),
(2013, 0, 2, 'account/account', 'my-account'),
(2012, 0, 2, 'account/wishlist', 'wishlist'),
(2011, 0, 2, 'account/voucher', 'vouchers'),
(2010, 0, 2, 'account/logout', 'logout'),
(2009, 0, 2, 'account/login', 'login'),
(2023, 0, 2, 'account/address', 'address-book'),
(2022, 0, 2, 'account/recurring', 'recurring'),
(2021, 0, 2, 'account/register', 'create-account'),
(2032, 0, 2, 'affiliate/transaction', 'affiliate-transaction'),
(2031, 0, 2, 'affiliate/tracking', 'affiliate-tracking'),
(2030, 0, 2, 'affiliate/payment', 'affiliate-payment'),
(2029, 0, 2, 'affiliate/login', 'affiliate-login'),
(2028, 0, 2, 'affiliate/register', 'create-affiliate-account'),
(2027, 0, 2, 'affiliate/forgotten', 'affiliate-forgot-password'),
(2026, 0, 2, 'account/password', 'change-password'),
(2025, 0, 2, 'account/edit', 'edit-account'),
(2033, 0, 2, 'affiliate/account', 'affiliates'),
(2098, 0, 2, 'category_id=56', 'test-24'),
(2099, 0, 2, 'category_id=57', 'tablets'),
(2100, 0, 2, 'category_id=58', 'test-25');

-- --------------------------------------------------------

--
-- Table structure for table `oc_seo_url-2`
--
-- Creation: Aug 02, 2020 at 11:47 AM
-- Last update: Aug 02, 2020 at 11:47 AM
-- Last check: Aug 02, 2020 at 11:47 AM
--

DROP TABLE IF EXISTS `oc_seo_url-2`;
CREATE TABLE `oc_seo_url-2` (
  `seo_url_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `query` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_seo_url-2`
--

INSERT INTO `oc_seo_url-2` (`seo_url_id`, `store_id`, `language_id`, `query`, `keyword`) VALUES
(824, 0, 1, 'product_id=48', 'ipod-classic'),
(836, 0, 1, 'category_id=20', 'desktops'),
(834, 0, 1, 'category_id=26', 'pc'),
(835, 0, 1, 'category_id=27', 'mac'),
(730, 0, 1, 'manufacturer_id=8', 'apple'),
(768, 0, 1, 'product_id=42', 'test'),
(789, 0, 1, 'category_id=34', 'mp3-players'),
(781, 0, 1, 'category_id=36', 'test2'),
(774, 0, 1, 'category_id=18', 'laptop-notebook'),
(775, 0, 1, 'category_id=46', 'macs'),
(776, 0, 1, 'category_id=45', 'windows'),
(777, 0, 1, 'category_id=25', 'component'),
(778, 0, 1, 'category_id=29', 'mouse'),
(779, 0, 1, 'category_id=28', 'monitor'),
(780, 0, 1, 'category_id=35', 'test1'),
(782, 0, 1, 'category_id=30', 'printer'),
(783, 0, 1, 'category_id=31', 'scanner'),
(784, 0, 1, 'category_id=32', 'web-camera'),
(785, 0, 1, 'category_id=57', 'tablet'),
(786, 0, 1, 'category_id=17', 'software'),
(787, 0, 1, 'category_id=24', 'smartphone'),
(788, 0, 1, 'category_id=33', 'camera'),
(790, 0, 1, 'category_id=43', 'test11'),
(791, 0, 1, 'category_id=44', 'test12'),
(792, 0, 1, 'category_id=47', 'test15'),
(793, 0, 1, 'category_id=48', 'test16'),
(794, 0, 1, 'category_id=49', 'test17'),
(795, 0, 1, 'category_id=50', 'test18'),
(796, 0, 1, 'category_id=51', 'test19'),
(797, 0, 1, 'category_id=52', 'test20'),
(798, 0, 1, 'category_id=58', 'test25'),
(799, 0, 1, 'category_id=53', 'test21'),
(800, 0, 1, 'category_id=54', 'test22'),
(801, 0, 1, 'category_id=55', 'test23'),
(802, 0, 1, 'category_id=56', 'test24'),
(803, 0, 1, 'category_id=38', 'test4'),
(804, 0, 1, 'category_id=37', 'test5'),
(805, 0, 1, 'category_id=39', 'test6'),
(806, 0, 1, 'category_id=40', 'test7'),
(807, 0, 1, 'category_id=41', 'test8'),
(808, 0, 1, 'category_id=42', 'test9'),
(809, 0, 1, 'product_id=30', 'canon-eos-5d'),
(840, 0, 1, 'product_id=47', 'hp-lp3065'),
(811, 0, 1, 'product_id=28', 'htc-touch-hd'),
(812, 0, 1, 'product_id=43', 'macbook'),
(813, 0, 1, 'product_id=44', 'macbook-air'),
(814, 0, 1, 'product_id=45', 'macbook-pro'),
(816, 0, 1, 'product_id=31', 'nikon-d300'),
(817, 0, 1, 'product_id=29', 'palm-treo-pro'),
(818, 0, 1, 'product_id=35', 'product-8'),
(819, 0, 1, 'product_id=49', 'samsung-galaxy-tab-10-1'),
(820, 0, 1, 'product_id=33', 'samsung-syncmaster-941bw'),
(821, 0, 1, 'product_id=46', 'sony-vaio'),
(837, 0, 1, 'product_id=41', 'imac'),
(823, 0, 1, 'product_id=40', 'iphone'),
(825, 0, 1, 'product_id=36', 'ipod-nano'),
(826, 0, 1, 'product_id=34', 'ipod-shuffle'),
(827, 0, 1, 'product_id=32', 'ipod-touch'),
(828, 0, 1, 'manufacturer_id=9', 'canon'),
(829, 0, 1, 'manufacturer_id=5', 'htc'),
(830, 0, 1, 'manufacturer_id=7', 'hewlett-packard'),
(831, 0, 1, 'manufacturer_id=6', 'palm'),
(832, 0, 1, 'manufacturer_id=10', 'sony'),
(841, 0, 1, 'information_id=6', 'delivery'),
(842, 0, 1, 'information_id=3', 'privacy'),
(844, 0, 2, 'product_id=28', 'htc-touch-hd'),
(845, 0, 2, 'product_id=29', 'palm-treo-pro'),
(846, 0, 2, 'product_id=30', 'canon-eos-5d'),
(847, 0, 2, 'product_id=31', 'nikon-d300'),
(848, 0, 2, 'product_id=32', 'ipod-touch'),
(849, 0, 2, 'product_id=33', 'samsung-syncmaster-941bw'),
(850, 0, 2, 'product_id=34', 'ipod-shuffle'),
(851, 0, 2, 'product_id=35', 'product-8'),
(852, 0, 2, 'product_id=36', 'ipod-nano'),
(853, 0, 2, 'product_id=40', 'iphone'),
(854, 0, 2, 'product_id=41', 'imac'),
(855, 0, 2, 'product_id=42', 'apple-cinema-30'),
(856, 0, 2, 'product_id=43', 'macbook'),
(857, 0, 2, 'product_id=44', 'macbook-air'),
(858, 0, 2, 'product_id=45', 'macbook-pro'),
(859, 0, 2, 'product_id=46', 'sony-vaio'),
(860, 0, 2, 'product_id=47', 'hp-lp3065'),
(861, 0, 2, 'product_id=48', 'ipod-classic'),
(862, 0, 2, 'product_id=49', 'samsung-galaxy-tab-10.1'),
(863, 0, 2, 'category_id=17', 'software'),
(864, 0, 2, 'category_id=18', 'laptops-notebooks'),
(865, 0, 2, 'category_id=20', 'desktops'),
(866, 0, 2, 'category_id=24', 'phones-pdas'),
(867, 0, 2, 'category_id=25', 'components'),
(868, 0, 2, 'category_id=26', 'pc'),
(869, 0, 2, 'category_id=27', 'mac'),
(870, 0, 2, 'category_id=28', 'monitors'),
(871, 0, 2, 'category_id=29', 'mice-and-trackballs'),
(872, 0, 2, 'category_id=30', 'printers'),
(873, 0, 2, 'category_id=31', 'scanners'),
(874, 0, 2, 'category_id=32', 'web-cameras'),
(875, 0, 2, 'category_id=33', 'cameras'),
(876, 0, 2, 'category_id=34', 'mp3-players'),
(877, 0, 2, 'category_id=35', 'test-1'),
(878, 0, 2, 'category_id=36', 'test-2'),
(879, 0, 2, 'category_id=37', 'test-5'),
(880, 0, 2, 'category_id=38', 'test-4'),
(881, 0, 2, 'category_id=39', 'test-6'),
(882, 0, 2, 'category_id=40', 'test-7'),
(883, 0, 2, 'category_id=41', 'test-8'),
(884, 0, 2, 'category_id=42', 'test-9'),
(885, 0, 2, 'category_id=43', 'test-11'),
(886, 0, 2, 'category_id=44', 'test-12'),
(887, 0, 2, 'category_id=45', 'windows'),
(888, 0, 2, 'category_id=46', 'macs'),
(889, 0, 2, 'category_id=47', 'test-15'),
(890, 0, 2, 'category_id=48', 'test-16'),
(891, 0, 2, 'category_id=49', 'test-17'),
(892, 0, 2, 'category_id=50', 'test-18'),
(893, 0, 2, 'category_id=51', 'test-19'),
(894, 0, 2, 'category_id=52', 'test-20'),
(895, 0, 2, 'category_id=53', 'test-21'),
(896, 0, 2, 'category_id=54', 'test-22'),
(897, 0, 2, 'category_id=55', 'test-23'),
(898, 0, 2, 'category_id=56', 'test-24'),
(899, 0, 2, 'category_id=57', 'tablets'),
(900, 0, 2, 'category_id=58', 'test-25'),
(901, 0, 2, 'information_id=3', 'privacy-policy'),
(902, 0, 2, 'information_id=4', 'o-kompanii'),
(903, 0, 2, 'information_id=5', 'polzovatelskoe-soglashenie'),
(904, 0, 2, 'information_id=6', 'delivery-information'),
(905, 0, 2, 'extension/quickcheckout/checkout', 'checkout');

-- --------------------------------------------------------

--
-- Table structure for table `oc_session`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 05:39 PM
--

DROP TABLE IF EXISTS `oc_session`;
CREATE TABLE `oc_session` (
  `session_id` varchar(32) NOT NULL,
  `data` text NOT NULL,
  `expire` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_session`
--

INSERT INTO `oc_session` (`session_id`, `data`, `expire`) VALUES
('007ac599b45e36504c747117bf', 'false', '2020-08-02 21:17:47'),
('0177805ec6797d7ba75ac846d7', 'false', '2020-08-02 21:17:48'),
('028598dbfffa5dc49679c436a7', 'false', '2020-08-03 01:16:06'),
('0291e466deda072c71c7e3d0cd', 'false', '2020-08-02 15:22:25'),
('02a036b21fd271afac2aceb7a9', 'false', '2020-08-02 21:17:45'),
('03244add013d94bcaaa5f9ff3e', 'false', '2020-08-03 01:16:08'),
('03820cc4ee75173f9fd1cb0ad4', 'false', '2020-08-02 19:31:15'),
('042a88194d4e6c76b0b12261c9', 'false', '2020-08-02 15:22:28'),
('04bb6b4cba4a4876973ad40e0c', 'false', '2020-08-02 23:31:25'),
('04fdb053bc6c99f96ad9d20281', 'false', '2020-08-02 19:31:12'),
('052a6160653958b7479c1b51b4', 'false', '2020-08-02 19:31:14'),
('0553d05967b27c5715fa9fc8a5', 'false', '2020-08-02 23:31:30'),
('05a8b5371170c7ca815f756813', 'false', '2020-08-02 23:31:28'),
('05e629512edcf729cc674c13d0', 'false', '2020-08-02 21:17:43'),
('05f87abf6c3c550af6d7a6a207', 'false', '2020-08-02 15:22:29'),
('087587e80464170f62217210a8', 'false', '2020-08-02 21:17:47'),
('08fb819bac5b0e903449e4f9e2', 'false', '2020-08-03 01:16:11'),
('096351419de3cdc28a4cd54f98', 'false', '2020-08-02 23:31:29'),
('09a7024e8d044b6498172ef495', 'false', '2020-08-02 21:17:46'),
('0a47f59703dac048c1bf525d2f', 'false', '2020-08-02 21:17:43'),
('0a95d4da6cd0f22d4a376aee39', 'false', '2020-08-03 01:16:06'),
('0b22c31df5db9d8e69313105c5', 'false', '2020-08-02 21:17:48'),
('0b2911632c81b6c5839418d32d', 'false', '2020-08-02 21:17:47'),
('0b586c60e1980abfae7f91fda2', 'false', '2020-08-03 01:16:10'),
('0c2d184b28ab6a1b87e5300975', 'false', '2020-08-02 21:17:48'),
('0d27f8f6dacac764459e7d1e8e', 'false', '2020-08-02 21:17:46'),
('0d2a50c1c6885de6704527f473', 'false', '2020-08-02 21:17:48'),
('0d2f9615cbaa8b6c1848976c6c', 'false', '2020-08-02 17:22:40'),
('0d76097b989ca492dceb1520f1', 'false', '2020-08-02 19:31:14'),
('0ddc01a944cfd6fa4056335e21', 'false', '2020-08-03 01:16:10'),
('0e4a18b9a143cff6beaf8c3977', 'false', '2020-08-02 19:31:14'),
('0f7cfec7ca969a4cd1622bc6c4', 'false', '2020-08-02 21:17:46'),
('0fa62f1c07401dfbb67b191664', 'false', '2020-08-02 23:31:26'),
('101973e4c9078dca9c7e8525c2', 'false', '2020-08-03 01:16:09'),
('10700b9ea1f691dd91d387ce72', 'false', '2020-08-02 15:22:23'),
('12346e340a775859b30a89e702', 'false', '2020-08-03 01:16:11'),
('12470688eeac39f72b50c1f7f1', 'false', '2020-08-02 15:22:28'),
('1377af40d8cb88c5fcc2001a00', 'false', '2020-08-03 01:16:10'),
('13ede946b4be37c4b4b27c4cf4', 'false', '2020-08-03 01:16:10'),
('140247226f430614f8713c8ba9', 'false', '2020-08-02 21:17:46'),
('1465fe9c41001f281f9d500ea6', 'false', '2020-08-03 01:16:09'),
('14c084cad2856c1e8cf9a9e827', 'false', '2020-08-02 21:17:44'),
('14e60f099fa2994b5f4faf09dd', 'false', '2020-08-02 19:31:12'),
('152d7bcc0aa01cf5627bc5a865', 'false', '2020-08-02 19:31:13'),
('15e90f01f7a8ff48c84602f6ca', 'false', '2020-08-02 23:31:30'),
('18624fac849af1560bb86dc32a', 'false', '2020-08-02 17:22:41'),
('193af18ae4c7935d397199e283', 'false', '2020-08-02 21:17:48'),
('1a44541dbb178b96be75e999e2', 'false', '2020-08-03 01:16:11'),
('1aad47513d3e5686d75164d2c0', 'false', '2020-08-03 01:16:07'),
('1b1b021c0d78545e9ef9f8c7e0', 'false', '2020-08-02 23:31:26'),
('1b648d3e6b8c89a83fc4469690', 'false', '2020-08-02 19:31:10'),
('1bf16ca9a76c6a4d1894d2d82b', 'false', '2020-08-02 23:31:29'),
('1c7ed075471bb06a9c1f64d819', 'false', '2020-08-03 01:16:10'),
('1de856bc90588460b79add9acd', 'false', '2020-08-02 15:22:25'),
('1e253c5af819230ae905b767ef', 'false', '2020-08-02 21:17:47'),
('1e9cebe4769d1433da4553537f', 'false', '2020-08-03 01:16:09'),
('1ea8344740e493d7f1f8922ace', 'false', '2020-08-02 19:31:15'),
('1eccbef6e6ff1c19849bb7f355', 'false', '2020-08-02 15:22:25'),
('1f9c1f10bbcced5eace2d622e4', 'false', '2020-08-02 17:22:41'),
('1fdea407817c51768ceee3206a', 'false', '2020-08-02 15:22:24'),
('1febb987dafabf0ad3a78aeb73', 'false', '2020-08-02 19:31:12'),
('1ff03e0ddfc221959c285b35aa', 'false', '2020-08-02 15:22:25'),
('20c0fd3b3047379903bd7fc6e4', 'false', '2020-08-02 17:22:36'),
('20c8636f90e7dcc20e03f05050', 'false', '2020-08-03 01:16:10'),
('2136dd38c18591ffc1ed4a0a18', 'false', '2020-08-02 21:17:47'),
('21522a543f422609bb9833da14', 'false', '2020-08-02 17:22:41'),
('222853e486197469a074084cb1', 'false', '2020-08-02 17:22:41'),
('2306900ea49033919753764afc', 'false', '2020-08-02 19:31:14'),
('23beb48887b6c87ab3769e86d7', 'false', '2020-08-02 23:31:29'),
('24fc9377d7361d643240fcd2ab', 'false', '2020-08-02 23:31:25'),
('2678d5cfe60bf5fef5a90b0df2', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 17:22:39'),
('26f77cc2b85b72a03c8bebcd81', 'false', '2020-08-03 01:16:11'),
('2766631da0b3c3674f86df9814', 'false', '2020-08-03 01:16:11'),
('27af36ea874154055342785c6b', 'false', '2020-08-02 19:31:15'),
('2a9f36646ec8c2a1c0a8602c12', 'false', '2020-08-02 15:22:28'),
('2b0227f675749fe63b87ddff6c', 'false', '2020-08-02 17:22:40'),
('2b1a4bf0e1a8658f512e1e7160', 'false', '2020-08-02 17:22:41'),
('2b5311cc8a07f9269a7485603b', 'false', '2020-08-03 01:16:08'),
('2ca19211c5734f4a64a4d57ded', 'false', '2020-08-03 01:16:09'),
('2d62271bf70c71035afac27222', 'false', '2020-08-02 17:22:37'),
('2dc2713030b0b7c63a37efaa62', 'false', '2020-08-02 21:17:45'),
('2e0176f2674b0179d79580eb23', 'false', '2020-08-02 15:22:28'),
('2e2e294ea27837e54c6920c0ea', 'false', '2020-08-02 19:31:14'),
('2e7aee1e8cf8b9b42698414a9b', 'false', '2020-08-02 21:17:46'),
('2f30dfd0310d1e62eaf482fb9b', 'false', '2020-08-02 23:31:29'),
('2f80cbdd690f90756c73af0da9', 'false', '2020-08-03 01:16:11'),
('2fd41ade0a61eb62d18a262a19', 'false', '2020-08-02 17:22:37'),
('2ff7178bc1c3f0fe2e71a4d107', 'false', '2020-08-02 15:22:27'),
('3026d3b22c72fc9f49f1da82f4', 'false', '2020-08-02 23:31:30'),
('302955886a41fe45e73f05d3de', 'false', '2020-08-02 19:31:11'),
('30b4d114ad2520b6b9b045c5c6', 'false', '2020-08-02 23:31:30'),
('31191ee6642939b0e492e5b135', 'false', '2020-08-02 23:31:25'),
('32029b6d01cf4b3ac2bd528392', 'false', '2020-08-02 19:31:10'),
('32346b4dfddc687b6140e23405', 'false', '2020-08-03 01:16:05'),
('3274b184901faad4a5e59ed59a', 'false', '2020-08-03 01:16:11'),
('328c9aea29d911858f785747f4', 'false', '2020-08-02 23:31:29'),
('329300f4a28e14d48e18cdcd3b', 'false', '2020-08-03 01:16:10'),
('32971544737c9338adf6a9fb72', 'false', '2020-08-02 19:31:13'),
('33917507abd96f321d0ec28be1', 'false', '2020-08-02 15:22:28'),
('34cab7bc05bff25cba99f59463', 'false', '2020-08-02 19:31:11'),
('35ce3126ed2908a7c9cd3af722', 'false', '2020-08-02 23:31:25'),
('361758053aa7201312eae55ead', 'false', '2020-08-02 21:17:44'),
('363162e236ceb95a1185daa4ed', 'false', '2020-08-03 01:16:08'),
('363f98ad3327e695a0ee54570a', 'false', '2020-08-03 01:16:11'),
('36c91b0ad70c94d9dcd7208f1c', 'false', '2020-08-02 23:31:29'),
('36f6bdf1f03dd85e6ebc4a56b0', 'false', '2020-08-02 21:17:48'),
('372171c3a0108908931ac95dc7', 'false', '2020-08-02 23:31:25'),
('37b7c6e364719b4d870e075910', '{\"language\":\"ru-ru\",\"currency\":\"RUB\",\"user_id\":\"1\",\"user_token\":\"kQZLmrcnks9NJxQYDxw7UcGaj5RcrAQd\",\"install\":\"ezUqpNhLFJ\",\"guest\":{\"customer_group_id\":\"1\",\"firstname\":\"\",\"lastname\":\"\",\"email\":\"\",\"telephone\":\"\",\"shipping_address\":true,\"create_account\":false},\"payment_methods\":{\"cod\":{\"code\":\"cod\",\"title\":\"\\u041e\\u043f\\u043b\\u0430\\u0442\\u0430 \\u043f\\u0440\\u0438 \\u0434\\u043e\\u0441\\u0442\\u0430\\u0432\\u043a\\u0435\",\"terms\":\"\",\"sort_order\":\"5\"}},\"shipping_address\":{\"country\":\"\\u0420\\u043e\\u0441\\u0441\\u0438\\u0439\\u0441\\u043a\\u0430\\u044f \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u044f\",\"iso_code_2\":\"RU\",\"iso_code_3\":\"RUS\",\"address_format\":\"\",\"zone\":\"\\u0410\\u043b\\u0442\\u0430\\u0439\\u0441\\u043a\\u0438\\u0439 \\u043a\\u0440\\u0430\\u0439\",\"zone_code\":\"ALT\",\"firstname\":\"\",\"lastname\":\"\",\"company\":\"\",\"address_1\":\"\",\"address_2\":\"\",\"postcode\":\"\",\"city\":\"\",\"country_id\":\"176\",\"zone_id\":\"2726\"},\"shipping_methods\":{\"flat\":{\"title\":\"\\u0424\\u0438\\u043a\\u0441\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u043d\\u0430\\u044f \\u0441\\u0442\\u043e\\u0438\\u043c\\u043e\\u0441\\u0442\\u044c \\u0434\\u043e\\u0441\\u0442\\u0430\\u0432\\u043a\\u0438\",\"quote\":{\"flat\":{\"code\":\"flat.flat\",\"title\":\"\\u0414\\u043e\\u0441\\u0442\\u0430\\u0432\\u043a\\u0430 \\u0441 \\u0444\\u0438\\u043a\\u0441\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u043d\\u043e\\u0439 \\u0441\\u0442\\u043e\\u0438\\u043c\\u043e\\u0441\\u0442\\u044c\\u044e \\u0434\\u043e\\u0441\\u0442\\u0430\\u0432\\u043a\\u0438\",\"cost\":\"5.00\",\"tax_class_id\":\"9\",\"text\":\"5.0\\u0440.\"}},\"sort_order\":\"1\",\"error\":false}},\"delivery_date\":\"\",\"delivery_time\":\"\",\"shipping_method\":{\"code\":\"flat.flat\",\"title\":\"\\u0414\\u043e\\u0441\\u0442\\u0430\\u0432\\u043a\\u0430 \\u0441 \\u0444\\u0438\\u043a\\u0441\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u043d\\u043e\\u0439 \\u0441\\u0442\\u043e\\u0438\\u043c\\u043e\\u0441\\u0442\\u044c\\u044e \\u0434\\u043e\\u0441\\u0442\\u0430\\u0432\\u043a\\u0438\",\"cost\":\"5.00\",\"tax_class_id\":\"9\",\"text\":\"5.0\\u0440.\"},\"payment_address\":{\"firstname\":\"\",\"lastname\":\"\",\"company\":\"\",\"address_1\":\"\",\"address_2\":\"\",\"postcode\":\"\",\"city\":\"\",\"country_id\":\"176\",\"zone_id\":\"\",\"custom_field\":[]},\"compare\":[\"40\"],\"last-active-tab\":\"tab-kassa\",\"success\":\"Success\"}', '2020-08-03 01:39:07'),
('381540d8ea9242d54c5e14d981', 'false', '2020-08-03 01:16:09'),
('385003c2fc460a4de8dce6d83e', 'false', '2020-08-03 01:16:06'),
('38a640f818e96e5bb66ced5bc3', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 19:31:14'),
('38b08569a22c755cd784f99e00', 'false', '2020-08-03 01:16:10'),
('399b484117f0cf4457ad8b96ab', 'false', '2020-08-02 15:22:25'),
('39a6f919fe8b9f06704a6569be', 'false', '2020-08-03 01:16:10'),
('39d7a44cca42fca99c7e5f1537', 'false', '2020-08-02 21:17:45'),
('3aa4a1d348305675b3e95b681d', 'false', '2020-08-02 21:17:45'),
('3b0871443c7e4246ac40ea0441', 'false', '2020-08-02 19:31:12'),
('3b115e18291e521734f0e9a12c', 'false', '2020-08-02 21:17:45'),
('3bcb0b0dde74f0cb19b984b900', 'false', '2020-08-02 21:17:48'),
('3d4e0e4e98eeb9c364195a15c6', 'false', '2020-08-02 21:17:47'),
('3db7852b42806c608c83d2a52f', 'false', '2020-08-02 21:17:48'),
('3e010c84fe116b953f813cbfe4', 'false', '2020-08-02 19:31:14'),
('3e43f4c0f3d17e7de06a5e084d', 'false', '2020-08-02 17:22:40'),
('3eabc405ea40945350c166e979', 'false', '2020-08-03 01:16:11'),
('3f6d306c1a16024e450db55fdb', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 15:22:26'),
('3f901be87552e0425ac5877da2', 'false', '2020-08-02 21:17:44'),
('3fcc5d59e00e3fec58ebb1f8d5', 'false', '2020-08-02 23:31:29'),
('40bc9ab0a3e8a5b375026bd795', 'false', '2020-08-02 21:17:47'),
('411e4cc7f2765deefcc00de76f', 'false', '2020-08-02 17:22:38'),
('4165f6d3595a593e68724f3de3', 'false', '2020-08-02 19:31:14'),
('41c61b2b00dd4b8b94294a4154', 'false', '2020-08-02 23:31:27'),
('4213bfdea9cd4248f7f03f3f33', 'false', '2020-08-02 17:22:40'),
('4236c2a5ca5f39331023d568df', 'false', '2020-08-02 19:31:11'),
('4324a4bb8f612e8bdefddbfc5e', 'false', '2020-08-02 21:17:48'),
('4355e076e14b762e9d3815d2d7', 'false', '2020-08-02 19:31:15'),
('43787ca92d7462ed39421fec97', 'false', '2020-08-02 23:31:29'),
('43c0ffb2fb409a3d721f41b37c', 'false', '2020-08-02 23:31:26'),
('446701f86eeff7b97efb199d57', 'false', '2020-08-02 23:31:30'),
('4475abe9b7a4264b4fafb30c97', 'false', '2020-08-02 19:31:14'),
('447a69332ceb5748b7893959e0', 'false', '2020-08-02 23:31:30'),
('44cc00c9f8d57f8148bc538872', 'false', '2020-08-02 19:31:14'),
('45bbc03c18ada62f135727fd54', 'false', '2020-08-02 21:17:43'),
('4757f9aabbc44cd21884a3737f', 'false', '2020-08-03 01:16:11'),
('47d110844031aae8a93d9132dd', 'false', '2020-08-02 19:31:11'),
('486bde673d3f588e74f3f84630', 'false', '2020-08-02 19:31:15'),
('48738b23760c9adaf790e58e7a', 'false', '2020-08-02 23:31:30'),
('4a0316f28aab29e434bd875500', 'false', '2020-08-02 23:31:30'),
('4a48eb221f4e156f84579c9128', 'false', '2020-08-02 15:22:28'),
('4aacc54f8f58a8f67afe26be88', 'false', '2020-08-02 19:31:13'),
('4acb2504b1785ecbefec68a002', 'false', '2020-08-02 19:31:15'),
('4b302daf2df32492d46dbd5827', 'false', '2020-08-03 01:16:11'),
('4b4dd687c4114140abe63d24c8', 'false', '2020-08-02 15:22:25'),
('4bca71d2bdbcf89bbaa79a4f42', 'false', '2020-08-02 19:31:12'),
('4bd7f3f0984e51cdc5de364f53', 'false', '2020-08-02 15:22:27'),
('4c6d1df4a4f1a2e7b20731f6fe', 'false', '2020-08-02 23:31:30'),
('4c79c5dadeabd32e7d06342dee', 'false', '2020-08-02 19:31:10'),
('4e7f935b875381e67a47a749b3', 'false', '2020-08-03 01:16:09'),
('4ec8766053950221b07d5b4d0a', 'false', '2020-08-02 19:31:12'),
('50cd6744730e23f5b4e12abcc3', 'false', '2020-08-02 23:31:30'),
('517da4510619b80c1ffeed8958', 'false', '2020-08-02 23:31:29'),
('51a1b1469cc30602f3194cdaf7', 'false', '2020-08-02 19:31:13'),
('51cad22d9855afdc6bbe817658', 'false', '2020-08-02 23:31:28'),
('5274836fedb58fe65fbe9db4b6', 'false', '2020-08-02 23:31:25'),
('52baeba0edc1a377f3f19b70b4', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 15:22:29'),
('52e43d1d126a8a4c6e75e231b7', 'false', '2020-08-02 21:17:48'),
('52ed4588e23b4b05dd9b80a3d4', 'false', '2020-08-02 21:17:47'),
('53a29d9de5a9b815d43ccf4ff3', 'false', '2020-08-02 19:31:14'),
('5413ad26c36632798b03646188', 'false', '2020-08-02 23:31:28'),
('54343f292f8e7bce02e22b8e19', 'false', '2020-08-03 01:16:08'),
('5454697c6ab86757820a799565', 'false', '2020-08-03 01:16:08'),
('54a9d0a04572c9202dfa386b28', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-03 01:32:18'),
('54f39d2c70e621b9dddcd7b4b9', 'false', '2020-08-02 23:31:28'),
('54f94d18c6494eeab0f5f9fb2e', 'false', '2020-08-02 23:31:30'),
('551f05a9333cfad1bc22d92204', 'false', '2020-08-02 15:22:29'),
('55433694ab4304018bada696db', 'false', '2020-08-02 15:22:25'),
('55f95a808aed4b1787698c5e17', 'false', '2020-08-02 21:17:48'),
('56c7d5f34825c8f1f548caa29e', 'false', '2020-08-03 01:16:11'),
('5857cf5b2a62052193f1f3f1b4', 'false', '2020-08-02 17:22:38'),
('5893f4fbf7e9358d19d483f839', 'false', '2020-08-02 21:17:46'),
('58b9a782cf32c07b38199c1ed5', 'false', '2020-08-02 19:31:15'),
('58efc0cb5da477aeef3b1b2c51', 'false', '2020-08-02 17:22:41'),
('5a14d113a7fecb6077d76f9d38', 'false', '2020-08-02 21:17:47'),
('5a8ebad87247c8ccd121c823f3', 'false', '2020-08-02 21:17:43'),
('5b2510146d1a1380f0f0fd04a2', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 15:22:27'),
('5b53c0ed671e3a27858ab55200', 'false', '2020-08-02 19:31:15'),
('5b8d20f0b27bed096108c8fb5b', 'false', '2020-08-02 17:22:40'),
('5d76b7127f7fba74a545959ff7', 'false', '2020-08-02 15:22:27'),
('5f0d1673db6e0d51cc4797476a', 'false', '2020-08-02 23:31:25'),
('60d188a8fa5adc6f60566e5599', 'false', '2020-08-03 01:16:07'),
('6135598e6362414f2864b42e99', 'false', '2020-08-02 23:31:30'),
('618912feb71e0bd2e378b5d4eb', 'false', '2020-08-02 19:31:12'),
('619381f87671a400471c108f25', 'false', '2020-08-03 01:16:07'),
('62a76ab5234529e95c6aad1f9d', 'false', '2020-08-02 15:22:24'),
('62d70f2bbee01fecd59b0c0138', 'false', '2020-08-02 19:31:15'),
('641986839a2ac83f8b1707687c', 'false', '2020-08-02 19:31:13'),
('6440fcb99795d0c0cfdad99844', 'false', '2020-08-02 19:31:14'),
('644a14f0309d9c2bf99564e335', 'false', '2020-08-02 23:31:29'),
('6452a7f2b1f2c918516f07ec92', 'false', '2020-08-02 23:31:27'),
('64f6f8f8bdb16397373dc258b1', 'false', '2020-08-03 01:16:08'),
('6528c54d35631f4689b3f5819e', 'false', '2020-08-02 15:22:24'),
('65bea5583951f332975e48a494', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 17:22:38'),
('65fc57d5c0e8a2fd9a08836bee', 'false', '2020-08-02 17:22:37'),
('6661b899458add7621a6bcdac1', 'false', '2020-08-03 01:16:06'),
('6683af080194a19bf8fffee1ed', 'false', '2020-08-02 21:17:44'),
('66afa7ac0490505fe3787437df', 'false', '2020-08-02 21:17:46'),
('66f060c31292d6b03d11505f28', 'false', '2020-08-02 23:31:27'),
('66fe1cf500a624caa2e29c9b34', 'false', '2020-08-02 23:31:29'),
('67b3c441660fd95eed5ca46972', 'false', '2020-08-02 17:22:41'),
('67d7b6846ced6130e27acea2fa', 'false', '2020-08-02 21:17:43'),
('67e4917426c4029330c24bff91', 'false', '2020-08-02 21:17:47'),
('689732c750c111005b2ed1e2f7', 'false', '2020-08-02 21:17:48'),
('68d8e24a1cce1465bca0df7eb9', 'false', '2020-08-02 19:31:14'),
('69c4ce3d7cb9c1d0f26807ec01', 'false', '2020-08-03 01:16:10'),
('6a5e372a0ac3c291269552ebf4', 'false', '2020-08-02 23:31:29'),
('6ae47286070c58fb785cadd6f9', 'false', '2020-08-02 21:17:46'),
('6af5ef98ccb5b3eb476e5a9bd2', 'false', '2020-08-02 21:17:46'),
('6c0fcecbc5e09d339e2009ae31', 'false', '2020-08-02 23:31:29'),
('6c53edda7ed141d91e1a127623', 'false', '2020-08-03 01:16:06'),
('6ca03c7fe6224a4e350f488fc9', 'false', '2020-08-03 01:16:08'),
('6cae6d179c29df987645c2ff0d', 'false', '2020-08-02 19:31:13'),
('6cce9c500918215250aba92496', 'false', '2020-08-02 19:31:12'),
('6cd72227ec5a29f3c3cc0393c4', 'false', '2020-08-02 15:22:29'),
('6dad8797b7b128edd4271a9735', 'false', '2020-08-03 01:16:11'),
('6de361404627a99c1672d85397', 'false', '2020-08-02 17:22:37'),
('6e4e61f4ec320f600dfa27f280', 'false', '2020-08-02 17:22:40'),
('6e5bf015aa7542530ddff1cd23', 'false', '2020-08-02 19:31:14'),
('6e71390d3abd2b690d0e0a538d', 'false', '2020-08-02 23:31:30'),
('6ed91d873a311b0d826113028f', 'false', '2020-08-02 23:31:30'),
('6edab50d353a0dc56b1a89988a', 'false', '2020-08-03 01:16:11'),
('6f6ffc39c882e903253f14a2d4', 'false', '2020-08-03 01:16:08'),
('6fa08f97cb36f1e1c3b9afc9db', 'false', '2020-08-02 17:22:41'),
('7046a6ce6a7d0e4c69d88b2798', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 19:31:11'),
('70b5da48fd2137d2c88071c710', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 17:22:39'),
('7302b02ff433a9ab2f0417ba2c', 'false', '2020-08-02 23:31:30'),
('739610815e9e1b92b9c27e9ea2', 'false', '2020-08-03 01:16:07'),
('74ba30b8c85c89cac8abecc0ae', 'false', '2020-08-03 01:16:10'),
('759d6ba901a1534e99763bafe2', 'false', '2020-08-02 19:31:13'),
('766630b30d0e65ef8ef129fa5b', 'false', '2020-08-03 01:16:06'),
('76a358fa744b171dd2da075f68', 'false', '2020-08-02 19:31:14'),
('7710cff70b00d9fd143b4be7ef', 'false', '2020-08-02 23:31:30'),
('77beeadab3df81a4886bf0c1a0', 'false', '2020-08-02 19:31:12'),
('783bd26ce6dca53dfb27693b60', 'false', '2020-08-02 23:31:27'),
('7975edc9a6a1fdbb7867ec642f', 'false', '2020-08-02 19:31:13'),
('79b5173af4f5edef4ea0c5dd7d', 'false', '2020-08-02 21:17:45'),
('7b2accf81bf15687dbdecf22a6', 'false', '2020-08-03 01:16:10'),
('7c394eb2559ac56ef7b2419f80', 'false', '2020-08-02 17:22:41'),
('7d9433d0d7ef4b4efb6d908aaf', 'false', '2020-08-02 21:17:42'),
('7eae6760d19ac8ef810fe388b0', 'false', '2020-08-02 19:31:15'),
('7ec262b1a4bb8c6e6e2f3d26e2', 'false', '2020-08-02 19:31:14'),
('7f23b6f5bb1f866a8f78965352', 'false', '2020-08-02 23:31:27'),
('7f6a244536c0b653de86e9eb1c', 'false', '2020-08-02 23:31:29'),
('7fad5a257359d97eb47fde0d05', 'false', '2020-08-03 01:16:11'),
('820da3c726e96072c6975b3017', 'false', '2020-08-02 19:31:10'),
('82398e949782652285d5e07175', 'false', '2020-08-02 23:31:28'),
('827d2f36123bd6205df4726750', 'false', '2020-08-03 01:16:08'),
('8281cf3658a55cedb56168979b', 'false', '2020-08-02 19:31:15'),
('828e6a055c062d01b953a25987', 'false', '2020-08-02 21:17:44'),
('82a30ff65108770352a4cf464f', 'false', '2020-08-02 21:17:41'),
('82e24b4ec648461692780bf661', 'false', '2020-08-02 23:31:29'),
('84c6c28d95707aa95ad8d97ef6', 'false', '2020-08-02 21:17:45'),
('8554c44bc5c07044fe08ab0c8d', 'false', '2020-08-03 01:16:05'),
('86bfa97847e10f49aacc1cb7b8', 'false', '2020-08-03 01:16:11'),
('88089c234c388af5f6e4fd4324', 'false', '2020-08-02 23:31:30'),
('8873336a05572fc5b95bc8f080', 'false', '2020-08-02 15:22:28'),
('88770a03b266d2df40fcf75a94', 'false', '2020-08-02 17:22:39'),
('88ffbc6dbd050312d00b9a52a7', 'false', '2020-08-02 21:17:43'),
('89081dca4b80f4bd81e1a2e025', 'false', '2020-08-02 19:31:10'),
('89f569649dd2a32f74cc8bf3d0', 'false', '2020-08-02 15:22:24'),
('8a05e585ec600f6ce0ef26e5a1', 'false', '2020-08-03 01:16:11'),
('8a913063e9f689897710bae09a', 'false', '2020-08-02 21:17:43'),
('8aebfdb72ba13be8d066916e13', 'false', '2020-08-02 21:17:46'),
('8c2ae74e98fe8a5b56d1f63293', 'false', '2020-08-02 15:22:29'),
('8c97378426a2234440005af18a', 'false', '2020-08-02 19:31:13'),
('8d7b7df0bd5f1fbe725b4d1b20', 'false', '2020-08-03 01:16:09'),
('8da6c4a438652d64c3fa8077a9', 'false', '2020-08-02 23:31:30'),
('8e51a0145b37b5df70698a0046', 'false', '2020-08-02 23:31:30'),
('8f59277232a67dfbd507e1fee0', 'false', '2020-08-02 23:31:29'),
('917d8d05608c73555990c066d0', 'false', '2020-08-02 15:22:28'),
('9190c4a1fd243bc2530aa3b473', 'false', '2020-08-03 01:16:09'),
('91df2745b7682b98cf9986761f', 'false', '2020-08-02 19:31:10'),
('926aa3c56e58b94dd8e42e2b5e', '{\"language\":\"ru-ru\",\"currency\":\"RUB\",\"user_id\":\"1\",\"user_token\":\"uHsyqa0BENLrTbVOzAADH8NmzRRPVRch\",\"install\":\"MkQVG5T2rN\"}', '2020-08-02 15:01:14'),
('92c7e19250d8a010590de33a26', 'false', '2020-08-03 01:16:09'),
('93efd15b503b53f2818b3d459c', 'false', '2020-08-02 23:31:28'),
('948c01cf614c0d2c57669dfe86', 'false', '2020-08-02 21:17:48'),
('94a407835ce1876b6f65a4d5c4', 'false', '2020-08-02 19:31:15'),
('94c03a04ad9d530926c53c382a', 'false', '2020-08-02 19:31:13'),
('95292891a9266cd575905ffa8f', 'false', '2020-08-02 23:31:30'),
('95cdd733d41d58d4148dd97726', 'false', '2020-08-02 19:31:09'),
('964de80f4c02f1a02cb36e07f9', 'false', '2020-08-02 21:17:48'),
('966bbebbcc711a91cfcc303041', 'false', '2020-08-02 21:17:44'),
('96a8a18ef2d7cb666e8e659ff1', 'false', '2020-08-02 17:22:37'),
('977dc9cb55e1de0c72256a91eb', 'false', '2020-08-02 21:17:48'),
('9806babe277c5b0a8e5f0ed86b', 'false', '2020-08-03 01:16:10'),
('982e58668b0efdc50ba9b614a2', 'false', '2020-08-03 01:16:11'),
('98346ebf7e13348e9bb29026af', 'false', '2020-08-02 17:22:41'),
('985a6d6722380c87e6120ca6e5', 'false', '2020-08-02 23:31:25'),
('987017a9e0b74ce57db6faa170', 'false', '2020-08-03 01:16:10'),
('98869be334774d6109c06061b1', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 15:22:25'),
('98b06bc3a6c3079c956438fd34', 'false', '2020-08-02 17:22:40'),
('98feb20e060c959b63ea872865', 'false', '2020-08-02 15:22:29'),
('9979d9e70058ab6834f5f6777b', 'false', '2020-08-02 23:31:28'),
('9989f4494791ddc988bc64adf3', 'false', '2020-08-02 15:22:29'),
('9bc3510c4a95f4f8d68e647cc6', 'false', '2020-08-03 01:16:10'),
('9d19116cf1259ef726d12a59a5', 'false', '2020-08-03 01:16:11'),
('9d99dfb914bcc641b8a95ebc15', 'false', '2020-08-03 01:16:10'),
('9e1fd97ccdcfc1fc4956acc08c', 'false', '2020-08-02 21:17:45'),
('9e7096a9bd1a3733059602f4d1', 'false', '2020-08-02 23:31:29'),
('9e9380edfa373f2963ef1bf738', 'false', '2020-08-02 15:22:26'),
('9ed2490acd3383f134e39f462e', 'false', '2020-08-02 19:31:13'),
('a007cec0914c13160845a59d3d', 'false', '2020-08-02 21:17:48'),
('a040b2cbf22e377b419aa38582', 'false', '2020-08-03 01:16:09'),
('a0ae20981160dc213ef53bea36', 'false', '2020-08-02 19:31:14'),
('a0c9421ff0a4c47db48bdb0271', 'false', '2020-08-03 01:16:06'),
('a13d5561350888e7514399a779', 'false', '2020-08-02 15:22:26'),
('a196b481e5e9a2c47d9c92db12', 'false', '2020-08-03 01:16:11'),
('a1e5ee67e45d978f8d04ab251b', 'false', '2020-08-02 19:31:11'),
('a29c2b6018e105fe8c6a91a908', 'false', '2020-08-02 23:31:30'),
('a2ad4e545111dc0afb15ca68ae', 'false', '2020-08-02 17:22:41'),
('a2dc252875bad6cb9404e692e9', 'false', '2020-08-02 21:17:45'),
('a2f543cb814b34f36ace769f27', 'false', '2020-08-03 01:16:08'),
('a4d44c180fd228c3c348a842de', 'false', '2020-08-02 23:31:26'),
('a4e9119a8768f077c6aa8230af', 'false', '2020-08-02 23:31:26'),
('a4ffea9529bdbabeb1c43f8994', 'false', '2020-08-02 23:31:26'),
('a5c62d4c7da746441c0d68d0fd', 'false', '2020-08-02 23:31:25'),
('a71efb0afedffcb55179fe6138', 'false', '2020-08-02 19:31:12'),
('a73f6a96beae8c37c3d737cd33', 'false', '2020-08-02 23:31:26'),
('a88abca15a3f769ce9fc256071', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 19:31:15'),
('a919416225af16fa2bf60842bf', 'false', '2020-08-02 17:22:39'),
('aa06ab719a5733ef6d611003c3', 'false', '2020-08-02 19:31:10'),
('ab052b34ddc3446b96950e0549', 'false', '2020-08-02 19:31:15'),
('ab31141aaf6275d851fec5d331', 'false', '2020-08-02 21:17:47'),
('ada2b01b014d7f320f119c88fe', 'false', '2020-08-03 01:16:11'),
('ae1f827e82d2ad4363ef134f31', 'false', '2020-08-02 15:22:28'),
('ae93f9b03885b6dbdef1c6e09d', 'false', '2020-08-03 01:16:10'),
('af175ce1209611e16015b9ecd6', 'false', '2020-08-02 21:17:47'),
('af83d9f541253bebcc9b769ca7', 'false', '2020-08-02 21:17:48'),
('af840d343107a4020d1fec76f0', 'false', '2020-08-02 19:31:15'),
('afa888c892ef8b86803d48dacb', 'false', '2020-08-02 19:31:15'),
('b0897d43fecbf74d9ba4469c37', 'false', '2020-08-03 01:16:07'),
('b0a4f2b11f05dd0eac8fc743c3', 'false', '2020-08-02 23:31:27'),
('b0de9ffe2f9648df68fa3ea4fb', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 19:31:14'),
('b156dc09fa4a96de092c72101c', 'false', '2020-08-02 15:22:27'),
('b2398b8e206a21cf728f0e3fdf', 'false', '2020-08-02 19:31:11'),
('b3bc6853f02b4f0bb6da8104f5', 'false', '2020-08-02 17:22:40'),
('b4bf88b42cdad6fe5778be4a20', 'false', '2020-08-02 21:17:48'),
('b4cdf46078e92010d19d090b9e', 'false', '2020-08-02 21:17:46'),
('b4d5f8e93a855ce6ad99489f4c', 'false', '2020-08-02 17:22:41'),
('b591afeed389d80a8e21ea6cda', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 17:22:37'),
('b5b8412447cd0ceb4dd7c0cc96', 'false', '2020-08-02 15:22:25'),
('b6a39b43368642fcf4f124c44e', 'false', '2020-08-02 19:31:09'),
('b6a8e90b70cae17b36e09f5789', 'false', '2020-08-02 17:22:38'),
('b6bf27f8696d67ac9b42671979', 'false', '2020-08-02 19:31:13'),
('b77b9f6d22d95894336416f0cc', 'false', '2020-08-02 23:31:29'),
('b7a2e2257406c57ead54165be1', 'false', '2020-08-02 19:31:15'),
('b7f7fbae664b37c50650d4a733', 'false', '2020-08-02 21:17:43'),
('b8456df7312d6f6cb3fe54b871', 'false', '2020-08-02 23:31:27'),
('b8d8b2e0c41e290896c1640f4d', 'false', '2020-08-03 01:16:07'),
('b8e12b74c4f10082307d8fc26f', 'false', '2020-08-02 23:31:29'),
('ba1ec516703bfdde04c0bc6475', 'false', '2020-08-02 19:31:13'),
('bac8d28345094a3c84345f1b96', 'false', '2020-08-02 23:31:29'),
('baf99eece3f5d26a2d6dbd7146', 'false', '2020-08-02 23:31:26'),
('bb0f46b42f8c8c0d43f57d53bb', 'false', '2020-08-02 21:17:43'),
('bb39306d650840a0ef911c298f', 'false', '2020-08-03 01:16:11'),
('bb8e7c0bdb20f1b48baae874e1', 'false', '2020-08-02 21:17:48'),
('bb9dbc61e15777377cfa11e9ce', 'false', '2020-08-03 01:16:08'),
('bbbf53ffea17f206c96b1b64fd', 'false', '2020-08-02 21:17:44'),
('bc4a65bbd31b7d9e0480f3d0d2', 'false', '2020-08-02 23:31:26'),
('bc87cd62f567e14d8c655ffb9e', 'false', '2020-08-02 21:17:47'),
('bca7887e53bf884d81367eb193', 'false', '2020-08-02 19:31:11'),
('bd65c72393132292da4f4b41ae', 'false', '2020-08-02 19:31:12'),
('bda3a7f261442db5d77def86d1', 'false', '2020-08-03 01:16:11'),
('be03d231c60e9a8257d1b3ebc9', 'false', '2020-08-02 23:31:25'),
('bfc282993379b6290a49a6ea7d', 'false', '2020-08-03 01:16:11'),
('c070c263e1473b0fbe01975177', 'false', '2020-08-02 19:31:14'),
('c090117e99fb69731066d38654', 'false', '2020-08-02 21:17:43'),
('c0c6a524b909a427ff9596c189', 'false', '2020-08-02 19:31:13'),
('c0c7bd0673472cdce6d77d86e2', 'false', '2020-08-02 23:31:28'),
('c160d16d9a7231074e8993af06', 'false', '2020-08-02 19:31:15'),
('c1af5e014b8d1f8dbfb740889e', 'false', '2020-08-02 17:22:40'),
('c1c6d7e52939bcd1a602f5fb9c', 'false', '2020-08-03 01:16:10'),
('c1f3670a5a550987bf0e42b756', 'false', '2020-08-02 21:17:48'),
('c33ae8ae969bda34c0adfa9631', 'false', '2020-08-03 01:16:11'),
('c3597f78967fbe7d7466445186', 'false', '2020-08-02 21:17:47'),
('c3d20bc3456415eccef72d8bb3', 'false', '2020-08-02 21:17:45'),
('c3fcd0db4d65eca0a270999401', 'false', '2020-08-02 23:31:26'),
('c51714ae2ea7d3d230a3571d2f', 'false', '2020-08-03 01:16:11'),
('c53faebb59626c03b337c7966f', 'false', '2020-08-02 23:31:30'),
('c5c03a3c1b8578f39b81954b1b', 'false', '2020-08-02 17:22:41'),
('c5cc523883baadfa1556d22e6c', 'false', '2020-08-02 19:31:13'),
('c71446c2524bfe977bf13a0b73', 'false', '2020-08-02 23:31:30'),
('c780ecaadc97c5acd9786e03c9', 'false', '2020-08-02 21:17:48'),
('c78c2c5757ccf61b42c2e6e75e', 'false', '2020-08-03 01:16:10'),
('c7ffda1f6a124c21f16e176348', 'false', '2020-08-02 23:31:26'),
('c832aaa7fe2748f644aaa9005b', 'false', '2020-08-03 01:16:08'),
('c8f369c887248be1b462d2b6bc', 'false', '2020-08-02 15:22:29'),
('c93be15bf7741f5d907de2c4db', 'false', '2020-08-02 17:22:40'),
('c995f630e1a5b38210e8484828', 'false', '2020-08-02 17:22:39'),
('ca178b00c490077d9d167c7c58', 'false', '2020-08-03 01:16:11'),
('ca8b08999c8eb26614d4eef341', 'false', '2020-08-03 01:16:11'),
('cab9de93318bdce85ed17ed8d0', 'false', '2020-08-02 21:17:48'),
('cb165c86532c3158422dd6ce3c', 'false', '2020-08-02 23:31:28'),
('cbb9046c7608379c537671b469', 'false', '2020-08-02 21:17:43'),
('cc0aeaff852b469cfe2aa1fb88', 'false', '2020-08-02 23:31:27'),
('cc49d83932db28a41953b3464f', 'false', '2020-08-03 01:16:09'),
('ce1908ce5b7e6ed8c0cf40bd7f', 'false', '2020-08-02 17:22:37'),
('ce49f62a5121c26d60a7915ea9', 'false', '2020-08-03 01:16:07'),
('cea88664ec6faa7c282838061a', 'false', '2020-08-02 19:31:15'),
('cead1c908983a2b2b91150ff4b', 'false', '2020-08-03 01:16:10'),
('cf83e56fb7ba3951229178c66b', 'false', '2020-08-03 01:16:09'),
('d0297a64f3005f4cbc65908b3d', 'false', '2020-08-02 17:22:38'),
('d0a66cd4cd7185c0c063687926', 'false', '2020-08-02 17:22:40'),
('d0b7794cf5a44a295b20b1a910', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-03 01:29:50'),
('d0c73ca0c8b601f3e6ea41d6ab', 'false', '2020-08-02 23:31:28'),
('d1a9208a3ec532a8bb3467ae33', 'false', '2020-08-02 23:31:30'),
('d1f281e6b022e06cd63b911932', 'false', '2020-08-02 19:31:14'),
('d332cb2e29dd70a42a78177707', 'false', '2020-08-02 15:22:29'),
('d33aa14b468029510335ebf70d', 'false', '2020-08-02 19:31:14'),
('d37519b606c60a3d7980ff1d35', 'false', '2020-08-03 01:16:10'),
('d3a9dab66e97c91bae109ecba7', 'false', '2020-08-02 23:31:25'),
('d57382cb66aec08f9e16d6aaf1', 'false', '2020-08-02 15:22:25'),
('d618bb24f3ed6d08f173154827', 'false', '2020-08-03 01:16:06'),
('d697317556a70132d464e5b5d5', 'false', '2020-08-03 01:16:11'),
('d6bf62280710d822767fbeb6f6', 'false', '2020-08-02 23:31:26'),
('d78496fb797b0e097d1e3c1db1', 'false', '2020-08-02 17:22:40'),
('d903ec93a4dc135485d8cce789', 'false', '2020-08-02 19:31:13'),
('d92f7fd3fbc76f95ed75fcb441', 'false', '2020-08-02 21:17:42'),
('d96ea7bb5abdf721023d23d061', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 17:22:39'),
('d9d0a5a3c8e62023250ec396d4', 'false', '2020-08-02 17:22:37'),
('da4854ba0f79958f0137bd81bc', 'false', '2020-08-02 21:17:47'),
('dae05590e26c4cf18bc923955e', 'false', '2020-08-02 23:31:28'),
('dae644634613e521a959490f1e', 'false', '2020-08-02 21:17:44'),
('db20b1a0202f13fb9cf09e8fc6', 'false', '2020-08-02 23:31:29'),
('db646a523a952d7f7f300bdb71', 'false', '2020-08-02 21:17:48'),
('dc79c8be1c50b98d8dd07d4386', 'false', '2020-08-02 23:31:26'),
('dcb4942edf6df6748891380fd8', 'false', '2020-08-03 01:16:07'),
('dcf2bb0597130af7293e0333f1', 'false', '2020-08-02 15:22:25'),
('de87529eb6d125ec27087ecfd2', 'false', '2020-08-02 19:31:10'),
('deadc3449f64f88ffb2218a7e5', 'false', '2020-08-02 19:31:13'),
('deed4898dea0eed42be9a94258', 'false', '2020-08-02 23:31:30'),
('df09dcf2f2cc3c69be876d8838', 'false', '2020-08-02 19:31:13'),
('dfb913f656ffa19f7e9826226e', 'false', '2020-08-02 23:31:25'),
('e0551cddbc21dd5414a5c23113', 'false', '2020-08-02 21:17:47'),
('e07b95f3f0226468128e8fb1c3', 'false', '2020-08-02 21:17:47'),
('e0cad9ba697c8566dc0c2ae912', 'false', '2020-08-02 23:31:30'),
('e14c5593c27be5bfc3fb225c18', 'false', '2020-08-03 01:16:11'),
('e1d396fd3267e1110fe5c68f3e', 'false', '2020-08-02 19:31:13'),
('e22171553bdbb30ece642cd8f3', 'false', '2020-08-02 21:17:45'),
('e260ba54221045dd364819b9ce', 'false', '2020-08-02 23:31:30'),
('e2a0d68071b282c6e90e3d377d', 'false', '2020-08-02 21:17:47'),
('e2fcbba642c315bf4c3c86ecc4', 'false', '2020-08-02 19:31:15'),
('e3863d041246429624fd3333b9', 'false', '2020-08-03 01:16:10'),
('e3a7d5b2bba7d6d44e08b1fdef', 'false', '2020-08-02 15:22:26'),
('e4143cc5a018ee339961a9a1b2', 'false', '2020-08-02 21:17:48'),
('e4c49ff5244df73931ef1011af', 'false', '2020-08-02 23:31:29'),
('e50ba64297f009f680d88691cb', 'false', '2020-08-02 21:17:47'),
('e512a5ae447204042b417387d0', 'false', '2020-08-02 19:31:13'),
('e55059de7185a132cc98d7aa4a', 'false', '2020-08-02 19:31:12'),
('e63d3ae9d1744f136849da610e', 'false', '2020-08-02 21:17:45'),
('e6f2d2ba8cb85a15bea5d6c637', 'false', '2020-08-02 15:22:28'),
('e6fbf4d8e5464f7fa4513f4de3', 'false', '2020-08-02 19:31:14'),
('e72cd4628ec903715c273c4ec5', 'false', '2020-08-03 01:16:11'),
('e852d87f03e195d582c943c6b2', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 17:22:39'),
('e862ee31ffad5eb0d02e745225', 'false', '2020-08-02 23:31:30'),
('e873a44a877be7bca880c30623', 'false', '2020-08-02 21:17:48'),
('e959be98004d58da46561eb150', 'false', '2020-08-02 21:17:43'),
('e9852074cf0eff6e6dc55f2c31', 'false', '2020-08-02 19:31:14'),
('e98aa19963156cd552076d8143', 'false', '2020-08-02 21:17:46'),
('eadcd06f5bb0a69ebd7be1ad46', 'false', '2020-08-02 17:22:41'),
('eb16839b7aa58c61c54c8f8f8c', 'false', '2020-08-02 15:22:25'),
('eb3bdbbb86de435ce1e3b3f7be', 'false', '2020-08-02 21:17:47'),
('eb8917d3bdba174debd9c99151', 'false', '2020-08-02 19:31:13'),
('ec1c6aafdac7b580eb0d92fdfc', 'false', '2020-08-02 15:22:28'),
('ecd45f9bb66a89eab8979c7235', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 17:22:38'),
('ecfc8fa7594add3e7982099b98', 'false', '2020-08-03 01:16:05'),
('ed0cd03c1f3b2571f7f029ba62', 'false', '2020-08-02 21:17:47'),
('edf04a376f88c48c3b388539cf', 'false', '2020-08-02 19:31:15'),
('ef68d20d1f3bb24f0c7c540aae', 'false', '2020-08-02 15:22:25'),
('efb9bf8b085c5ba44f252ca94e', 'false', '2020-08-02 15:22:24'),
('f0fea2f9f6abd9deec633c2cf9', 'false', '2020-08-02 17:22:39'),
('f11d69d9659eab2f5104a78b21', 'false', '2020-08-03 01:16:11'),
('f1c5979e1bb5ffa0153152606c', 'false', '2020-08-02 19:31:10'),
('f2330c7cf660a4a2b59e32fd26', 'false', '2020-08-02 17:22:37'),
('f302499ed809815fdb2cc4e0e5', 'false', '2020-08-02 21:17:48'),
('f40f6aea8a51dcb17d59683b98', 'false', '2020-08-02 17:22:37'),
('f43f4cd30ba7ac6f8eb959f816', 'false', '2020-08-02 15:22:25'),
('f47c470942dfd093249f59c1b0', 'false', '2020-08-02 21:17:46'),
('f48535cba3ab3ae53231a2df30', 'false', '2020-08-02 23:31:30'),
('f4abc39cfb4de65bfd1a31beab', 'false', '2020-08-03 01:16:09'),
('f4f37237da99f96ee4abb04e09', 'false', '2020-08-03 01:16:11'),
('f67a6a8fe43c905425466f812d', 'false', '2020-08-02 21:17:47'),
('f77269c402e8b1d6da7ca9b685', 'false', '2020-08-02 21:17:47'),
('f7f9245c8ee59d6bb37b4d481a', 'false', '2020-08-02 21:17:44'),
('f7fdf1ec7fdd01992fde68f562', '{\"language\":\"ru-ru\",\"currency\":\"RUB\"}', '2020-08-02 17:22:37'),
('f81d78846d8194a383f8b59587', 'false', '2020-08-02 15:22:26'),
('f8863d199f9e51daf90a822105', 'false', '2020-08-02 17:22:41'),
('f8b540f88930f7dd91ad208e66', 'false', '2020-08-02 19:31:15'),
('f8bea7a31a17400c1bb04ffaf2', 'false', '2020-08-02 23:31:28'),
('fa416dbe9bae31cc6122767565', 'false', '2020-08-02 21:17:43'),
('faee69fb58f3e4a317c5387a3d', 'false', '2020-08-02 15:22:28'),
('fb4042ef2d0e6938c14eaef466', 'false', '2020-08-02 17:22:41'),
('fb9bac7cff487b7d321d9d0029', 'false', '2020-08-02 23:31:30'),
('fbe2ae706ab7568156dee489a6', 'false', '2020-08-02 23:31:26'),
('fcecde2e71b4da8b4e6079686f', 'false', '2020-08-02 23:31:30'),
('fecb58527d0b62f6b151a0a072', 'false', '2020-08-03 01:16:06'),
('ff619cd56ebfd118f885a5d8c5', 'false', '2020-08-02 21:17:47'),
('ffba0d38cd0240f9e750483d08', 'false', '2020-08-02 23:31:29'),
('ffbdac19b8650f6222aa5ec320', 'false', '2020-08-02 17:22:37');

-- --------------------------------------------------------

--
-- Table structure for table `oc_setting`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 05:25 PM
--

DROP TABLE IF EXISTS `oc_setting`;
CREATE TABLE `oc_setting` (
  `setting_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `code` varchar(128) NOT NULL,
  `key` varchar(128) NOT NULL,
  `value` text NOT NULL,
  `serialized` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_setting`
--

INSERT INTO `oc_setting` (`setting_id`, `store_id`, `code`, `key`, `value`, `serialized`) VALUES
(1508, 0, 'config', 'config_error_display', '1', 0),
(1507, 0, 'config', 'config_file_mime_allowed', 'text/plain\r\nimage/png\r\nimage/jpeg\r\nimage/gif\r\nimage/bmp\r\nimage/tiff\r\nimage/svg+xml\r\napplication/zip\r\n&quot;application/zip&quot;\r\napplication/x-zip\r\n&quot;application/x-zip&quot;\r\napplication/x-zip-compressed\r\n&quot;application/x-zip-compressed&quot;\r\napplication/rar\r\n&quot;application/rar&quot;\r\napplication/x-rar\r\n&quot;application/x-rar&quot;\r\napplication/x-rar-compressed\r\n&quot;application/x-rar-compressed&quot;\r\napplication/octet-stream\r\n&quot;application/octet-stream&quot;\r\naudio/mpeg\r\nvideo/quicktime\r\napplication/pdf', 0),
(1506, 0, 'config', 'config_file_ext_allowed', 'zip\r\ntxt\r\npng\r\njpe\r\njpeg\r\njpg\r\ngif\r\nbmp\r\nico\r\ntiff\r\ntif\r\nsvg\r\nsvgz\r\nzip\r\nrar\r\nmsi\r\ncab\r\nmp3\r\nqt\r\nmov\r\npdf\r\npsd\r\nai\r\neps\r\nps\r\ndoc', 0),
(1505, 0, 'config', 'config_file_max_size', '300000', 0),
(1500, 0, 'config', 'config_compression', '0', 0),
(1501, 0, 'config', 'config_secure', '0', 0),
(1502, 0, 'config', 'config_password', '1', 0),
(1503, 0, 'config', 'config_shared', '1', 0),
(1504, 0, 'config', 'config_encryption', 'hFqWaAmpd1epMru7VfY0iahzyShng0UsW5kH3BgT4RXRrNIExZaYcRHIHM2nlkezxCg7kiPaEVJa12X0SmPLB0FKfZoY8mqoaCjlUy0t8wJOvPZk5fObl0B5rjDGuHXbbdL48kgSgJzqYBeMY6QXzxRcJ4HvPOhYGHQtd3Do1sKRtXHQ6ObQQJtRTsavuj7GdEWdRuD8KzX9zBHMK3t9G6QNbaKppyrnIj8v1nt204dbUtsTkrPX8rTWZuW9CWWLCnMJFBBAE8CYzbtDjiFXGeTZPQrd6otmzO4tnOkkAzxPN588OlJ7iIGjCTVkuBTCqz1kcYAHifGRUVw0fd3f88B8Ez2JMSiRK7ofYvs0eTEOzdxQgiJ7loriU8pfBrxeoL42VxQAks6MS7ndCwYv2a4rpPvotZm3gpsWnrFlA0ebI3OVT0dowQmyO5BUgjx8mpUQpZf1wxdjVl3rC5G7UguX2SZfcx8pwlnfMKyo00VBr3eyEGmyx3RkhHMpOcH948zSwokKcmK63fmj505GYzlIY4gGM4GbUIbaq1rkGEmkMJQ8XZhZSfZRPmZ9yNFMsIhPXtYLE8hTDaWAvDoAWAFDpGg56FJTpT7HRpMlmsgDUaHwNoVkXHX3sI7m0D85D8BSaBVcCRLqOvtDwNNEb6TCz7U34hYXafZMQVQjzixJ87ohQIUeTcWeAJHNDnAQjfq79bV6gRbDVFseCcDJCa7KqgjHD0YSkqP9N5gOx2yfhpfCZqilVj1nwKQPxsaUt4fBReUNrmRvBd0p7AWJDGddSJDlPsMYI3SOXRuLuvfOlXp146y1fi5UTlk0QqOOmdsh3ljzZVBKUdmNuznQ65Ib9ezk5gw4lLg6OWYcRRiH9OHWUifcHOyreYiAvsLzTkIf36Srll6fyWZAvTw6ySrOHzvvffHyGqIv21ksCH9yg9QIP30wM5GlBnrgLVZ5ENzulX51BucZgZlGuEAhFMaVf5wgH3JXas7e2wgU5ccHzMke4qubEIgeyVp0ISTf', 0),
(4, 0, 'voucher', 'total_voucher_sort_order', '8', 0),
(5, 0, 'voucher', 'total_voucher_status', '1', 0),
(464, 0, 'module_ocfilter', 'module_ocfilter_sub_category', '1', 0),
(463, 0, 'module_ocfilter', 'module_ocfilter_status', '1', 0),
(1499, 0, 'config', 'config_robots', 'abot\r\ndbot\r\nebot\r\nhbot\r\nkbot\r\nlbot\r\nmbot\r\nnbot\r\nobot\r\npbot\r\nrbot\r\nsbot\r\ntbot\r\nvbot\r\nybot\r\nzbot\r\nbot.\r\nbot/\r\n_bot\r\n.bot\r\n/bot\r\n-bot\r\n:bot\r\n(bot\r\ncrawl\r\nslurp\r\nspider\r\nseek\r\naccoona\r\nacoon\r\nadressendeutschland\r\nah-ha.com\r\nahoy\r\naltavista\r\nananzi\r\nanthill\r\nappie\r\narachnophilia\r\narale\r\naraneo\r\naranha\r\narchitext\r\naretha\r\narks\r\nasterias\r\natlocal\r\natn\r\natomz\r\naugurfind\r\nbackrub\r\nbannana_bot\r\nbaypup\r\nbdfetch\r\nbig brother\r\nbiglotron\r\nbjaaland\r\nblackwidow\r\nblaiz\r\nblog\r\nblo.\r\nbloodhound\r\nboitho\r\nbooch\r\nbradley\r\nbutterfly\r\ncalif\r\ncassandra\r\nccubee\r\ncfetch\r\ncharlotte\r\nchurl\r\ncienciaficcion\r\ncmc\r\ncollective\r\ncomagent\r\ncombine\r\ncomputingsite\r\ncsci\r\ncurl\r\ncusco\r\ndaumoa\r\ndeepindex\r\ndelorie\r\ndepspid\r\ndeweb\r\ndie blinde kuh\r\ndigger\r\nditto\r\ndmoz\r\ndocomo\r\ndownload express\r\ndtaagent\r\ndwcp\r\nebiness\r\nebingbong\r\ne-collector\r\nejupiter\r\nemacs-w3 search engine\r\nesther\r\nevliya celebi\r\nezresult\r\nfalcon\r\nfelix ide\r\nferret\r\nfetchrover\r\nfido\r\nfindlinks\r\nfireball\r\nfish search\r\nfouineur\r\nfunnelweb\r\ngazz\r\ngcreep\r\ngenieknows\r\ngetterroboplus\r\ngeturl\r\nglx\r\ngoforit\r\ngolem\r\ngrabber\r\ngrapnel\r\ngralon\r\ngriffon\r\ngromit\r\ngrub\r\ngulliver\r\nhamahakki\r\nharvest\r\nhavindex\r\nhelix\r\nheritrix\r\nhku www octopus\r\nhomerweb\r\nhtdig\r\nhtml index\r\nhtml_analyzer\r\nhtmlgobble\r\nhubater\r\nhyper-decontextualizer\r\nia_archiver\r\nibm_planetwide\r\nichiro\r\niconsurf\r\niltrovatore\r\nimage.kapsi.net\r\nimagelock\r\nincywincy\r\nindexer\r\ninfobee\r\ninformant\r\ningrid\r\ninktomisearch.com\r\ninspector web\r\nintelliagent\r\ninternet shinchakubin\r\nip3000\r\niron33\r\nisraeli-search\r\nivia\r\njack\r\njakarta\r\njavabee\r\njetbot\r\njumpstation\r\nkatipo\r\nkdd-explorer\r\nkilroy\r\nknowledge\r\nkototoi\r\nkretrieve\r\nlabelgrabber\r\nlachesis\r\nlarbin\r\nlegs\r\nlibwww\r\nlinkalarm\r\nlink validator\r\nlinkscan\r\nlockon\r\nlwp\r\nlycos\r\nmagpie\r\nmantraagent\r\nmapoftheinternet\r\nmarvin/\r\nmattie\r\nmediafox\r\nmediapartners\r\nmercator\r\nmerzscope\r\nmicrosoft url control\r\nminirank\r\nmiva\r\nmj12\r\nmnogosearch\r\nmoget\r\nmonster\r\nmoose\r\nmotor\r\nmultitext\r\nmuncher\r\nmuscatferret\r\nmwd.search\r\nmyweb\r\nnajdi\r\nnameprotect\r\nnationaldirectory\r\nnazilla\r\nncsa beta\r\nnec-meshexplorer\r\nnederland.zoek\r\nnetcarta webmap engine\r\nnetmechanic\r\nnetresearchserver\r\nnetscoop\r\nnewscan-online\r\nnhse\r\nnokia6682/\r\nnomad\r\nnoyona\r\nnutch\r\nnzexplorer\r\nobjectssearch\r\noccam\r\nomni\r\nopen text\r\nopenfind\r\nopenintelligencedata\r\norb search\r\nosis-project\r\npack rat\r\npageboy\r\npagebull\r\npage_verifier\r\npanscient\r\nparasite\r\npartnersite\r\npatric\r\npear.\r\npegasus\r\nperegrinator\r\npgp key agent\r\nphantom\r\nphpdig\r\npicosearch\r\npiltdownman\r\npimptrain\r\npinpoint\r\npioneer\r\npiranha\r\nplumtreewebaccessor\r\npogodak\r\npoirot\r\npompos\r\npoppelsdorf\r\npoppi\r\npopular iconoclast\r\npsycheclone\r\npublisher\r\npython\r\nrambler\r\nraven search\r\nroach\r\nroad runner\r\nroadhouse\r\nrobbie\r\nrobofox\r\nrobozilla\r\nrules\r\nsalty\r\nsbider\r\nscooter\r\nscoutjet\r\nscrubby\r\nsearch.\r\nsearchprocess\r\nsemanticdiscovery\r\nsenrigan\r\nsg-scout\r\nshai\'hulud\r\nshark\r\nshopwiki\r\nsidewinder\r\nsift\r\nsilk\r\nsimmany\r\nsite searcher\r\nsite valet\r\nsitetech-rover\r\nskymob.com\r\nsleek\r\nsmartwit\r\nsna-\r\nsnappy\r\nsnooper\r\nsohu\r\nspeedfind\r\nsphere\r\nsphider\r\nspinner\r\nspyder\r\nsteeler/\r\nsuke\r\nsuntek\r\nsupersnooper\r\nsurfnomore\r\nsven\r\nsygol\r\nszukacz\r\ntach black widow\r\ntarantula\r\ntempleton\r\n/teoma\r\nt-h-u-n-d-e-r-s-t-o-n-e\r\ntheophrastus\r\ntitan\r\ntitin\r\ntkwww\r\ntoutatis\r\nt-rex\r\ntutorgig\r\ntwiceler\r\ntwisted\r\nucsd\r\nudmsearch\r\nurl check\r\nupdated\r\nvagabondo\r\nvalkyrie\r\nverticrawl\r\nvictoria\r\nvision-search\r\nvolcano\r\nvoyager/\r\nvoyager-hc\r\nw3c_validator\r\nw3m2\r\nw3mir\r\nwalker\r\nwallpaper\r\nwanderer\r\nwauuu\r\nwavefire\r\nweb core\r\nweb hopper\r\nweb wombat\r\nwebbandit\r\nwebcatcher\r\nwebcopy\r\nwebfoot\r\nweblayers\r\nweblinker\r\nweblog monitor\r\nwebmirror\r\nwebmonkey\r\nwebquest\r\nwebreaper\r\nwebsitepulse\r\nwebsnarf\r\nwebstolperer\r\nwebvac\r\nwebwalk\r\nwebwatch\r\nwebwombat\r\nwebzinger\r\nwhizbang\r\nwhowhere\r\nwild ferret\r\nworldlight\r\nwwwc\r\nwwwster\r\nxenu\r\nxget\r\nxift\r\nxirq\r\nyandex\r\nyanga\r\nyeti\r\nyodao\r\nzao\r\nzippp\r\nzyborg', 0),
(1498, 0, 'config', 'config_seo_url', '1', 0),
(1477, 0, 'config', 'config_affiliate_group_id', '1', 0),
(1478, 0, 'config', 'config_affiliate_approval', '0', 0),
(1479, 0, 'config', 'config_affiliate_auto', '0', 0),
(1480, 0, 'config', 'config_affiliate_commission', '5', 0),
(1481, 0, 'config', 'config_affiliate_id', '4', 0),
(1482, 0, 'config', 'config_return_id', '0', 0),
(1483, 0, 'config', 'config_return_status_id', '2', 0),
(1484, 0, 'config', 'config_captcha', '', 0),
(1485, 0, 'config', 'config_captcha_page', '[\"review\",\"return\",\"contact\"]', 1),
(1486, 0, 'config', 'config_logo', 'catalog/logo.png', 0),
(1487, 0, 'config', 'config_icon', 'catalog/cart.png', 0),
(1488, 0, 'config', 'config_mail_engine', 'mail', 0),
(1489, 0, 'config', 'config_mail_parameter', '', 0),
(1490, 0, 'config', 'config_mail_smtp_hostname', '', 0),
(1491, 0, 'config', 'config_mail_smtp_username', '', 0),
(1492, 0, 'config', 'config_mail_smtp_password', '', 0),
(1493, 0, 'config', 'config_mail_smtp_port', '25', 0),
(1494, 0, 'config', 'config_mail_smtp_timeout', '5', 0),
(1495, 0, 'config', 'config_mail_alert', '[\"order\"]', 1),
(1496, 0, 'config', 'config_mail_alert_email', '', 0),
(1497, 0, 'config', 'config_maintenance', '0', 0),
(1476, 0, 'config', 'config_stock_checkout', '0', 0),
(1475, 0, 'config', 'config_stock_warning', '0', 0),
(1470, 0, 'config', 'config_processing_status', '[\"5\",\"1\",\"2\",\"12\",\"3\"]', 1),
(1471, 0, 'config', 'config_complete_status', '[\"5\",\"3\"]', 1),
(1472, 0, 'config', 'config_fraud_status_id', '7', 0),
(1473, 0, 'config', 'config_api_id', '1', 0),
(1474, 0, 'config', 'config_stock_display', '0', 0),
(95, 0, 'payment_free_checkout', 'payment_free_checkout_status', '1', 0),
(96, 0, 'payment_free_checkout', 'free_checkout_order_status_id', '1', 0),
(97, 0, 'payment_free_checkout', 'payment_free_checkout_sort_order', '1', 0),
(98, 0, 'payment_cod', 'payment_cod_sort_order', '5', 0),
(99, 0, 'payment_cod', 'payment_cod_total', '0.01', 0),
(100, 0, 'payment_cod', 'payment_cod_order_status_id', '1', 0),
(101, 0, 'payment_cod', 'payment_cod_geo_zone_id', '0', 0),
(102, 0, 'payment_cod', 'payment_cod_status', '1', 0),
(103, 0, 'shipping_flat', 'shipping_flat_sort_order', '1', 0),
(104, 0, 'shipping_flat', 'shipping_flat_status', '1', 0),
(105, 0, 'shipping_flat', 'shipping_flat_geo_zone_id', '0', 0),
(106, 0, 'shipping_flat', 'shipping_flat_tax_class_id', '9', 0),
(107, 0, 'shipping_flat', 'shipping_flat_cost', '5.00', 0),
(108, 0, 'total_shipping', 'total_shipping_sort_order', '3', 0),
(109, 0, 'total_sub_total', 'sub_total_sort_order', '1', 0),
(110, 0, 'total_sub_total', 'total_sub_total_status', '1', 0),
(111, 0, 'total_tax', 'total_tax_status', '1', 0),
(112, 0, 'total_total', 'total_total_sort_order', '9', 0),
(113, 0, 'total_total', 'total_total_status', '1', 0),
(114, 0, 'total_tax', 'total_tax_sort_order', '5', 0),
(115, 0, 'total_credit', 'total_credit_sort_order', '7', 0),
(116, 0, 'total_credit', 'total_credit_status', '1', 0),
(117, 0, 'total_reward', 'total_reward_sort_order', '2', 0),
(118, 0, 'total_reward', 'total_reward_status', '1', 0),
(119, 0, 'total_shipping', 'total_shipping_status', '1', 0),
(120, 0, 'total_shipping', 'total_shipping_estimator', '1', 0),
(121, 0, 'total_coupon', 'total_coupon_sort_order', '4', 0),
(122, 0, 'total_coupon', 'total_coupon_status', '1', 0),
(123, 0, 'module_category', 'module_category_status', '1', 0),
(124, 0, 'module_account', 'module_account_status', '1', 0),
(125, 0, 'theme_default', 'theme_default_product_limit', '15', 0),
(126, 0, 'theme_default', 'theme_default_product_description_length', '100', 0),
(127, 0, 'theme_default', 'theme_default_image_thumb_width', '228', 0),
(128, 0, 'theme_default', 'theme_default_image_thumb_height', '228', 0),
(129, 0, 'theme_default', 'theme_default_image_popup_width', '500', 0),
(130, 0, 'theme_default', 'theme_default_image_popup_height', '500', 0),
(131, 0, 'theme_default', 'theme_default_image_category_width', '80', 0),
(132, 0, 'theme_default', 'theme_default_image_category_height', '80', 0),
(133, 0, 'theme_default', 'theme_default_image_product_width', '228', 0),
(134, 0, 'theme_default', 'theme_default_image_product_height', '228', 0),
(135, 0, 'theme_default', 'theme_default_image_additional_width', '74', 0),
(136, 0, 'theme_default', 'theme_default_image_additional_height', '74', 0),
(137, 0, 'theme_default', 'theme_default_image_related_width', '200', 0),
(138, 0, 'theme_default', 'theme_default_image_related_height', '200', 0),
(139, 0, 'theme_default', 'theme_default_image_compare_width', '90', 0),
(140, 0, 'theme_default', 'theme_default_image_compare_height', '90', 0),
(141, 0, 'theme_default', 'theme_default_image_wishlist_width', '47', 0),
(142, 0, 'theme_default', 'theme_default_image_wishlist_height', '47', 0),
(143, 0, 'theme_default', 'theme_default_image_cart_height', '47', 0),
(144, 0, 'theme_default', 'theme_default_image_cart_width', '47', 0),
(145, 0, 'theme_default', 'theme_default_image_location_height', '50', 0),
(146, 0, 'theme_default', 'theme_default_image_location_width', '268', 0),
(147, 0, 'theme_default', 'theme_default_directory', 'default', 0),
(148, 0, 'theme_default', 'theme_default_status', '1', 0),
(149, 0, 'dashboard_activity', 'dashboard_activity_status', '1', 0),
(150, 0, 'dashboard_activity', 'dashboard_activity_sort_order', '7', 0),
(151, 0, 'dashboard_sale', 'dashboard_sale_status', '1', 0),
(152, 0, 'dashboard_sale', 'dashboard_sale_width', '3', 0),
(153, 0, 'dashboard_chart', 'dashboard_chart_status', '1', 0),
(154, 0, 'dashboard_chart', 'dashboard_chart_width', '6', 0),
(155, 0, 'dashboard_customer', 'dashboard_customer_status', '1', 0),
(156, 0, 'dashboard_customer', 'dashboard_customer_width', '3', 0),
(157, 0, 'dashboard_map', 'dashboard_map_status', '1', 0),
(158, 0, 'dashboard_map', 'dashboard_map_width', '6', 0),
(159, 0, 'dashboard_online', 'dashboard_online_status', '1', 0),
(160, 0, 'dashboard_online', 'dashboard_online_width', '3', 0),
(161, 0, 'dashboard_order', 'dashboard_order_sort_order', '1', 0),
(162, 0, 'dashboard_order', 'dashboard_order_status', '1', 0),
(163, 0, 'dashboard_order', 'dashboard_order_width', '3', 0),
(164, 0, 'dashboard_sale', 'dashboard_sale_sort_order', '2', 0),
(165, 0, 'dashboard_customer', 'dashboard_customer_sort_order', '3', 0),
(166, 0, 'dashboard_online', 'dashboard_online_sort_order', '4', 0),
(167, 0, 'dashboard_map', 'dashboard_map_sort_order', '5', 0),
(168, 0, 'dashboard_chart', 'dashboard_chart_sort_order', '6', 0),
(169, 0, 'dashboard_recent', 'dashboard_recent_status', '1', 0),
(170, 0, 'dashboard_recent', 'dashboard_recent_sort_order', '8', 0),
(171, 0, 'dashboard_activity', 'dashboard_activity_width', '4', 0),
(172, 0, 'dashboard_recent', 'dashboard_recent_width', '8', 0),
(173, 0, 'report_customer_activity', 'report_customer_activity_status', '1', 0),
(174, 0, 'report_customer_activity', 'report_customer_activity_sort_order', '1', 0),
(175, 0, 'report_customer_order', 'report_customer_order_status', '1', 0),
(176, 0, 'report_customer_order', 'report_customer_order_sort_order', '2', 0),
(177, 0, 'report_customer_reward', 'report_customer_reward_status', '1', 0),
(178, 0, 'report_customer_reward', 'report_customer_reward_sort_order', '3', 0),
(179, 0, 'report_customer_search', 'report_customer_search_sort_order', '3', 0),
(180, 0, 'report_customer_search', 'report_customer_search_status', '1', 0),
(181, 0, 'report_customer_transaction', 'report_customer_transaction_status', '1', 0),
(182, 0, 'report_customer_transaction', 'report_customer_transaction_status_sort_order', '4', 0),
(183, 0, 'report_sale_tax', 'report_sale_tax_status', '1', 0),
(184, 0, 'report_sale_tax', 'report_sale_tax_sort_order', '5', 0),
(185, 0, 'report_sale_shipping', 'report_sale_shipping_status', '1', 0),
(186, 0, 'report_sale_shipping', 'report_sale_shipping_sort_order', '6', 0),
(187, 0, 'report_sale_return', 'report_sale_return_status', '1', 0),
(188, 0, 'report_sale_return', 'report_sale_return_sort_order', '7', 0),
(189, 0, 'report_sale_order', 'report_sale_order_status', '1', 0),
(190, 0, 'report_sale_order', 'report_sale_order_sort_order', '8', 0),
(191, 0, 'report_sale_coupon', 'report_sale_coupon_status', '1', 0),
(192, 0, 'report_sale_coupon', 'report_sale_coupon_sort_order', '9', 0),
(193, 0, 'report_product_viewed', 'report_product_viewed_status', '1', 0),
(194, 0, 'report_product_viewed', 'report_product_viewed_sort_order', '10', 0),
(195, 0, 'report_product_purchased', 'report_product_purchased_status', '1', 0),
(196, 0, 'report_product_purchased', 'report_product_purchased_sort_order', '11', 0),
(197, 0, 'report_marketing', 'report_marketing_status', '1', 0),
(198, 0, 'report_marketing', 'report_marketing_sort_order', '12', 0),
(199, 0, 'developer', 'developer_theme', '1', 0),
(200, 0, 'developer', 'developer_sass', '1', 0),
(1469, 0, 'config', 'config_order_status_id', '1', 0),
(1468, 0, 'config', 'config_checkout_id', '5', 0),
(1467, 0, 'config', 'config_checkout_guest', '1', 0),
(1466, 0, 'config', 'config_cart_weight', '1', 0),
(1465, 0, 'config', 'config_invoice_prefix', 'INV-2020-00', 0),
(1464, 0, 'config', 'config_account_id', '3', 0),
(1463, 0, 'config', 'config_login_attempts', '5', 0),
(1462, 0, 'config', 'config_customer_price', '0', 0),
(1461, 0, 'config', 'config_customer_group_display', '[\"1\"]', 1),
(1460, 0, 'config', 'config_customer_group_id', '1', 0),
(1459, 0, 'config', 'config_customer_search', '0', 0),
(1458, 0, 'config', 'config_customer_activity', '0', 0),
(1457, 0, 'config', 'config_customer_online', '0', 0),
(1456, 0, 'config', 'config_tax_customer', 'shipping', 0),
(1455, 0, 'config', 'config_tax_default', 'shipping', 0),
(1454, 0, 'config', 'config_tax', '0', 0),
(1453, 0, 'config', 'config_voucher_max', '1000', 0),
(1452, 0, 'config', 'config_voucher_min', '1', 0),
(1451, 0, 'config', 'config_review_guest', '1', 0),
(1450, 0, 'config', 'config_review_status', '1', 0),
(1449, 0, 'config', 'config_limit_admin', '20', 0),
(1448, 0, 'config', 'config_product_count', '0', 0),
(1447, 0, 'config', 'config_weight_class_id', '1', 0),
(1446, 0, 'config', 'config_length_class_id', '1', 0),
(1445, 0, 'config', 'config_currency_auto', '0', 0),
(1444, 0, 'config', 'config_currency', 'RUB', 0),
(1443, 0, 'config', 'config_admin_language', 'ru-ru', 0),
(1442, 0, 'config', 'config_language', 'ru-ru', 0),
(1441, 0, 'config', 'config_zone_id', '2761', 0),
(1440, 0, 'config', 'config_country_id', '176', 0),
(1438, 0, 'config', 'config_open', '', 0),
(1439, 0, 'config', 'config_comment', '', 0),
(1437, 0, 'config', 'config_image', '', 0),
(1436, 0, 'config', 'config_fax', '', 0),
(1435, 0, 'config', 'config_telephone', '123456789', 0),
(1434, 0, 'config', 'config_email', 'm.molkov@wbooster.ru', 0),
(1433, 0, 'config', 'config_geocode', '', 0),
(1432, 0, 'config', 'config_address', 'Address 1', 0),
(1431, 0, 'config', 'config_owner', 'Your Name', 0),
(1430, 0, 'config', 'config_name', 'Your Store', 0),
(1429, 0, 'config', 'config_layout_id', '4', 0),
(1428, 0, 'config', 'config_theme', 'default', 0),
(1427, 0, 'config', 'config_meta_keyword', '', 0),
(1426, 0, 'config', 'config_meta_description', 'My Store', 0),
(1425, 0, 'config', 'config_meta_title', 'Your Store', 0),
(465, 0, 'module_ocfilter', 'module_ocfilter_sitemap_status', '1', 0),
(466, 0, 'module_ocfilter', 'module_ocfilter_sitemap_link', 'http://opencart.mmvmolkov.beget.tech/index.php?route=extension/feed/ocfilter_sitemap', 0),
(467, 0, 'module_ocfilter', 'module_ocfilter_search_button', '1', 0),
(468, 0, 'module_ocfilter', 'module_ocfilter_show_selected', '1', 0),
(469, 0, 'module_ocfilter', 'module_ocfilter_show_price', '1', 0),
(470, 0, 'module_ocfilter', 'module_ocfilter_show_counter', '1', 0),
(471, 0, 'module_ocfilter', 'module_ocfilter_manufacturer', '1', 0),
(472, 0, 'module_ocfilter', 'module_ocfilter_manufacturer_type', 'checkbox', 0),
(473, 0, 'module_ocfilter', 'module_ocfilter_stock_status', '0', 0),
(474, 0, 'module_ocfilter', 'module_ocfilter_stock_status_method', 'quantity', 0),
(475, 0, 'module_ocfilter', 'module_ocfilter_stock_status_type', 'checkbox', 0),
(476, 0, 'module_ocfilter', 'module_ocfilter_stock_out_value', '0', 0),
(477, 0, 'module_ocfilter', 'module_ocfilter_manual_price', '0', 0),
(478, 0, 'module_ocfilter', 'module_ocfilter_consider_discount', '0', 0),
(479, 0, 'module_ocfilter', 'module_ocfilter_consider_special', '0', 0),
(480, 0, 'module_ocfilter', 'module_ocfilter_consider_option', '0', 0),
(481, 0, 'module_ocfilter', 'module_ocfilter_show_options_limit', '0', 0),
(482, 0, 'module_ocfilter', 'module_ocfilter_show_values_limit', '0', 0),
(483, 0, 'module_ocfilter', 'module_ocfilter_hide_empty_values', '1', 0),
(484, 0, 'module_ocfilter', 'module_ocfilter_copy_type', 'checkbox', 0),
(485, 0, 'module_ocfilter', 'module_ocfilter_copy_status', '-1', 0),
(486, 0, 'module_ocfilter', 'module_ocfilter_copy_attribute', '1', 0),
(487, 0, 'module_ocfilter', 'module_ocfilter_attribute_separator', '', 0),
(488, 0, 'module_ocfilter', 'module_ocfilter_copy_filter', '0', 0),
(489, 0, 'module_ocfilter', 'module_ocfilter_copy_option', '0', 0),
(490, 0, 'module_ocfilter', 'module_ocfilter_copy_truncate', '0', 0),
(491, 0, 'module_ocfilter', 'module_ocfilter_copy_category', '1', 0),
(2179, 0, 'yandex_money', 'yandex_money_market_option_size_option_id', '2', 0),
(880, 0, 'advanced_sitemap', 'advanced_sitemap_default_lang', 'ru-ru', 0),
(2020, 0, 'mlseo', 'mlseo_default_lang', 'ru-ru', 0),
(2018, 0, 'mlseo', 'mlseo_lang_codes', '{\"2\":\"ru-ru\"}', 1),
(2019, 0, 'mlseo', 'mlseo_lang_to_store', '{\"ru-ru\":{\"config_url\":\"http:\\/\\/opencart.mmvmolkov.beget.tech\",\"config_ssl\":\"http:\\/\\/opencart.mmvmolkov.beget.tech\"}}', 1),
(2016, 0, 'mlseo', 'mlseo_manufacturer_url_pattern', '[name]', 0),
(2017, 0, 'mlseo', 'mlseo_ml_mode', '', 0),
(2014, 0, 'mlseo', 'mlseo_information_description_pattern', '[name] - [desc]', 0),
(2013, 0, 'mlseo', 'mlseo_information_keyword_pattern', '[name] [desc]', 0),
(2012, 0, 'mlseo', 'mlseo_information_title_pattern', '[name]', 0),
(2011, 0, 'mlseo', 'mlseo_information_h3_pattern', '[name]', 0),
(2010, 0, 'mlseo', 'mlseo_information_h2_pattern', '[name]', 0),
(2009, 0, 'mlseo', 'mlseo_information_h1_pattern', '[name]', 0),
(2008, 0, 'mlseo', 'mlseo_information_url_pattern', '[name]', 0),
(2007, 0, 'mlseo', 'mlseo_category_full_desc_pattern', '[name]', 0),
(2006, 0, 'mlseo', 'mlseo_category_description_pattern', '[name] - [desc]', 0),
(2004, 0, 'mlseo', 'mlseo_category_title_pattern', '[name]', 0),
(2005, 0, 'mlseo', 'mlseo_category_keyword_pattern', '[name], [desc]', 0),
(2003, 0, 'mlseo', 'mlseo_category_h3_pattern', '[name]', 0),
(2002, 0, 'mlseo', 'mlseo_category_h2_pattern', '[name]', 0),
(2001, 0, 'mlseo', 'mlseo_category_h1_pattern', '[name]', 0),
(2000, 0, 'mlseo', 'mlseo_category_url_pattern', '[name]', 0),
(1997, 0, 'mlseo', 'mlseo_product_related_samecat', '', 0),
(1998, 0, 'mlseo', 'mlseo_product_related_no', '5', 0),
(1999, 0, 'mlseo', 'mlseo_product_related_relevance', '5', 0),
(1993, 0, 'mlseo', 'mlseo_product_image_title_pattern', '[name]', 0),
(1994, 0, 'mlseo', 'mlseo_product_image_name_pattern', '[name]', 0),
(1995, 0, 'mlseo', 'mlseo_product_tag_pattern', '[name], [model], [category]', 0),
(1996, 0, 'mlseo', 'mlseo_product_full_desc_pattern', '[name] - [model] - [category]', 0),
(1992, 0, 'mlseo', 'mlseo_product_image_alt_pattern', '[name]', 0),
(1991, 0, 'mlseo', 'mlseo_product_description_pattern', '[name] - [model] - [category] - [desc]', 0),
(1990, 0, 'mlseo', 'mlseo_product_keyword_pattern', '[name], [model], [category]', 0),
(1989, 0, 'mlseo', 'mlseo_product_title_pattern', '[name] - [model]', 0),
(1988, 0, 'mlseo', 'mlseo_product_h3_pattern', '[name]', 0),
(1986, 0, 'mlseo', 'mlseo_product_h1_pattern', '[name]', 0),
(1987, 0, 'mlseo', 'mlseo_product_h2_pattern', '[name]', 0),
(1985, 0, 'mlseo', 'mlseo_product_url_pattern', '[name]', 0),
(1984, 0, 'mlseo', 'mlseo_fix_cart', '1', 0),
(1983, 0, 'mlseo', 'mlseo_fpp_slash', '', 0),
(1982, 0, 'mlseo', 'mlseo_fpp_tag_2', '', 0),
(1981, 0, 'mlseo', 'mlseo_fix_search', '1', 0),
(1980, 0, 'mlseo', 'mlseo_fpp_remove_search', '1', 0),
(1979, 0, 'mlseo', 'mlseo_fpp_brand_parent', '1', 0),
(1978, 0, 'mlseo', 'mlseo_absolute', '1', 0),
(1977, 0, 'mlseo', 'mlseo_fpp_directcat', '1', 0),
(1976, 0, 'mlseo', 'mlseo_fpp_bc_mode', '0', 0),
(1972, 0, 'mlseo', 'mlseo_tcard_data', '{\"nick\":\"\",\"home_type\":\"summary\",\"desc\":\"1\"}', 1),
(1973, 0, 'mlseo', 'mlseo_gpublisher_data', '{\"url\":\"\"}', 1),
(1974, 0, 'mlseo', 'mlseo_fpp_mode', '0', 0),
(1975, 0, 'mlseo', 'mlseo_fpp_breadcrumbs', '0', 0),
(1970, 0, 'mlseo', 'mlseo_microdata_data', '{\"product\":\"1\",\"model\":\"1\",\"brand\":\"1\",\"reviews\":\"1\",\"organization\":\"1\",\"organization_search\":\"1\",\"contact\":[{\"phone\":\"\",\"type\":\"customer support\"},{\"phone\":\"\",\"type\":\"customer support\"},{\"phone\":\"\",\"type\":\"customer support\"}],\"store\":\"1\",\"store_logo\":\"1\",\"store_mail\":\"1\",\"address_street\":\"\",\"address_city\":\"\",\"address_region\":\"\",\"address_code\":\"\",\"address_country\":\"\",\"same_as\":[\"\",\"\",\"\"],\"pricerange\":\"\",\"website\":\"1\",\"website_search\":\"1\",\"gps_lat\":\"\",\"gps_long\":\"\",\"breadcrumbs\":\"1\"}', 1),
(1971, 0, 'mlseo', 'mlseo_opengraph_data', '{\"page_id\":\"\",\"desc\":\"1\"}', 1),
(1969, 0, 'mlseo', 'mlseo_title_suffix', '{\"02\":\"\"}', 1),
(1968, 0, 'mlseo', 'mlseo_title_prefix', '{\"02\":\"\"}', 1),
(1967, 0, 'mlseo', 'mlseo_store', '{\"0\":{\"analytics\":\"\"},\"02\":{\"seo_title\":\"\",\"description\":\"\",\"keywords\":\"\",\"title\":\"\",\"h2\":\"\",\"h3\":\"\"}}', 1),
(1966, 0, 'mlseo', 'mlseo_robots_default', '', 0),
(1965, 0, 'mlseo', 'mlseo_reviews', '', 0),
(1964, 0, 'mlseo', 'mlseo_canonical', '1', 0),
(1963, 0, 'mlseo', 'mlseo_cache', '', 0),
(1962, 0, 'mlseo', 'mlseo_insertautotitle', '1', 0),
(1961, 0, 'mlseo', 'mlseo_editautometadesc', '1', 0),
(1960, 0, 'mlseo', 'mlseo_insertautometadesc', '1', 0),
(1959, 0, 'mlseo', 'mlseo_editautometakeyword', '1', 0),
(1958, 0, 'mlseo', 'mlseo_insertautometakeyword', '1', 0),
(1957, 0, 'mlseo', 'mlseo_editautoseotitle', '1', 0),
(1956, 0, 'mlseo', 'mlseo_insertautoseotitle', '1', 0),
(1955, 0, 'mlseo', 'mlseo_editautourl', '1', 0),
(1954, 0, 'mlseo', 'mlseo_insertautourl', '1', 0),
(1953, 0, 'mlseo', 'mlseo_ascii_2', '1', 0),
(1952, 0, 'mlseo', 'mlseo_duplicate', '1', 0),
(1951, 0, 'mlseo', 'mlseo_lowercase', '1', 0),
(1950, 0, 'mlseo', 'mlseo_remove_2', '', 0),
(1949, 0, 'mlseo', 'mlseo_extension', '', 0),
(1948, 0, 'mlseo', 'mlseo_whitespace', '-', 0),
(1947, 0, 'mlseo', 'mlseo_pagination_fix', '1', 0),
(1946, 0, 'mlseo', 'mlseo_hreflang', '1', 0),
(1945, 0, 'mlseo', 'mlseo_store_mode', '', 0),
(1944, 0, 'mlseo', 'mlseo_flag', '', 0),
(1943, 0, 'mlseo', 'mlseo_flag_mode', '', 0),
(1942, 0, 'mlseo', 'mlseo_special_group', '', 0),
(1941, 0, 'mlseo', 'mlseo_redirect_dynamic', '1', 0),
(1940, 0, 'mlseo', 'mlseo_redirect_canonical', '', 0),
(879, 0, 'advanced_sitemap', 'advanced_sitemap_limit', '', 0),
(877, 0, 'advanced_sitemap', 'advanced_sitemap_status', '1', 0),
(878, 0, 'advanced_sitemap', 'advanced_sitemap_cfg', '{\"product\":{\"status\":\"1\",\"priority\":\"0.8\",\"freq\":\"weekly\"},\"category\":{\"status\":\"1\",\"priority\":\"0.8\",\"freq\":\"weekly\"},\"manufacturer\":{\"status\":\"1\",\"priority\":\"0.7\",\"freq\":\"monthly\"},\"information\":{\"status\":\"1\",\"priority\":\"0.7\",\"freq\":\"monthly\"}}', 1),
(881, 0, 'module_quickcheckout', 'module_quickcheckout_status', '1', 0),
(984, 0, 'quickcheckout', 'quickcheckout_field_rules', '{\"display\":\"on\",\"required\":\"on\",\"sort_order\":\"\"}', 1),
(983, 0, 'quickcheckout', 'quickcheckout_field_shipping', '{\"sort_order\":\"\"}', 1),
(982, 0, 'quickcheckout', 'quickcheckout_field_register', '{\"sort_order\":\"\"}', 1),
(981, 0, 'quickcheckout', 'quickcheckout_field_newsletter', '{\"required\":\"on\",\"sort_order\":\"\"}', 1),
(980, 0, 'quickcheckout', 'quickcheckout_field_zone', '{\"default\":\"2761\",\"sort_order\":\"13\"}', 1),
(979, 0, 'quickcheckout', 'quickcheckout_field_country', '{\"default\":\"176\",\"sort_order\":\"12\"}', 1),
(978, 0, 'quickcheckout', 'quickcheckout_field_postcode', '{\"default\":{\"2\":\"\"},\"placeholder\":{\"2\":\"\"},\"sort_order\":\"11\"}', 1),
(977, 0, 'quickcheckout', 'quickcheckout_field_city', '{\"default\":{\"2\":\"\"},\"placeholder\":{\"2\":\"\"},\"sort_order\":\"10\"}', 1),
(976, 0, 'quickcheckout', 'quickcheckout_field_address_2', '{\"default\":{\"2\":\"\"},\"placeholder\":{\"2\":\"\"},\"sort_order\":\"9\"}', 1),
(975, 0, 'quickcheckout', 'quickcheckout_field_address_1', '{\"default\":{\"2\":\"\"},\"placeholder\":{\"2\":\"\"},\"sort_order\":\"8\"}', 1),
(974, 0, 'quickcheckout', 'quickcheckout_field_customer_group', '{\"sort_order\":\"7\"}', 1),
(973, 0, 'quickcheckout', 'quickcheckout_field_company', '{\"default\":{\"2\":\"\"},\"placeholder\":{\"2\":\"\"},\"sort_order\":\"6\"}', 1),
(972, 0, 'quickcheckout', 'quickcheckout_field_telephone', '{\"display\":\"on\",\"required\":\"on\",\"default\":{\"2\":\"\"},\"placeholder\":{\"2\":\"\"},\"sort_order\":\"4\"}', 1),
(971, 0, 'quickcheckout', 'quickcheckout_field_email', '{\"display\":\"on\",\"required\":\"on\",\"default\":{\"2\":\"\"},\"placeholder\":{\"2\":\"\"},\"sort_order\":\"3\"}', 1),
(970, 0, 'quickcheckout', 'quickcheckout_field_lastname', '{\"display\":\"on\",\"required\":\"on\",\"default\":{\"2\":\"\"},\"placeholder\":{\"2\":\"\"},\"sort_order\":\"2\"}', 1),
(969, 0, 'quickcheckout', 'quickcheckout_field_firstname', '{\"display\":\"on\",\"required\":\"on\",\"default\":{\"2\":\"\"},\"placeholder\":{\"2\":\"\"},\"sort_order\":\"1\"}', 1),
(967, 0, 'quickcheckout', 'quickcheckout_loading_display', '0', 0),
(968, 0, 'quickcheckout', 'quickcheckout_custom_css', '', 0),
(966, 0, 'quickcheckout', 'quickcheckout_load_screen', '0', 0),
(964, 0, 'quickcheckout', 'quickcheckout_show_shipping_address', '0', 0),
(965, 0, 'quickcheckout', 'quickcheckout_slide_effect', '0', 0),
(962, 0, 'quickcheckout', 'quickcheckout_login_module', '1', 0),
(963, 0, 'quickcheckout', 'quickcheckout_cart', '1', 0),
(961, 0, 'quickcheckout', 'quickcheckout_step', '{\"login\":{\"column\":\"1\",\"row\":\"1\"},\"payment_address\":{\"column\":\"1\",\"row\":\"2\"},\"shipping_address\":{\"column\":\"1\",\"row\":\"3\"},\"shipping_method\":{\"column\":\"2\",\"row\":\"1\"},\"payment_method\":{\"column\":\"3\",\"row\":\"1\"},\"cart\":{\"column\":\"4\",\"row\":\"2\"},\"coupons\":{\"column\":\"4\",\"row\":\"2\"},\"confirm\":{\"column\":\"4\",\"row\":\"2\"}}', 1),
(960, 0, 'quickcheckout', 'quickcheckout_column', '{\"1\":\"4\",\"2\":\"4\",\"3\":\"4\",\"4\":\"8\"}', 1),
(959, 0, 'quickcheckout', 'quickcheckout_responsive', '1', 0),
(958, 0, 'quickcheckout', 'quickcheckout_layout', '4', 0),
(957, 0, 'quickcheckout', 'quickcheckout_keyword', '{\"2\":\"checkout\"}', 1),
(956, 0, 'quickcheckout', 'quickcheckout_proceed_button_text', '{\"2\":\"\"}', 1),
(955, 0, 'quickcheckout', 'quickcheckout_force_bootstrap', '0', 0),
(954, 0, 'quickcheckout', 'quickcheckout_skip_cart', '1', 0),
(953, 0, 'quickcheckout', 'quickcheckout_payment_target', '#button-confirm, .button, .btn', 0),
(952, 0, 'quickcheckout', 'quickcheckout_auto_submit', '1', 0),
(951, 0, 'quickcheckout', 'quickcheckout_text_error', '1', 0),
(950, 0, 'quickcheckout', 'quickcheckout_highlight_error', '1', 0),
(949, 0, 'quickcheckout', 'quickcheckout_edit_cart', '1', 0),
(948, 0, 'quickcheckout', 'quickcheckout_save_data', '1', 0),
(947, 0, 'quickcheckout', 'quickcheckout_confirmation_page', '0', 0),
(946, 0, 'quickcheckout', 'quickcheckout_debug', '0', 0),
(945, 0, 'quickcheckout', 'quickcheckout_minimum_order', '0', 0),
(944, 0, 'quickcheckout', 'quickcheckout_status', '1', 0),
(985, 0, 'quickcheckout', 'quickcheckout_field_comment', '{\"default\":{\"2\":\"\"},\"placeholder\":{\"2\":\"\"}}', 1),
(986, 0, 'quickcheckout', 'quickcheckout_coupon', '0', 0),
(987, 0, 'quickcheckout', 'quickcheckout_voucher', '0', 0),
(988, 0, 'quickcheckout', 'quickcheckout_reward', '0', 0),
(989, 0, 'quickcheckout', 'quickcheckout_html_header', '{\"2\":\"\"}', 1),
(990, 0, 'quickcheckout', 'quickcheckout_html_footer', '{\"2\":\"\"}', 1),
(991, 0, 'quickcheckout', 'quickcheckout_payment_module', '1', 0),
(992, 0, 'quickcheckout', 'quickcheckout_payment_reload', '0', 0),
(993, 0, 'quickcheckout', 'quickcheckout_payment', '1', 0),
(994, 0, 'quickcheckout', 'quickcheckout_payment_default', 'cod', 0),
(995, 0, 'quickcheckout', 'quickcheckout_shipping_reload', '0', 0),
(996, 0, 'quickcheckout', 'quickcheckout_payment_logo', '{\"cod\":\"\",\"free_checkout\":\"\"}', 1),
(997, 0, 'quickcheckout', 'quickcheckout_shipping_module', '1', 0),
(998, 0, 'quickcheckout', 'quickcheckout_shipping_title_display', '0', 0),
(999, 0, 'quickcheckout', 'quickcheckout_shipping', '1', 0),
(1000, 0, 'quickcheckout', 'quickcheckout_shipping_default', 'flat', 0),
(1001, 0, 'quickcheckout', 'quickcheckout_shipping_logo', '{\"flat\":\"\"}', 1),
(1002, 0, 'quickcheckout', 'quickcheckout_survey', '0', 0),
(1003, 0, 'quickcheckout', 'quickcheckout_survey_required', '0', 0),
(1004, 0, 'quickcheckout', 'quickcheckout_survey_text', '{\"2\":\"\"}', 1),
(1005, 0, 'quickcheckout', 'quickcheckout_survey_type', '0', 0),
(1006, 0, 'quickcheckout', 'quickcheckout_delivery', '0', 0),
(1007, 0, 'quickcheckout', 'quickcheckout_delivery_time', '0', 0),
(1008, 0, 'quickcheckout', 'quickcheckout_delivery_required', '0', 0),
(1009, 0, 'quickcheckout', 'quickcheckout_delivery_unavailable', '&quot;2017-10-31&quot;, &quot;2017-08-11&quot;, &quot;2017-12-25&quot;', 0),
(1010, 0, 'quickcheckout', 'quickcheckout_delivery_min', '1', 0),
(1011, 0, 'quickcheckout', 'quickcheckout_delivery_max', '30', 0),
(1012, 0, 'quickcheckout', 'quickcheckout_delivery_min_hour', '09', 0),
(1013, 0, 'quickcheckout', 'quickcheckout_delivery_max_hour', '17', 0),
(1014, 0, 'quickcheckout', 'quickcheckout_delivery_days_of_week', '', 0),
(1939, 0, 'mlseo', 'mlseo_redirect_http', '6', 0),
(1938, 0, 'mlseo', 'mlseo_banners', '1', 0),
(1937, 0, 'mlseo', 'mlseo_redirect', '1', 0),
(1936, 0, 'mlseo', 'mlseo_friendly', '1', 0),
(1935, 0, 'mlseo', 'mlseo_url_absolute', '1', 0),
(1509, 0, 'config', 'config_error_log', '1', 0),
(1510, 0, 'config', 'config_error_filename', 'error.log', 0),
(2015, 0, 'mlseo', 'mlseo_information_full_desc_pattern', '[name]', 0),
(1934, 0, 'mlseo', 'mlseo_enabled', '1', 0),
(2180, 0, 'yandex_money', 'yandex_money_market_option_prefix_size_text', '', 0),
(2178, 0, 'yandex_money', 'yandex_money_market_option_prefix_color_text', '', 0),
(2177, 0, 'yandex_money', 'yandex_money_market_option_color_option_id', '2', 0),
(2176, 0, 'yandex_money', 'yandex_money_market_vat', '{\"9\":\"VAT_18\",\"10\":\"VAT_18\"}', 1),
(2175, 0, 'yandex_money', 'yandex_money_market_available_store', '{\"non-zero-quantity\":\"\",\"6\":\"\",\"7\":\"\",\"5\":\"\",\"8\":\"\"}', 1),
(2174, 0, 'yandex_money', 'yandex_money_market_available_pickup', '{\"non-zero-quantity\":\"\",\"6\":\"\",\"7\":\"\",\"5\":\"\",\"8\":\"\"}', 1),
(2173, 0, 'yandex_money', 'yandex_money_market_available_delivery', '{\"non-zero-quantity\":\"\",\"6\":\"\",\"7\":\"\",\"5\":\"\",\"8\":\"\"}', 1),
(2172, 0, 'yandex_money', 'yandex_money_market_available_available', '{\"non-zero-quantity\":\"none\",\"6\":\"none\",\"7\":\"none\",\"5\":\"none\",\"8\":\"none\"}', 1),
(2171, 0, 'yandex_money', 'yandex_money_market_name_template', '%model% %manufacturer% %name%', 0),
(2170, 0, 'yandex_money', 'yandex_money_market_simple', '', 0),
(2169, 0, 'yandex_money', 'yandex_money_market_delivery_order_before', '{\"1\":\"\",\"2\":\"\",\"3\":\"\",\"4\":\"\",\"5\":\"\"}', 1),
(2168, 0, 'yandex_money', 'yandex_money_market_delivery_days_to', '{\"1\":\"\",\"2\":\"\",\"3\":\"\",\"4\":\"\",\"5\":\"\"}', 1),
(2167, 0, 'yandex_money', 'yandex_money_market_delivery_days_from', '{\"1\":\"\",\"2\":\"\",\"3\":\"\",\"4\":\"\",\"5\":\"\"}', 1),
(2166, 0, 'yandex_money', 'yandex_money_market_delivery_cost', '{\"1\":\"\",\"2\":\"\",\"3\":\"\",\"4\":\"\",\"5\":\"\"}', 1),
(2165, 0, 'yandex_money', 'yandex_money_market_category_all', '', 0),
(2163, 0, 'yandex_money', 'yandex_money_market_currency_rate', '{\"RUB\":\"CBRF\"}', 1),
(2164, 0, 'yandex_money', 'yandex_money_market_currency_plus', '{\"RUB\":\"\"}', 1),
(2162, 0, 'yandex_money', 'yandex_money_market_full_shopname', 'Your Store', 0),
(2161, 0, 'yandex_money', 'yandex_money_market_shopname', 'Your Store', 0),
(2160, 0, 'yandex_money', 'yandex_money_market_active', '', 0),
(2159, 0, 'yandex_money', 'yandex_money_metrika_pw', '', 0),
(2157, 0, 'yandex_money', 'yandex_money_metrika_number', '', 0),
(2158, 0, 'yandex_money', 'yandex_money_metrika_idapp', '', 0),
(2155, 0, 'yandex_money', 'yandex_money_billing_sort_order', '0', 0),
(2156, 0, 'yandex_money', 'yandex_money_metrika_active', '', 0),
(2154, 0, 'yandex_money', 'yandex_money_billing_geo_zone', '0', 0),
(2153, 0, 'yandex_money', 'yandex_money_billing_minimum_payment_amount', '0', 0),
(2152, 0, 'yandex_money', 'yandex_money_billing_success_order_status', '7', 0),
(2151, 0, 'yandex_money', 'yandex_money_billing_display_name', 'Платежка (банковские карты, кошелек)', 0),
(2150, 0, 'yandex_money', 'yandex_money_billing_purpose', 'Номер заказа %order_id% Оплата через Платежку', 0),
(2149, 0, 'yandex_money', 'yandex_money_billing_form_id', '', 0),
(2148, 0, 'yandex_money', 'yandex_money_wallet_sort_order', '0', 0),
(2147, 0, 'yandex_money', 'yandex_money_wallet_geo_zone', '0', 0),
(2146, 0, 'yandex_money', 'yandex_money_wallet_minimum_payment_amount', '0', 0),
(2145, 0, 'yandex_money', 'yandex_money_wallet_success_order_status', '7', 0),
(2144, 0, 'yandex_money', 'yandex_money_wallet_display_name', 'Яндекс.Деньги (банковские карты, кошелек)', 0),
(2143, 0, 'yandex_money', 'yandex_money_wallet_password', '', 0),
(2142, 0, 'yandex_money', 'yandex_money_wallet_account_id', '', 0),
(2141, 0, 'yandex_money', 'yandex_money_kassa_sort_order', '0', 0),
(2139, 0, 'yandex_money', 'yandex_money_kassa_geo_zone', '0', 0),
(2140, 0, 'yandex_money', 'yandex_money_kassa_debug_log', '', 0),
(2138, 0, 'yandex_money', 'yandex_money_kassa_minimum_payment_amount', '0', 0),
(2136, 0, 'yandex_money', 'yandex_money_kassa_invoice_message', '', 0),
(2137, 0, 'yandex_money', 'yandex_money_kassa_success_order_status', '7', 0),
(2135, 0, 'yandex_money', 'yandex_money_kassa_invoice_subject', 'Оплата заказа %order_id%', 0),
(2134, 0, 'yandex_money', 'yandex_money_kassa_show_in_footer', '', 0),
(2133, 0, 'yandex_money', 'yandex_money_kassa_second_receipt_status', '7', 0),
(2132, 0, 'yandex_money', 'yandex_money_kassa_second_receipt_enable', '0', 0),
(2131, 0, 'yandex_money', 'yandex_money_kassa_payment_subject_default', 'commodity', 0),
(2130, 0, 'yandex_money', 'yandex_money_kassa_payment_mode_default', 'full_prepayment', 0),
(2129, 0, 'yandex_money', 'yandex_money_kassa_tax_rates', '{\"9\":1,\"10\":1}', 1),
(2128, 0, 'yandex_money', 'yandex_money_kassa_tax_rate_default', '1', 0),
(2127, 0, 'yandex_money', 'yandex_money_kassa_display_name', 'Яндекс.Касса (банковские карты, электронные деньги и другое)', 0),
(2126, 0, 'yandex_money', 'yandex_money_kassa_payment_description', '', 0),
(2125, 0, 'yandex_money', 'yandex_money_kassa_cancel_order_status', '7', 0),
(2124, 0, 'yandex_money', 'yandex_money_kassa_hold_order_status', '7', 0),
(2123, 0, 'yandex_money', 'yandex_money_kassa_b2b_tax_rates', '{\"9\":\"untaxed\",\"10\":\"untaxed\"}', 1),
(2122, 0, 'yandex_money', 'yandex_money_kassa_b2b_tax_rate_default', 'untaxed', 0),
(2121, 0, 'yandex_money', 'yandex_money_kassa_b2b_sberbank_payment_purpose', '', 0),
(2120, 0, 'yandex_money', 'yandex_money_kassa_currency', 'RUB', 0),
(2119, 0, 'yandex_money', 'yandex_money_kassa_payment_mode', 'kassa', 0),
(2118, 0, 'yandex_money', 'yandex_money_kassa_password', '', 0),
(2117, 0, 'yandex_money', 'yandex_money_kassa_shop_id', '', 0),
(2116, 0, 'yandex_money', 'yandex_money_nps_prev_vote_time', '', 0),
(2115, 0, 'yandex_money', 'yandex_money_metrika_o2auth', '', 0),
(2114, 0, 'yandex_money', 'yandex_money_metrika_code', '', 0),
(2113, 0, 'payment_yandex_money', 'payment_yandex_money_status', '', 0),
(2181, 0, 'yandex_money', 'yandex_money_kassa_use_yandex_button', '', 0),
(2182, 0, 'yandex_money', 'yandex_money_kassa_use_installments_button', '', 0),
(2183, 0, 'yandex_money', 'yandex_money_kassa_payment_method_widget', '', 0),
(2184, 0, 'yandex_money', 'yandex_money_kassa_payment_method_yandex_money', '', 0),
(2185, 0, 'yandex_money', 'yandex_money_kassa_payment_method_bank_card', '', 0),
(2186, 0, 'yandex_money', 'yandex_money_kassa_payment_method_sberbank', '', 0),
(2187, 0, 'yandex_money', 'yandex_money_kassa_payment_method_cash', '', 0),
(2188, 0, 'yandex_money', 'yandex_money_kassa_payment_method_qiwi', '', 0),
(2189, 0, 'yandex_money', 'yandex_money_kassa_payment_method_webmoney', '', 0),
(2190, 0, 'yandex_money', 'yandex_money_kassa_payment_method_alfabank', '', 0),
(2191, 0, 'yandex_money', 'yandex_money_kassa_payment_method_tinkoff_bank', '', 0),
(2192, 0, 'yandex_money', 'yandex_money_kassa_payment_method_installments', '', 0),
(2193, 0, 'yandex_money', 'yandex_money_kassa_invoice', '', 0),
(2194, 0, 'yandex_money', 'yandex_money_kassa_invoice_logo', '', 0),
(2195, 0, 'yandex_money', 'yandex_money_kassa_create_order_before_redirect', '', 0),
(2196, 0, 'yandex_money', 'yandex_money_kassa_clear_cart_before_redirect', '', 0),
(2197, 0, 'yandex_money', 'yandex_money_wallet_create_order_before_redirect', '', 0),
(2198, 0, 'yandex_money', 'yandex_money_wallet_clear_cart_before_redirect', '', 0),
(2199, 0, 'yandex_money', 'yandex_money_market_features', '', 0),
(2200, 0, 'yandex_money', 'yandex_money_market_dimensions', '', 0),
(2201, 0, 'yandex_money', 'yandex_money_market_category_list', '', 0),
(2202, 0, 'yandex_money', 'yandex_money_market_vat_enabled', '', 0),
(2203, 0, 'yandex_money', 'yandex_money_metrika_webvizor', '', 0),
(2204, 0, 'yandex_money', 'yandex_money_metrika_clickmap', '', 0),
(2205, 0, 'yandex_money', 'yandex_money_metrika_hash', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_shipping_courier`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_shipping_courier`;
CREATE TABLE `oc_shipping_courier` (
  `shipping_courier_id` int(11) NOT NULL,
  `shipping_courier_code` varchar(255) NOT NULL DEFAULT '',
  `shipping_courier_name` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_shipping_courier`
--

INSERT INTO `oc_shipping_courier` (`shipping_courier_id`, `shipping_courier_code`, `shipping_courier_name`) VALUES
(1, 'dhl', 'DHL'),
(2, 'fedex', 'Fedex'),
(3, 'ups', 'UPS'),
(4, 'royal-mail', 'Royal Mail'),
(5, 'usps', 'United States Postal Service'),
(6, 'auspost', 'Australia Post');

-- --------------------------------------------------------

--
-- Table structure for table `oc_statistics`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_statistics`;
CREATE TABLE `oc_statistics` (
  `statistics_id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `value` decimal(15,4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_statistics`
--

INSERT INTO `oc_statistics` (`statistics_id`, `code`, `value`) VALUES
(1, 'order_sale', '0.0000'),
(2, 'order_processing', '0.0000'),
(3, 'order_complete', '0.0000'),
(4, 'order_other', '0.0000'),
(5, 'returns', '0.0000'),
(6, 'product', '0.0000'),
(7, 'review', '0.0000');

-- --------------------------------------------------------

--
-- Table structure for table `oc_stock_status`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_stock_status`;
CREATE TABLE `oc_stock_status` (
  `stock_status_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_stock_status`
--

INSERT INTO `oc_stock_status` (`stock_status_id`, `language_id`, `name`) VALUES
(7, 1, 'In Stock'),
(8, 1, 'Pre-Order'),
(5, 1, 'Out Of Stock'),
(6, 1, '2-3 Days'),
(7, 2, 'In Stock'),
(8, 2, 'Pre-Order'),
(5, 2, 'Out Of Stock'),
(6, 2, '2-3 Days');

-- --------------------------------------------------------

--
-- Table structure for table `oc_store`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_store`;
CREATE TABLE `oc_store` (
  `store_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ssl` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_tax_class`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_tax_class`;
CREATE TABLE `oc_tax_class` (
  `tax_class_id` int(11) NOT NULL,
  `title` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_tax_class`
--

INSERT INTO `oc_tax_class` (`tax_class_id`, `title`, `description`, `date_added`, `date_modified`) VALUES
(9, 'Taxable Goods', 'Taxed goods', '2009-01-06 23:21:53', '2011-09-23 14:07:50'),
(10, 'Downloadable Products', 'Downloadable', '2011-09-21 22:19:39', '2011-09-22 10:27:36');

-- --------------------------------------------------------

--
-- Table structure for table `oc_tax_rate`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_tax_rate`;
CREATE TABLE `oc_tax_rate` (
  `tax_rate_id` int(11) NOT NULL,
  `geo_zone_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL,
  `rate` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `type` char(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_tax_rate`
--

INSERT INTO `oc_tax_rate` (`tax_rate_id`, `geo_zone_id`, `name`, `rate`, `type`, `date_added`, `date_modified`) VALUES
(86, 3, 'VAT (20%)', '20.0000', 'P', '2011-03-09 21:17:10', '2011-09-22 22:24:29'),
(87, 3, 'Eco Tax (-2.00)', '2.0000', 'F', '2011-09-21 21:49:23', '2011-09-23 00:40:19');

-- --------------------------------------------------------

--
-- Table structure for table `oc_tax_rate_to_customer_group`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_tax_rate_to_customer_group`;
CREATE TABLE `oc_tax_rate_to_customer_group` (
  `tax_rate_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_tax_rate_to_customer_group`
--

INSERT INTO `oc_tax_rate_to_customer_group` (`tax_rate_id`, `customer_group_id`) VALUES
(86, 1),
(87, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_tax_rule`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_tax_rule`;
CREATE TABLE `oc_tax_rule` (
  `tax_rule_id` int(11) NOT NULL,
  `tax_class_id` int(11) NOT NULL,
  `tax_rate_id` int(11) NOT NULL,
  `based` varchar(10) NOT NULL,
  `priority` int(5) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_tax_rule`
--

INSERT INTO `oc_tax_rule` (`tax_rule_id`, `tax_class_id`, `tax_rate_id`, `based`, `priority`) VALUES
(121, 10, 86, 'payment', 1),
(120, 10, 87, 'store', 0),
(128, 9, 86, 'shipping', 1),
(127, 9, 87, 'shipping', 2);

-- --------------------------------------------------------

--
-- Table structure for table `oc_theme`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_theme`;
CREATE TABLE `oc_theme` (
  `theme_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `theme` varchar(64) NOT NULL,
  `route` varchar(64) NOT NULL,
  `code` mediumtext NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_translation`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_translation`;
CREATE TABLE `oc_translation` (
  `translation_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `route` varchar(64) NOT NULL,
  `key` varchar(64) NOT NULL,
  `value` text NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_upload`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_upload`;
CREATE TABLE `oc_upload` (
  `upload_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_url_404`
--
-- Creation: Aug 02, 2020 at 10:54 AM
-- Last update: Aug 02, 2020 at 10:54 AM
--

DROP TABLE IF EXISTS `oc_url_404`;
CREATE TABLE `oc_url_404` (
  `url_404_id` int(11) NOT NULL,
  `query` varchar(1000) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  `date_accessed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_url_absolute`
--
-- Creation: Aug 02, 2020 at 10:54 AM
-- Last update: Aug 02, 2020 at 10:54 AM
--

DROP TABLE IF EXISTS `oc_url_absolute`;
CREATE TABLE `oc_url_absolute` (
  `url_absolute_id` int(11) NOT NULL,
  `query` varchar(1000) NOT NULL,
  `redirect` varchar(1000) NOT NULL,
  `language_id` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_url_redirect`
--
-- Creation: Aug 02, 2020 at 10:54 AM
-- Last update: Aug 02, 2020 at 11:56 AM
--

DROP TABLE IF EXISTS `oc_url_redirect`;
CREATE TABLE `oc_url_redirect` (
  `url_redirect_id` int(11) NOT NULL,
  `query` varchar(1000) NOT NULL,
  `redirect` varchar(1000) NOT NULL,
  `language_id` int(3) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_url_redirect`
--

INSERT INTO `oc_url_redirect` (`url_redirect_id`, `query`, `redirect`, `language_id`, `date_created`) VALUES
(1, 'http://opencart.mmvmolkov.beget.tech/htc-touch-hd', 'product/product&product_id=28', 2, '2020-08-02 11:56:59'),
(2, 'http://opencart.mmvmolkov.beget.tech/palm-treo-pro', 'product/product&product_id=29', 2, '2020-08-02 11:56:59'),
(3, 'http://opencart.mmvmolkov.beget.tech/canon-eos-5d', 'product/product&product_id=30', 2, '2020-08-02 11:56:59'),
(4, 'http://opencart.mmvmolkov.beget.tech/nikon-d300', 'product/product&product_id=31', 2, '2020-08-02 11:56:59'),
(5, 'http://opencart.mmvmolkov.beget.tech/ipod-touch', 'product/product&product_id=32', 2, '2020-08-02 11:56:59'),
(6, 'http://opencart.mmvmolkov.beget.tech/samsung-syncmaster-941bw', 'product/product&product_id=33', 2, '2020-08-02 11:56:59'),
(7, 'http://opencart.mmvmolkov.beget.tech/ipod-shuffle', 'product/product&product_id=34', 2, '2020-08-02 11:56:59'),
(8, 'http://opencart.mmvmolkov.beget.tech/product-8', 'product/product&product_id=35', 2, '2020-08-02 11:56:59'),
(9, 'http://opencart.mmvmolkov.beget.tech/ipod-nano', 'product/product&product_id=36', 2, '2020-08-02 11:56:59'),
(10, 'http://opencart.mmvmolkov.beget.tech/iphone', 'product/product&product_id=40', 2, '2020-08-02 11:56:59'),
(11, 'http://opencart.mmvmolkov.beget.tech/imac', 'product/product&product_id=41', 2, '2020-08-02 11:56:59'),
(12, 'http://opencart.mmvmolkov.beget.tech/apple-cinema-30', 'product/product&product_id=42', 2, '2020-08-02 11:56:59'),
(13, 'http://opencart.mmvmolkov.beget.tech/macbook', 'product/product&product_id=43', 2, '2020-08-02 11:56:59'),
(14, 'http://opencart.mmvmolkov.beget.tech/macbook-air', 'product/product&product_id=44', 2, '2020-08-02 11:56:59'),
(15, 'http://opencart.mmvmolkov.beget.tech/macbook-pro', 'product/product&product_id=45', 2, '2020-08-02 11:56:59'),
(16, 'http://opencart.mmvmolkov.beget.tech/sony-vaio', 'product/product&product_id=46', 2, '2020-08-02 11:56:59'),
(17, 'http://opencart.mmvmolkov.beget.tech/hp-lp3065', 'product/product&product_id=47', 2, '2020-08-02 11:56:59'),
(18, 'http://opencart.mmvmolkov.beget.tech/ipod-classic', 'product/product&product_id=48', 2, '2020-08-02 11:56:59'),
(19, 'http://opencart.mmvmolkov.beget.tech/samsung-galaxy-tab-10.1', 'product/product&product_id=49', 2, '2020-08-02 11:56:59');

-- --------------------------------------------------------

--
-- Table structure for table `oc_user`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:19 AM
--

DROP TABLE IF EXISTS `oc_user`;
CREATE TABLE `oc_user` (
  `user_id` int(11) NOT NULL,
  `user_group_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(9) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `image` varchar(255) NOT NULL,
  `code` varchar(40) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_user`
--

INSERT INTO `oc_user` (`user_id`, `user_group_id`, `username`, `password`, `salt`, `firstname`, `lastname`, `email`, `image`, `code`, `ip`, `status`, `date_added`) VALUES
(1, 1, 'admin', '5dd486070bd3db92432ce4aa2c07bea64f42172f', 'qL0ew6XZ8', 'John', 'Doe', 'm.molkov@wbooster.ru', '', '', '128.68.177.21', 1, '2020-08-02 09:18:25');

-- --------------------------------------------------------

--
-- Table structure for table `oc_user_group`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 05:24 PM
--

DROP TABLE IF EXISTS `oc_user_group`;
CREATE TABLE `oc_user_group` (
  `user_group_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `permission` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_user_group`
--

INSERT INTO `oc_user_group` (`user_group_id`, `name`, `permission`) VALUES
(1, 'Administrator', '{\"access\":[\"catalog\\/attribute\",\"catalog\\/attribute_group\",\"catalog\\/category\",\"catalog\\/download\",\"catalog\\/filter\",\"catalog\\/information\",\"catalog\\/manufacturer\",\"catalog\\/option\",\"catalog\\/product\",\"catalog\\/recurring\",\"catalog\\/review\",\"common\\/column_left\",\"common\\/developer\",\"common\\/filemanager\",\"common\\/profile\",\"common\\/security\",\"customer\\/custom_field\",\"customer\\/customer\",\"customer\\/customer_approval\",\"customer\\/customer_group\",\"design\\/banner\",\"design\\/layout\",\"design\\/seo_url\",\"design\\/theme\",\"design\\/translation\",\"event\\/language\",\"event\\/statistics\",\"event\\/theme\",\"extension\\/advertise\\/google\",\"extension\\/analytics\\/google\",\"extension\\/captcha\\/basic\",\"extension\\/captcha\\/google\",\"extension\\/dashboard\\/activity\",\"extension\\/dashboard\\/chart\",\"extension\\/dashboard\\/customer\",\"extension\\/dashboard\\/map\",\"extension\\/dashboard\\/online\",\"extension\\/dashboard\\/order\",\"extension\\/dashboard\\/recent\",\"extension\\/dashboard\\/sale\",\"extension\\/export_import\",\"extension\\/extension\\/advertise\",\"extension\\/extension\\/analytics\",\"extension\\/extension\\/captcha\",\"extension\\/extension\\/dashboard\",\"extension\\/extension\\/feed\",\"extension\\/extension\\/fraud\",\"extension\\/extension\\/menu\",\"extension\\/extension\\/module\",\"extension\\/extension\\/payment\",\"extension\\/extension\\/promotion\",\"extension\\/extension\\/report\",\"extension\\/extension\\/shipping\",\"extension\\/extension\\/theme\",\"extension\\/extension\\/total\",\"extension\\/feed\\/google_base\",\"extension\\/feed\\/google_sitemap\",\"extension\\/feed\\/openbaypro\",\"extension\\/fraud\\/fraudlabspro\",\"extension\\/fraud\\/ip\",\"extension\\/fraud\\/maxmind\",\"extension\\/module\\/account\",\"extension\\/module\\/amazon_login\",\"extension\\/module\\/amazon_pay\",\"extension\\/module\\/banner\",\"extension\\/module\\/bestseller\",\"extension\\/module\\/carousel\",\"extension\\/module\\/category\",\"extension\\/module\\/divido_calculator\",\"extension\\/module\\/ebay_listing\",\"extension\\/module\\/featured\",\"extension\\/module\\/filter\",\"extension\\/module\\/google_hangouts\",\"extension\\/module\\/html\",\"extension\\/module\\/information\",\"extension\\/module\\/klarna_checkout_module\",\"extension\\/module\\/latest\",\"extension\\/module\\/laybuy_layout\",\"extension\\/module\\/ocfilter\",\"extension\\/module\\/pilibaba_button\",\"extension\\/module\\/pp_braintree_button\",\"extension\\/module\\/pp_button\",\"extension\\/module\\/pp_login\",\"extension\\/module\\/quickcheckout\",\"extension\\/module\\/sagepay_direct_cards\",\"extension\\/module\\/sagepay_server_cards\",\"extension\\/module\\/sainent_extensions\",\"extension\\/module\\/slideshow\",\"extension\\/module\\/special\",\"extension\\/module\\/store\",\"extension\\/openbay\\/amazon\",\"extension\\/openbay\\/amazon_listing\",\"extension\\/openbay\\/amazon_product\",\"extension\\/openbay\\/amazonus\",\"extension\\/openbay\\/amazonus_listing\",\"extension\\/openbay\\/amazonus_product\",\"extension\\/openbay\\/ebay\",\"extension\\/openbay\\/ebay_profile\",\"extension\\/openbay\\/ebay_template\",\"extension\\/openbay\\/etsy\",\"extension\\/openbay\\/etsy_product\",\"extension\\/openbay\\/etsy_shipping\",\"extension\\/openbay\\/etsy_shop\",\"extension\\/openbay\\/fba\",\"extension\\/payment\\/alipay\",\"extension\\/payment\\/alipay_cross\",\"extension\\/payment\\/amazon_login_pay\",\"extension\\/payment\\/authorizenet_aim\",\"extension\\/payment\\/authorizenet_sim\",\"extension\\/payment\\/bank_transfer\",\"extension\\/payment\\/bluepay_hosted\",\"extension\\/payment\\/bluepay_redirect\",\"extension\\/payment\\/cardconnect\",\"extension\\/payment\\/cardinity\",\"extension\\/payment\\/cheque\",\"extension\\/payment\\/cod\",\"extension\\/payment\\/divido\",\"extension\\/payment\\/eway\",\"extension\\/payment\\/firstdata\",\"extension\\/payment\\/firstdata_remote\",\"extension\\/payment\\/free_checkout\",\"extension\\/payment\\/g2apay\",\"extension\\/payment\\/globalpay\",\"extension\\/payment\\/globalpay_remote\",\"extension\\/payment\\/klarna_account\",\"extension\\/payment\\/klarna_checkout\",\"extension\\/payment\\/klarna_invoice\",\"extension\\/payment\\/laybuy\",\"extension\\/payment\\/liqpay\",\"extension\\/payment\\/nochex\",\"extension\\/payment\\/paymate\",\"extension\\/payment\\/paypoint\",\"extension\\/payment\\/payza\",\"extension\\/payment\\/perpetual_payments\",\"extension\\/payment\\/pilibaba\",\"extension\\/payment\\/pp_braintree\",\"extension\\/payment\\/pp_express\",\"extension\\/payment\\/pp_payflow\",\"extension\\/payment\\/pp_payflow_iframe\",\"extension\\/payment\\/pp_pro\",\"extension\\/payment\\/pp_pro_iframe\",\"extension\\/payment\\/pp_standard\",\"extension\\/payment\\/realex\",\"extension\\/payment\\/realex_remote\",\"extension\\/payment\\/sagepay_direct\",\"extension\\/payment\\/sagepay_server\",\"extension\\/payment\\/sagepay_us\",\"extension\\/payment\\/securetrading_pp\",\"extension\\/payment\\/securetrading_ws\",\"extension\\/payment\\/skrill\",\"extension\\/payment\\/squareup\",\"extension\\/payment\\/twocheckout\",\"extension\\/payment\\/web_payment_software\",\"extension\\/payment\\/wechat_pay\",\"extension\\/payment\\/worldpay\",\"extension\\/report\\/customer_activity\",\"extension\\/report\\/customer_order\",\"extension\\/report\\/customer_reward\",\"extension\\/report\\/customer_search\",\"extension\\/report\\/customer_transaction\",\"extension\\/report\\/marketing\",\"extension\\/report\\/product_purchased\",\"extension\\/report\\/product_viewed\",\"extension\\/report\\/sale_coupon\",\"extension\\/report\\/sale_order\",\"extension\\/report\\/sale_return\",\"extension\\/report\\/sale_shipping\",\"extension\\/report\\/sale_tax\",\"extension\\/shipping\\/auspost\",\"extension\\/shipping\\/ec_ship\",\"extension\\/shipping\\/fedex\",\"extension\\/shipping\\/flat\",\"extension\\/shipping\\/free\",\"extension\\/shipping\\/item\",\"extension\\/shipping\\/parcelforce_48\",\"extension\\/shipping\\/pickup\",\"extension\\/shipping\\/royal_mail\",\"extension\\/shipping\\/ups\",\"extension\\/shipping\\/usps\",\"extension\\/shipping\\/weight\",\"extension\\/theme\\/default\",\"extension\\/total\\/coupon\",\"extension\\/total\\/credit\",\"extension\\/total\\/handling\",\"extension\\/total\\/klarna_fee\",\"extension\\/total\\/low_order_fee\",\"extension\\/total\\/reward\",\"extension\\/total\\/shipping\",\"extension\\/total\\/sub_total\",\"extension\\/total\\/tax\",\"extension\\/total\\/total\",\"extension\\/total\\/voucher\",\"feed\\/advanced_sitemap\",\"localisation\\/country\",\"localisation\\/currency\",\"localisation\\/geo_zone\",\"localisation\\/language\",\"localisation\\/length_class\",\"localisation\\/location\",\"localisation\\/order_status\",\"localisation\\/return_action\",\"localisation\\/return_reason\",\"localisation\\/return_status\",\"localisation\\/stock_status\",\"localisation\\/tax_class\",\"localisation\\/tax_rate\",\"localisation\\/weight_class\",\"localisation\\/zone\",\"mail\\/affiliate\",\"mail\\/customer\",\"mail\\/forgotten\",\"mail\\/return\",\"mail\\/reward\",\"mail\\/transaction\",\"marketing\\/contact\",\"marketing\\/coupon\",\"marketing\\/marketing\",\"marketplace\\/api\",\"marketplace\\/event\",\"marketplace\\/extension\",\"marketplace\\/install\",\"marketplace\\/installer\",\"marketplace\\/marketplace\",\"marketplace\\/modification\",\"marketplace\\/openbay\",\"module\\/complete_seo\",\"report\\/online\",\"report\\/report\",\"report\\/statistics\",\"sale\\/order\",\"sale\\/recurring\",\"sale\\/return\",\"sale\\/voucher\",\"sale\\/voucher_theme\",\"setting\\/setting\",\"setting\\/store\",\"startup\\/error\",\"startup\\/event\",\"startup\\/login\",\"startup\\/permission\",\"startup\\/router\",\"startup\\/sass\",\"startup\\/startup\",\"tool\\/backup\",\"tool\\/log\",\"tool\\/upload\",\"user\\/api\",\"user\\/user\",\"user\\/user_permission\",\"extension\\/payment\\/yandex_money\"],\"modify\":[\"catalog\\/attribute\",\"catalog\\/attribute_group\",\"catalog\\/category\",\"catalog\\/download\",\"catalog\\/filter\",\"catalog\\/information\",\"catalog\\/manufacturer\",\"catalog\\/option\",\"catalog\\/product\",\"catalog\\/recurring\",\"catalog\\/review\",\"common\\/column_left\",\"common\\/developer\",\"common\\/filemanager\",\"common\\/profile\",\"common\\/security\",\"customer\\/custom_field\",\"customer\\/customer\",\"customer\\/customer_approval\",\"customer\\/customer_group\",\"design\\/banner\",\"design\\/layout\",\"design\\/seo_url\",\"design\\/theme\",\"design\\/translation\",\"event\\/language\",\"event\\/statistics\",\"event\\/theme\",\"extension\\/advertise\\/google\",\"extension\\/analytics\\/google\",\"extension\\/captcha\\/basic\",\"extension\\/captcha\\/google\",\"extension\\/dashboard\\/activity\",\"extension\\/dashboard\\/chart\",\"extension\\/dashboard\\/customer\",\"extension\\/dashboard\\/map\",\"extension\\/dashboard\\/online\",\"extension\\/dashboard\\/order\",\"extension\\/dashboard\\/recent\",\"extension\\/dashboard\\/sale\",\"extension\\/export_import\",\"extension\\/extension\\/advertise\",\"extension\\/extension\\/analytics\",\"extension\\/extension\\/captcha\",\"extension\\/extension\\/dashboard\",\"extension\\/extension\\/feed\",\"extension\\/extension\\/fraud\",\"extension\\/extension\\/menu\",\"extension\\/extension\\/module\",\"extension\\/extension\\/payment\",\"extension\\/extension\\/promotion\",\"extension\\/extension\\/report\",\"extension\\/extension\\/shipping\",\"extension\\/extension\\/theme\",\"extension\\/extension\\/total\",\"extension\\/feed\\/google_base\",\"extension\\/feed\\/google_sitemap\",\"extension\\/feed\\/openbaypro\",\"extension\\/fraud\\/fraudlabspro\",\"extension\\/fraud\\/ip\",\"extension\\/fraud\\/maxmind\",\"extension\\/module\\/account\",\"extension\\/module\\/amazon_login\",\"extension\\/module\\/amazon_pay\",\"extension\\/module\\/banner\",\"extension\\/module\\/bestseller\",\"extension\\/module\\/carousel\",\"extension\\/module\\/category\",\"extension\\/module\\/divido_calculator\",\"extension\\/module\\/ebay_listing\",\"extension\\/module\\/featured\",\"extension\\/module\\/filter\",\"extension\\/module\\/google_hangouts\",\"extension\\/module\\/html\",\"extension\\/module\\/information\",\"extension\\/module\\/klarna_checkout_module\",\"extension\\/module\\/latest\",\"extension\\/module\\/laybuy_layout\",\"extension\\/module\\/ocfilter\",\"extension\\/module\\/pilibaba_button\",\"extension\\/module\\/pp_braintree_button\",\"extension\\/module\\/pp_button\",\"extension\\/module\\/pp_login\",\"extension\\/module\\/quickcheckout\",\"extension\\/module\\/sagepay_direct_cards\",\"extension\\/module\\/sagepay_server_cards\",\"extension\\/module\\/sainent_extensions\",\"extension\\/module\\/slideshow\",\"extension\\/module\\/special\",\"extension\\/module\\/store\",\"extension\\/openbay\\/amazon\",\"extension\\/openbay\\/amazon_listing\",\"extension\\/openbay\\/amazon_product\",\"extension\\/openbay\\/amazonus\",\"extension\\/openbay\\/amazonus_listing\",\"extension\\/openbay\\/amazonus_product\",\"extension\\/openbay\\/ebay\",\"extension\\/openbay\\/ebay_profile\",\"extension\\/openbay\\/ebay_template\",\"extension\\/openbay\\/etsy\",\"extension\\/openbay\\/etsy_product\",\"extension\\/openbay\\/etsy_shipping\",\"extension\\/openbay\\/etsy_shop\",\"extension\\/openbay\\/fba\",\"extension\\/payment\\/alipay\",\"extension\\/payment\\/alipay_cross\",\"extension\\/payment\\/amazon_login_pay\",\"extension\\/payment\\/authorizenet_aim\",\"extension\\/payment\\/authorizenet_sim\",\"extension\\/payment\\/bank_transfer\",\"extension\\/payment\\/bluepay_hosted\",\"extension\\/payment\\/bluepay_redirect\",\"extension\\/payment\\/cardconnect\",\"extension\\/payment\\/cardinity\",\"extension\\/payment\\/cheque\",\"extension\\/payment\\/cod\",\"extension\\/payment\\/divido\",\"extension\\/payment\\/eway\",\"extension\\/payment\\/firstdata\",\"extension\\/payment\\/firstdata_remote\",\"extension\\/payment\\/free_checkout\",\"extension\\/payment\\/g2apay\",\"extension\\/payment\\/globalpay\",\"extension\\/payment\\/globalpay_remote\",\"extension\\/payment\\/klarna_account\",\"extension\\/payment\\/klarna_checkout\",\"extension\\/payment\\/klarna_invoice\",\"extension\\/payment\\/laybuy\",\"extension\\/payment\\/liqpay\",\"extension\\/payment\\/nochex\",\"extension\\/payment\\/paymate\",\"extension\\/payment\\/paypoint\",\"extension\\/payment\\/payza\",\"extension\\/payment\\/perpetual_payments\",\"extension\\/payment\\/pilibaba\",\"extension\\/payment\\/pp_braintree\",\"extension\\/payment\\/pp_express\",\"extension\\/payment\\/pp_payflow\",\"extension\\/payment\\/pp_payflow_iframe\",\"extension\\/payment\\/pp_pro\",\"extension\\/payment\\/pp_pro_iframe\",\"extension\\/payment\\/pp_standard\",\"extension\\/payment\\/realex\",\"extension\\/payment\\/realex_remote\",\"extension\\/payment\\/sagepay_direct\",\"extension\\/payment\\/sagepay_server\",\"extension\\/payment\\/sagepay_us\",\"extension\\/payment\\/securetrading_pp\",\"extension\\/payment\\/securetrading_ws\",\"extension\\/payment\\/skrill\",\"extension\\/payment\\/squareup\",\"extension\\/payment\\/twocheckout\",\"extension\\/payment\\/web_payment_software\",\"extension\\/payment\\/wechat_pay\",\"extension\\/payment\\/worldpay\",\"extension\\/report\\/customer_activity\",\"extension\\/report\\/customer_order\",\"extension\\/report\\/customer_reward\",\"extension\\/report\\/customer_search\",\"extension\\/report\\/customer_transaction\",\"extension\\/report\\/marketing\",\"extension\\/report\\/product_purchased\",\"extension\\/report\\/product_viewed\",\"extension\\/report\\/sale_coupon\",\"extension\\/report\\/sale_order\",\"extension\\/report\\/sale_return\",\"extension\\/report\\/sale_shipping\",\"extension\\/report\\/sale_tax\",\"extension\\/shipping\\/auspost\",\"extension\\/shipping\\/ec_ship\",\"extension\\/shipping\\/fedex\",\"extension\\/shipping\\/flat\",\"extension\\/shipping\\/free\",\"extension\\/shipping\\/item\",\"extension\\/shipping\\/parcelforce_48\",\"extension\\/shipping\\/pickup\",\"extension\\/shipping\\/royal_mail\",\"extension\\/shipping\\/ups\",\"extension\\/shipping\\/usps\",\"extension\\/shipping\\/weight\",\"extension\\/theme\\/default\",\"extension\\/total\\/coupon\",\"extension\\/total\\/credit\",\"extension\\/total\\/handling\",\"extension\\/total\\/klarna_fee\",\"extension\\/total\\/low_order_fee\",\"extension\\/total\\/reward\",\"extension\\/total\\/shipping\",\"extension\\/total\\/sub_total\",\"extension\\/total\\/tax\",\"extension\\/total\\/total\",\"extension\\/total\\/voucher\",\"feed\\/advanced_sitemap\",\"localisation\\/country\",\"localisation\\/currency\",\"localisation\\/geo_zone\",\"localisation\\/language\",\"localisation\\/length_class\",\"localisation\\/location\",\"localisation\\/order_status\",\"localisation\\/return_action\",\"localisation\\/return_reason\",\"localisation\\/return_status\",\"localisation\\/stock_status\",\"localisation\\/tax_class\",\"localisation\\/tax_rate\",\"localisation\\/weight_class\",\"localisation\\/zone\",\"mail\\/affiliate\",\"mail\\/customer\",\"mail\\/forgotten\",\"mail\\/return\",\"mail\\/reward\",\"mail\\/transaction\",\"marketing\\/contact\",\"marketing\\/coupon\",\"marketing\\/marketing\",\"marketplace\\/api\",\"marketplace\\/event\",\"marketplace\\/extension\",\"marketplace\\/install\",\"marketplace\\/installer\",\"marketplace\\/marketplace\",\"marketplace\\/modification\",\"marketplace\\/openbay\",\"module\\/complete_seo\",\"report\\/online\",\"report\\/report\",\"report\\/statistics\",\"sale\\/order\",\"sale\\/recurring\",\"sale\\/return\",\"sale\\/voucher\",\"sale\\/voucher_theme\",\"setting\\/setting\",\"setting\\/store\",\"startup\\/error\",\"startup\\/event\",\"startup\\/login\",\"startup\\/permission\",\"startup\\/router\",\"startup\\/sass\",\"startup\\/startup\",\"tool\\/backup\",\"tool\\/log\",\"tool\\/upload\",\"user\\/api\",\"user\\/user\",\"user\\/user_permission\",\"extension\\/payment\\/yandex_money\"]}'),
(10, 'Demonstration', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_voucher`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_voucher`;
CREATE TABLE `oc_voucher` (
  `voucher_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `from_name` varchar(64) NOT NULL,
  `from_email` varchar(96) NOT NULL,
  `to_name` varchar(64) NOT NULL,
  `to_email` varchar(96) NOT NULL,
  `voucher_theme_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_voucher_history`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_voucher_history`;
CREATE TABLE `oc_voucher_history` (
  `voucher_history_id` int(11) NOT NULL,
  `voucher_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_voucher_theme`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_voucher_theme`;
CREATE TABLE `oc_voucher_theme` (
  `voucher_theme_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_voucher_theme`
--

INSERT INTO `oc_voucher_theme` (`voucher_theme_id`, `image`) VALUES
(8, 'catalog/demo/canon_eos_5d_2.jpg'),
(7, 'catalog/demo/gift-voucher-birthday.jpg'),
(6, 'catalog/demo/apple_logo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `oc_voucher_theme_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:23 AM
--

DROP TABLE IF EXISTS `oc_voucher_theme_description`;
CREATE TABLE `oc_voucher_theme_description` (
  `voucher_theme_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_voucher_theme_description`
--

INSERT INTO `oc_voucher_theme_description` (`voucher_theme_id`, `language_id`, `name`) VALUES
(6, 1, 'Christmas'),
(7, 1, 'Birthday'),
(8, 1, 'General'),
(6, 2, 'Christmas'),
(7, 2, 'Birthday'),
(8, 2, 'General');

-- --------------------------------------------------------

--
-- Table structure for table `oc_weight_class`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:28 AM
--

DROP TABLE IF EXISTS `oc_weight_class`;
CREATE TABLE `oc_weight_class` (
  `weight_class_id` int(11) NOT NULL,
  `value` decimal(15,8) NOT NULL DEFAULT '0.00000000'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_weight_class`
--

INSERT INTO `oc_weight_class` (`weight_class_id`, `value`) VALUES
(1, '1.00000000'),
(2, '1000.00000000');

-- --------------------------------------------------------

--
-- Table structure for table `oc_weight_class_description`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:28 AM
--

DROP TABLE IF EXISTS `oc_weight_class_description`;
CREATE TABLE `oc_weight_class_description` (
  `weight_class_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(32) NOT NULL,
  `unit` varchar(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_weight_class_description`
--

INSERT INTO `oc_weight_class_description` (`weight_class_id`, `language_id`, `title`, `unit`) VALUES
(1, 2, 'Килограмм', 'кг'),
(2, 2, 'Граммы', 'г');

-- --------------------------------------------------------

--
-- Table structure for table `oc_ya_money_payment`
--
-- Creation: Aug 02, 2020 at 05:24 PM
--

DROP TABLE IF EXISTS `oc_ya_money_payment`;
CREATE TABLE `oc_ya_money_payment` (
  `order_id` int(11) NOT NULL,
  `payment_id` char(36) NOT NULL,
  `status` enum('pending','waiting_for_capture','succeeded','canceled') NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `currency` char(3) NOT NULL,
  `payment_method_id` char(36) NOT NULL,
  `paid` enum('Y','N') NOT NULL,
  `created_at` datetime NOT NULL,
  `captured_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `receipt` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ya_money_product_properties`
--
-- Creation: Aug 02, 2020 at 05:24 PM
--

DROP TABLE IF EXISTS `oc_ya_money_product_properties`;
CREATE TABLE `oc_ya_money_product_properties` (
  `product_id` int(11) NOT NULL,
  `payment_subject` varchar(256) DEFAULT NULL,
  `payment_mode` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_ya_money_refunds`
--
-- Creation: Aug 02, 2020 at 05:24 PM
--

DROP TABLE IF EXISTS `oc_ya_money_refunds`;
CREATE TABLE `oc_ya_money_refunds` (
  `refund_id` char(36) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_id` char(36) NOT NULL,
  `status` enum('pending','succeeded','canceled') NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `currency` char(3) NOT NULL,
  `created_at` datetime NOT NULL,
  `authorized_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_zone`
--
-- Creation: Aug 02, 2020 at 10:40 AM
-- Last update: Aug 02, 2020 at 10:40 AM
--

DROP TABLE IF EXISTS `oc_zone`;
CREATE TABLE `oc_zone` (
  `zone_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `code` varchar(32) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_zone`
--

INSERT INTO `oc_zone` (`zone_id`, `country_id`, `name`, `code`, `status`) VALUES
(2721, 176, 'Республика Хакасия', 'KK', 1),
(2722, 176, 'Московская область', 'MOS', 1),
(2723, 176, 'Чукотский АО', 'CHU', 1),
(2724, 176, 'Архангельская область', 'ARK', 1),
(2725, 176, 'Астраханская область', 'AST', 1),
(2726, 176, 'Алтайский край', 'ALT', 1),
(2727, 176, 'Белгородская область', 'BEL', 1),
(2728, 176, 'Еврейская АО', 'YEV', 1),
(2729, 176, 'Амурская область', 'AMU', 1),
(2730, 176, 'Брянская область', 'BRY', 1),
(2731, 176, 'Чувашская Республика', 'CU', 1),
(2732, 176, 'Челябинская область', 'CHE', 1),
(2733, 176, 'Карачаево-Черкеcсия', 'KC', 1),
(2734, 176, 'Забайкальский край', 'ZAB', 1),
(2735, 176, 'Ленинградская область', 'LEN', 1),
(2736, 176, 'Республика Калмыкия', 'KL', 1),
(2737, 176, 'Сахалинская область', 'SAK', 1),
(2738, 176, 'Республика Алтай', 'AL', 1),
(2739, 176, 'Чеченская Республика', 'CE', 1),
(2740, 176, 'Иркутская область', 'IRK', 1),
(2741, 176, 'Ивановская область', 'IVA', 1),
(2742, 176, 'Удмуртская Республика', 'UD', 1),
(2743, 176, 'Калининградская область', 'KGD', 1),
(2744, 176, 'Калужская область', 'KLU', 1),
(2746, 176, 'Республика Татарстан', 'TA', 1),
(2747, 176, 'Кемеровская область', 'KEM', 1),
(2748, 176, 'Хабаровский край', 'KHA', 1),
(2749, 176, 'Ханты-Мансийский АО - Югра', 'KHM', 1),
(2750, 176, 'Костромская область', 'KOS', 1),
(2751, 176, 'Краснодарский край', 'KDA', 1),
(2752, 176, 'Красноярский край', 'KYA', 1),
(2754, 176, 'Курганская область', 'KGN', 1),
(2755, 176, 'Курская область', 'KRS', 1),
(2756, 176, 'Республика Тыва', 'TY', 1),
(2757, 176, 'Липецкая область', 'LIP', 1),
(2758, 176, 'Магаданская область', 'MAG', 1),
(2759, 176, 'Республика Дагестан', 'DA', 1),
(2760, 176, 'Республика Адыгея', 'AD', 1),
(2761, 176, 'Москва', 'MOW', 1),
(2762, 176, 'Мурманская область', 'MUR', 1),
(2763, 176, 'Республика Кабардино-Балкария', 'KB', 1),
(2764, 176, 'Ненецкий АО', 'NEN', 1),
(2765, 176, 'Республика Ингушетия', 'IN', 1),
(2766, 176, 'Нижегородская область', 'NIZ', 1),
(2767, 176, 'Новгородская область', 'NGR', 1),
(2768, 176, 'Новосибирская область', 'NVS', 1),
(2769, 176, 'Омская область', 'OMS', 1),
(2770, 176, 'Орловская область', 'ORL', 1),
(2771, 176, 'Оренбургская область', 'ORE', 1),
(2773, 176, 'Пензенская область', 'PNZ', 1),
(2774, 176, 'Пермский край', 'PER', 1),
(2775, 176, 'Камчатский край', 'KAM', 1),
(2776, 176, 'Республика Карелия', 'KR', 1),
(2777, 176, 'Псковская область', 'PSK', 1),
(2778, 176, 'Ростовская область', 'ROS', 1),
(2779, 176, 'Рязанская область', 'RYA', 1),
(2780, 176, 'Ямало-Ненецкий АО', 'YAN', 1),
(2781, 176, 'Самарская область', 'SAM', 1),
(2782, 176, 'Республика Мордовия', 'MO', 1),
(2783, 176, 'Саратовская область', 'SAR', 1),
(2784, 176, 'Смоленская область', 'SMO', 1),
(2785, 176, 'Санкт-Петербург', 'SPE', 1),
(2786, 176, 'Ставропольский край', 'STA', 1),
(2787, 176, 'Республика Коми', 'KO', 1),
(2788, 176, 'Тамбовская область', 'TAM', 1),
(2789, 176, 'Томская область', 'TOM', 1),
(2790, 176, 'Тульская область', 'TUL', 1),
(2792, 176, 'Тверская область', 'TVE', 1),
(2793, 176, 'Тюменская область', 'TYU', 1),
(2794, 176, 'Республика Башкортостан', 'BA', 1),
(2795, 176, 'Ульяновская область', 'ULY', 1),
(2796, 176, 'Республика Бурятия', 'BU', 1),
(2798, 176, 'Республика Северная Осетия', 'SE', 1),
(2799, 176, 'Владимирская область', 'VLA', 1),
(2800, 176, 'Приморский край', 'PRI', 1),
(2801, 176, 'Волгоградская область', 'VGG', 1),
(2802, 176, 'Вологодская область', 'VLG', 1),
(2803, 176, 'Воронежская область', 'VOR', 1),
(2804, 176, 'Кировская область', 'KIR', 1),
(2805, 176, 'Республика Саха', 'SA', 1),
(2806, 176, 'Ярославская область', 'YAR', 1),
(2807, 176, 'Свердловская область', 'SVE', 1),
(2808, 176, 'Республика Марий Эл', 'ME', 1),
(4231, 176, 'Республика Крым', 'KRM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_zone_to_geo_zone`
--
-- Creation: Aug 02, 2020 at 06:18 AM
-- Last update: Aug 02, 2020 at 06:18 AM
--

DROP TABLE IF EXISTS `oc_zone_to_geo_zone`;
CREATE TABLE `oc_zone_to_geo_zone` (
  `zone_to_geo_zone_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL DEFAULT '0',
  `geo_zone_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_zone_to_geo_zone`
--

INSERT INTO `oc_zone_to_geo_zone` (`zone_to_geo_zone_id`, `country_id`, `zone_id`, `geo_zone_id`, `date_added`, `date_modified`) VALUES
(1, 222, 0, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 222, 3513, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 222, 3514, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 222, 3515, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 222, 3516, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 222, 3517, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 222, 3518, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 222, 3519, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 222, 3520, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 222, 3521, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 222, 3522, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 222, 3523, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 222, 3524, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 222, 3525, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 222, 3526, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 222, 3527, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 222, 3528, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 222, 3529, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 222, 3530, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 222, 3531, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 222, 3532, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 222, 3533, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, 222, 3534, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, 222, 3535, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(25, 222, 3536, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 222, 3537, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, 222, 3538, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, 222, 3539, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(29, 222, 3540, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(30, 222, 3541, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(31, 222, 3542, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(32, 222, 3543, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, 222, 3544, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 222, 3545, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 222, 3546, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, 222, 3547, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 222, 3548, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, 222, 3549, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, 222, 3550, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, 222, 3551, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(41, 222, 3552, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(42, 222, 3553, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(43, 222, 3554, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(44, 222, 3555, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(45, 222, 3556, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(46, 222, 3557, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(47, 222, 3558, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(48, 222, 3559, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(49, 222, 3560, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(50, 222, 3561, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(51, 222, 3562, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(52, 222, 3563, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(53, 222, 3564, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(54, 222, 3565, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(55, 222, 3566, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(56, 222, 3567, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(57, 222, 3568, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(58, 222, 3569, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(59, 222, 3570, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(60, 222, 3571, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(61, 222, 3572, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(62, 222, 3573, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(63, 222, 3574, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(64, 222, 3575, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(65, 222, 3576, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(66, 222, 3577, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(67, 222, 3578, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(68, 222, 3579, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(69, 222, 3580, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(70, 222, 3581, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(71, 222, 3582, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(72, 222, 3583, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(73, 222, 3584, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(74, 222, 3585, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(75, 222, 3586, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(76, 222, 3587, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(77, 222, 3588, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(78, 222, 3589, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(79, 222, 3590, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(80, 222, 3591, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(81, 222, 3592, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(82, 222, 3593, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(83, 222, 3594, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(84, 222, 3595, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(85, 222, 3596, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(86, 222, 3597, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(87, 222, 3598, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(88, 222, 3599, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(89, 222, 3600, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(90, 222, 3601, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(91, 222, 3602, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(92, 222, 3603, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(93, 222, 3604, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(94, 222, 3605, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(95, 222, 3606, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(96, 222, 3607, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(97, 222, 3608, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(98, 222, 3609, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(99, 222, 3610, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(100, 222, 3611, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(101, 222, 3612, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(102, 222, 3949, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(103, 222, 3950, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(104, 222, 3951, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(105, 222, 3952, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(106, 222, 3953, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(107, 222, 3954, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(108, 222, 3955, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(109, 222, 3972, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `oc_address`
--
ALTER TABLE `oc_address`
  ADD PRIMARY KEY (`address_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `oc_advertise_google_target`
--
ALTER TABLE `oc_advertise_google_target`
  ADD PRIMARY KEY (`advertise_google_target_id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `oc_api`
--
ALTER TABLE `oc_api`
  ADD PRIMARY KEY (`api_id`);

--
-- Indexes for table `oc_api_ip`
--
ALTER TABLE `oc_api_ip`
  ADD PRIMARY KEY (`api_ip_id`);

--
-- Indexes for table `oc_api_session`
--
ALTER TABLE `oc_api_session`
  ADD PRIMARY KEY (`api_session_id`);

--
-- Indexes for table `oc_attribute`
--
ALTER TABLE `oc_attribute`
  ADD PRIMARY KEY (`attribute_id`);

--
-- Indexes for table `oc_attribute_description`
--
ALTER TABLE `oc_attribute_description`
  ADD PRIMARY KEY (`attribute_id`,`language_id`);

--
-- Indexes for table `oc_attribute_group`
--
ALTER TABLE `oc_attribute_group`
  ADD PRIMARY KEY (`attribute_group_id`);

--
-- Indexes for table `oc_attribute_group_description`
--
ALTER TABLE `oc_attribute_group_description`
  ADD PRIMARY KEY (`attribute_group_id`,`language_id`);

--
-- Indexes for table `oc_banner`
--
ALTER TABLE `oc_banner`
  ADD PRIMARY KEY (`banner_id`);

--
-- Indexes for table `oc_banner_image`
--
ALTER TABLE `oc_banner_image`
  ADD PRIMARY KEY (`banner_image_id`);

--
-- Indexes for table `oc_cart`
--
ALTER TABLE `oc_cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `cart_id` (`api_id`,`customer_id`,`session_id`,`product_id`,`recurring_id`);

--
-- Indexes for table `oc_category`
--
ALTER TABLE `oc_category`
  ADD PRIMARY KEY (`category_id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `oc_category_description`
--
ALTER TABLE `oc_category_description`
  ADD PRIMARY KEY (`category_id`,`language_id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `oc_category_filter`
--
ALTER TABLE `oc_category_filter`
  ADD PRIMARY KEY (`category_id`,`filter_id`);

--
-- Indexes for table `oc_category_path`
--
ALTER TABLE `oc_category_path`
  ADD PRIMARY KEY (`category_id`,`path_id`);

--
-- Indexes for table `oc_category_to_google_product_category`
--
ALTER TABLE `oc_category_to_google_product_category`
  ADD PRIMARY KEY (`google_product_category`,`store_id`),
  ADD KEY `category_id_store_id` (`category_id`,`store_id`);

--
-- Indexes for table `oc_category_to_layout`
--
ALTER TABLE `oc_category_to_layout`
  ADD PRIMARY KEY (`category_id`,`store_id`);

--
-- Indexes for table `oc_category_to_store`
--
ALTER TABLE `oc_category_to_store`
  ADD PRIMARY KEY (`category_id`,`store_id`);

--
-- Indexes for table `oc_country`
--
ALTER TABLE `oc_country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `oc_coupon`
--
ALTER TABLE `oc_coupon`
  ADD PRIMARY KEY (`coupon_id`);

--
-- Indexes for table `oc_coupon_category`
--
ALTER TABLE `oc_coupon_category`
  ADD PRIMARY KEY (`coupon_id`,`category_id`);

--
-- Indexes for table `oc_coupon_history`
--
ALTER TABLE `oc_coupon_history`
  ADD PRIMARY KEY (`coupon_history_id`);

--
-- Indexes for table `oc_coupon_product`
--
ALTER TABLE `oc_coupon_product`
  ADD PRIMARY KEY (`coupon_product_id`);

--
-- Indexes for table `oc_currency`
--
ALTER TABLE `oc_currency`
  ADD PRIMARY KEY (`currency_id`);

--
-- Indexes for table `oc_customer`
--
ALTER TABLE `oc_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `oc_customer_activity`
--
ALTER TABLE `oc_customer_activity`
  ADD PRIMARY KEY (`customer_activity_id`);

--
-- Indexes for table `oc_customer_affiliate`
--
ALTER TABLE `oc_customer_affiliate`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `oc_customer_approval`
--
ALTER TABLE `oc_customer_approval`
  ADD PRIMARY KEY (`customer_approval_id`);

--
-- Indexes for table `oc_customer_group`
--
ALTER TABLE `oc_customer_group`
  ADD PRIMARY KEY (`customer_group_id`);

--
-- Indexes for table `oc_customer_group_description`
--
ALTER TABLE `oc_customer_group_description`
  ADD PRIMARY KEY (`customer_group_id`,`language_id`);

--
-- Indexes for table `oc_customer_history`
--
ALTER TABLE `oc_customer_history`
  ADD PRIMARY KEY (`customer_history_id`);

--
-- Indexes for table `oc_customer_ip`
--
ALTER TABLE `oc_customer_ip`
  ADD PRIMARY KEY (`customer_ip_id`),
  ADD KEY `ip` (`ip`);

--
-- Indexes for table `oc_customer_login`
--
ALTER TABLE `oc_customer_login`
  ADD PRIMARY KEY (`customer_login_id`),
  ADD KEY `email` (`email`),
  ADD KEY `ip` (`ip`);

--
-- Indexes for table `oc_customer_online`
--
ALTER TABLE `oc_customer_online`
  ADD PRIMARY KEY (`ip`);

--
-- Indexes for table `oc_customer_reward`
--
ALTER TABLE `oc_customer_reward`
  ADD PRIMARY KEY (`customer_reward_id`);

--
-- Indexes for table `oc_customer_search`
--
ALTER TABLE `oc_customer_search`
  ADD PRIMARY KEY (`customer_search_id`);

--
-- Indexes for table `oc_customer_transaction`
--
ALTER TABLE `oc_customer_transaction`
  ADD PRIMARY KEY (`customer_transaction_id`);

--
-- Indexes for table `oc_customer_wishlist`
--
ALTER TABLE `oc_customer_wishlist`
  ADD PRIMARY KEY (`customer_id`,`product_id`);

--
-- Indexes for table `oc_custom_field`
--
ALTER TABLE `oc_custom_field`
  ADD PRIMARY KEY (`custom_field_id`);

--
-- Indexes for table `oc_custom_field_customer_group`
--
ALTER TABLE `oc_custom_field_customer_group`
  ADD PRIMARY KEY (`custom_field_id`,`customer_group_id`);

--
-- Indexes for table `oc_custom_field_description`
--
ALTER TABLE `oc_custom_field_description`
  ADD PRIMARY KEY (`custom_field_id`,`language_id`);

--
-- Indexes for table `oc_custom_field_value`
--
ALTER TABLE `oc_custom_field_value`
  ADD PRIMARY KEY (`custom_field_value_id`);

--
-- Indexes for table `oc_custom_field_value_description`
--
ALTER TABLE `oc_custom_field_value_description`
  ADD PRIMARY KEY (`custom_field_value_id`,`language_id`);

--
-- Indexes for table `oc_download`
--
ALTER TABLE `oc_download`
  ADD PRIMARY KEY (`download_id`);

--
-- Indexes for table `oc_download_description`
--
ALTER TABLE `oc_download_description`
  ADD PRIMARY KEY (`download_id`,`language_id`);

--
-- Indexes for table `oc_event`
--
ALTER TABLE `oc_event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `oc_extension`
--
ALTER TABLE `oc_extension`
  ADD PRIMARY KEY (`extension_id`);

--
-- Indexes for table `oc_extension_install`
--
ALTER TABLE `oc_extension_install`
  ADD PRIMARY KEY (`extension_install_id`);

--
-- Indexes for table `oc_extension_path`
--
ALTER TABLE `oc_extension_path`
  ADD PRIMARY KEY (`extension_path_id`);

--
-- Indexes for table `oc_filter`
--
ALTER TABLE `oc_filter`
  ADD PRIMARY KEY (`filter_id`);

--
-- Indexes for table `oc_filter_description`
--
ALTER TABLE `oc_filter_description`
  ADD PRIMARY KEY (`filter_id`,`language_id`);

--
-- Indexes for table `oc_filter_group`
--
ALTER TABLE `oc_filter_group`
  ADD PRIMARY KEY (`filter_group_id`);

--
-- Indexes for table `oc_filter_group_description`
--
ALTER TABLE `oc_filter_group_description`
  ADD PRIMARY KEY (`filter_group_id`,`language_id`);

--
-- Indexes for table `oc_geo_zone`
--
ALTER TABLE `oc_geo_zone`
  ADD PRIMARY KEY (`geo_zone_id`);

--
-- Indexes for table `oc_information`
--
ALTER TABLE `oc_information`
  ADD PRIMARY KEY (`information_id`);

--
-- Indexes for table `oc_information_description`
--
ALTER TABLE `oc_information_description`
  ADD PRIMARY KEY (`information_id`,`language_id`);

--
-- Indexes for table `oc_information_to_layout`
--
ALTER TABLE `oc_information_to_layout`
  ADD PRIMARY KEY (`information_id`,`store_id`);

--
-- Indexes for table `oc_information_to_store`
--
ALTER TABLE `oc_information_to_store`
  ADD PRIMARY KEY (`information_id`,`store_id`);

--
-- Indexes for table `oc_language`
--
ALTER TABLE `oc_language`
  ADD PRIMARY KEY (`language_id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `oc_layout`
--
ALTER TABLE `oc_layout`
  ADD PRIMARY KEY (`layout_id`);

--
-- Indexes for table `oc_layout_module`
--
ALTER TABLE `oc_layout_module`
  ADD PRIMARY KEY (`layout_module_id`);

--
-- Indexes for table `oc_layout_route`
--
ALTER TABLE `oc_layout_route`
  ADD PRIMARY KEY (`layout_route_id`);

--
-- Indexes for table `oc_length_class`
--
ALTER TABLE `oc_length_class`
  ADD PRIMARY KEY (`length_class_id`);

--
-- Indexes for table `oc_length_class_description`
--
ALTER TABLE `oc_length_class_description`
  ADD PRIMARY KEY (`length_class_id`,`language_id`);

--
-- Indexes for table `oc_location`
--
ALTER TABLE `oc_location`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `oc_manufacturer`
--
ALTER TABLE `oc_manufacturer`
  ADD PRIMARY KEY (`manufacturer_id`);

--
-- Indexes for table `oc_manufacturer_to_store`
--
ALTER TABLE `oc_manufacturer_to_store`
  ADD PRIMARY KEY (`manufacturer_id`,`store_id`);

--
-- Indexes for table `oc_marketing`
--
ALTER TABLE `oc_marketing`
  ADD PRIMARY KEY (`marketing_id`);

--
-- Indexes for table `oc_modification`
--
ALTER TABLE `oc_modification`
  ADD PRIMARY KEY (`modification_id`);

--
-- Indexes for table `oc_module`
--
ALTER TABLE `oc_module`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `oc_ocfilter_option`
--
ALTER TABLE `oc_ocfilter_option`
  ADD PRIMARY KEY (`option_id`),
  ADD KEY `keyword` (`keyword`),
  ADD KEY `sort_order` (`sort_order`);

--
-- Indexes for table `oc_ocfilter_option_description`
--
ALTER TABLE `oc_ocfilter_option_description`
  ADD PRIMARY KEY (`option_id`,`language_id`);

--
-- Indexes for table `oc_ocfilter_option_to_category`
--
ALTER TABLE `oc_ocfilter_option_to_category`
  ADD PRIMARY KEY (`category_id`,`option_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `oc_ocfilter_option_to_store`
--
ALTER TABLE `oc_ocfilter_option_to_store`
  ADD PRIMARY KEY (`store_id`,`option_id`);

--
-- Indexes for table `oc_ocfilter_option_value`
--
ALTER TABLE `oc_ocfilter_option_value`
  ADD PRIMARY KEY (`value_id`),
  ADD KEY `option_id` (`option_id`),
  ADD KEY `keyword` (`keyword`);

--
-- Indexes for table `oc_ocfilter_option_value_description`
--
ALTER TABLE `oc_ocfilter_option_value_description`
  ADD PRIMARY KEY (`value_id`,`language_id`),
  ADD KEY `option_id` (`option_id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `oc_ocfilter_option_value_to_product`
--
ALTER TABLE `oc_ocfilter_option_value_to_product`
  ADD PRIMARY KEY (`ocfilter_option_value_to_product_id`),
  ADD UNIQUE KEY `option_id_value_id_product_id` (`option_id`,`value_id`,`product_id`),
  ADD KEY `slide_value_min_slide_value_max` (`slide_value_min`,`slide_value_max`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `oc_ocfilter_option_value_to_product_description`
--
ALTER TABLE `oc_ocfilter_option_value_to_product_description`
  ADD PRIMARY KEY (`product_id`,`value_id`,`option_id`,`language_id`);

--
-- Indexes for table `oc_ocfilter_page`
--
ALTER TABLE `oc_ocfilter_page`
  ADD PRIMARY KEY (`ocfilter_page_id`),
  ADD KEY `keyword` (`keyword`),
  ADD KEY `category_id_params` (`category_id`,`params`);

--
-- Indexes for table `oc_ocfilter_page_description`
--
ALTER TABLE `oc_ocfilter_page_description`
  ADD PRIMARY KEY (`ocfilter_page_id`,`language_id`);

--
-- Indexes for table `oc_option`
--
ALTER TABLE `oc_option`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `oc_option_description`
--
ALTER TABLE `oc_option_description`
  ADD PRIMARY KEY (`option_id`,`language_id`);

--
-- Indexes for table `oc_option_value`
--
ALTER TABLE `oc_option_value`
  ADD PRIMARY KEY (`option_value_id`);

--
-- Indexes for table `oc_option_value_description`
--
ALTER TABLE `oc_option_value_description`
  ADD PRIMARY KEY (`option_value_id`,`language_id`);

--
-- Indexes for table `oc_order`
--
ALTER TABLE `oc_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `oc_order_history`
--
ALTER TABLE `oc_order_history`
  ADD PRIMARY KEY (`order_history_id`);

--
-- Indexes for table `oc_order_option`
--
ALTER TABLE `oc_order_option`
  ADD PRIMARY KEY (`order_option_id`);

--
-- Indexes for table `oc_order_product`
--
ALTER TABLE `oc_order_product`
  ADD PRIMARY KEY (`order_product_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `oc_order_recurring`
--
ALTER TABLE `oc_order_recurring`
  ADD PRIMARY KEY (`order_recurring_id`);

--
-- Indexes for table `oc_order_recurring_transaction`
--
ALTER TABLE `oc_order_recurring_transaction`
  ADD PRIMARY KEY (`order_recurring_transaction_id`);

--
-- Indexes for table `oc_order_shipment`
--
ALTER TABLE `oc_order_shipment`
  ADD PRIMARY KEY (`order_shipment_id`);

--
-- Indexes for table `oc_order_status`
--
ALTER TABLE `oc_order_status`
  ADD PRIMARY KEY (`order_status_id`,`language_id`);

--
-- Indexes for table `oc_order_total`
--
ALTER TABLE `oc_order_total`
  ADD PRIMARY KEY (`order_total_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `oc_order_voucher`
--
ALTER TABLE `oc_order_voucher`
  ADD PRIMARY KEY (`order_voucher_id`);

--
-- Indexes for table `oc_product`
--
ALTER TABLE `oc_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `oc_product_advertise_google`
--
ALTER TABLE `oc_product_advertise_google`
  ADD PRIMARY KEY (`product_advertise_google_id`),
  ADD UNIQUE KEY `product_id_store_id` (`product_id`,`store_id`);

--
-- Indexes for table `oc_product_advertise_google_status`
--
ALTER TABLE `oc_product_advertise_google_status`
  ADD PRIMARY KEY (`product_id`,`store_id`,`product_variation_id`);

--
-- Indexes for table `oc_product_advertise_google_target`
--
ALTER TABLE `oc_product_advertise_google_target`
  ADD PRIMARY KEY (`product_id`,`advertise_google_target_id`);

--
-- Indexes for table `oc_product_attribute`
--
ALTER TABLE `oc_product_attribute`
  ADD PRIMARY KEY (`product_id`,`attribute_id`,`language_id`);

--
-- Indexes for table `oc_product_description`
--
ALTER TABLE `oc_product_description`
  ADD PRIMARY KEY (`product_id`,`language_id`),
  ADD KEY `name` (`name`);
ALTER TABLE `oc_product_description` ADD FULLTEXT KEY `related_generator` (`name`,`description`);

--
-- Indexes for table `oc_product_discount`
--
ALTER TABLE `oc_product_discount`
  ADD PRIMARY KEY (`product_discount_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `oc_product_filter`
--
ALTER TABLE `oc_product_filter`
  ADD PRIMARY KEY (`product_id`,`filter_id`);

--
-- Indexes for table `oc_product_image`
--
ALTER TABLE `oc_product_image`
  ADD PRIMARY KEY (`product_image_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `oc_product_option`
--
ALTER TABLE `oc_product_option`
  ADD PRIMARY KEY (`product_option_id`);

--
-- Indexes for table `oc_product_option_value`
--
ALTER TABLE `oc_product_option_value`
  ADD PRIMARY KEY (`product_option_value_id`);

--
-- Indexes for table `oc_product_recurring`
--
ALTER TABLE `oc_product_recurring`
  ADD PRIMARY KEY (`product_id`,`recurring_id`,`customer_group_id`);

--
-- Indexes for table `oc_product_related`
--
ALTER TABLE `oc_product_related`
  ADD PRIMARY KEY (`product_id`,`related_id`);

--
-- Indexes for table `oc_product_reward`
--
ALTER TABLE `oc_product_reward`
  ADD PRIMARY KEY (`product_reward_id`);

--
-- Indexes for table `oc_product_special`
--
ALTER TABLE `oc_product_special`
  ADD PRIMARY KEY (`product_special_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `oc_product_to_category`
--
ALTER TABLE `oc_product_to_category`
  ADD PRIMARY KEY (`product_id`,`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `oc_product_to_download`
--
ALTER TABLE `oc_product_to_download`
  ADD PRIMARY KEY (`product_id`,`download_id`);

--
-- Indexes for table `oc_product_to_layout`
--
ALTER TABLE `oc_product_to_layout`
  ADD PRIMARY KEY (`product_id`,`store_id`);

--
-- Indexes for table `oc_product_to_store`
--
ALTER TABLE `oc_product_to_store`
  ADD PRIMARY KEY (`product_id`,`store_id`);

--
-- Indexes for table `oc_recurring`
--
ALTER TABLE `oc_recurring`
  ADD PRIMARY KEY (`recurring_id`);

--
-- Indexes for table `oc_recurring_description`
--
ALTER TABLE `oc_recurring_description`
  ADD PRIMARY KEY (`recurring_id`,`language_id`);

--
-- Indexes for table `oc_return`
--
ALTER TABLE `oc_return`
  ADD PRIMARY KEY (`return_id`);

--
-- Indexes for table `oc_return_action`
--
ALTER TABLE `oc_return_action`
  ADD PRIMARY KEY (`return_action_id`,`language_id`);

--
-- Indexes for table `oc_return_history`
--
ALTER TABLE `oc_return_history`
  ADD PRIMARY KEY (`return_history_id`);

--
-- Indexes for table `oc_return_reason`
--
ALTER TABLE `oc_return_reason`
  ADD PRIMARY KEY (`return_reason_id`,`language_id`);

--
-- Indexes for table `oc_return_status`
--
ALTER TABLE `oc_return_status`
  ADD PRIMARY KEY (`return_status_id`,`language_id`);

--
-- Indexes for table `oc_review`
--
ALTER TABLE `oc_review`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `oc_seo_url`
--
ALTER TABLE `oc_seo_url`
  ADD PRIMARY KEY (`seo_url_id`),
  ADD KEY `query` (`query`),
  ADD KEY `keyword` (`keyword`);

--
-- Indexes for table `oc_seo_url-2`
--
ALTER TABLE `oc_seo_url-2`
  ADD PRIMARY KEY (`seo_url_id`),
  ADD KEY `query` (`query`),
  ADD KEY `keyword` (`keyword`);

--
-- Indexes for table `oc_session`
--
ALTER TABLE `oc_session`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `oc_setting`
--
ALTER TABLE `oc_setting`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `oc_shipping_courier`
--
ALTER TABLE `oc_shipping_courier`
  ADD PRIMARY KEY (`shipping_courier_id`);

--
-- Indexes for table `oc_statistics`
--
ALTER TABLE `oc_statistics`
  ADD PRIMARY KEY (`statistics_id`);

--
-- Indexes for table `oc_stock_status`
--
ALTER TABLE `oc_stock_status`
  ADD PRIMARY KEY (`stock_status_id`,`language_id`);

--
-- Indexes for table `oc_store`
--
ALTER TABLE `oc_store`
  ADD PRIMARY KEY (`store_id`);

--
-- Indexes for table `oc_tax_class`
--
ALTER TABLE `oc_tax_class`
  ADD PRIMARY KEY (`tax_class_id`);

--
-- Indexes for table `oc_tax_rate`
--
ALTER TABLE `oc_tax_rate`
  ADD PRIMARY KEY (`tax_rate_id`);

--
-- Indexes for table `oc_tax_rate_to_customer_group`
--
ALTER TABLE `oc_tax_rate_to_customer_group`
  ADD PRIMARY KEY (`tax_rate_id`,`customer_group_id`);

--
-- Indexes for table `oc_tax_rule`
--
ALTER TABLE `oc_tax_rule`
  ADD PRIMARY KEY (`tax_rule_id`);

--
-- Indexes for table `oc_theme`
--
ALTER TABLE `oc_theme`
  ADD PRIMARY KEY (`theme_id`);

--
-- Indexes for table `oc_translation`
--
ALTER TABLE `oc_translation`
  ADD PRIMARY KEY (`translation_id`);

--
-- Indexes for table `oc_upload`
--
ALTER TABLE `oc_upload`
  ADD PRIMARY KEY (`upload_id`);

--
-- Indexes for table `oc_url_404`
--
ALTER TABLE `oc_url_404`
  ADD PRIMARY KEY (`url_404_id`),
  ADD KEY `query` (`query`(333));

--
-- Indexes for table `oc_url_absolute`
--
ALTER TABLE `oc_url_absolute`
  ADD PRIMARY KEY (`url_absolute_id`),
  ADD KEY `query` (`query`(333)),
  ADD KEY `redirect` (`redirect`(333));

--
-- Indexes for table `oc_url_redirect`
--
ALTER TABLE `oc_url_redirect`
  ADD PRIMARY KEY (`url_redirect_id`),
  ADD KEY `query` (`query`(333)),
  ADD KEY `redirect` (`redirect`(333));

--
-- Indexes for table `oc_user`
--
ALTER TABLE `oc_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `oc_user_group`
--
ALTER TABLE `oc_user_group`
  ADD PRIMARY KEY (`user_group_id`);

--
-- Indexes for table `oc_voucher`
--
ALTER TABLE `oc_voucher`
  ADD PRIMARY KEY (`voucher_id`);

--
-- Indexes for table `oc_voucher_history`
--
ALTER TABLE `oc_voucher_history`
  ADD PRIMARY KEY (`voucher_history_id`);

--
-- Indexes for table `oc_voucher_theme`
--
ALTER TABLE `oc_voucher_theme`
  ADD PRIMARY KEY (`voucher_theme_id`);

--
-- Indexes for table `oc_voucher_theme_description`
--
ALTER TABLE `oc_voucher_theme_description`
  ADD PRIMARY KEY (`voucher_theme_id`,`language_id`);

--
-- Indexes for table `oc_weight_class`
--
ALTER TABLE `oc_weight_class`
  ADD PRIMARY KEY (`weight_class_id`);

--
-- Indexes for table `oc_weight_class_description`
--
ALTER TABLE `oc_weight_class_description`
  ADD PRIMARY KEY (`weight_class_id`,`language_id`);

--
-- Indexes for table `oc_ya_money_payment`
--
ALTER TABLE `oc_ya_money_payment`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `oc_ya_money_payment_unq_payment_id` (`payment_id`);

--
-- Indexes for table `oc_ya_money_product_properties`
--
ALTER TABLE `oc_ya_money_product_properties`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `oc_ya_money_refunds`
--
ALTER TABLE `oc_ya_money_refunds`
  ADD PRIMARY KEY (`refund_id`),
  ADD KEY `oc_ya_money_refunds_idx_order_id` (`order_id`),
  ADD KEY `oc_ya_money_refunds_idx_payment_id` (`payment_id`);

--
-- Indexes for table `oc_zone`
--
ALTER TABLE `oc_zone`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indexes for table `oc_zone_to_geo_zone`
--
ALTER TABLE `oc_zone_to_geo_zone`
  ADD PRIMARY KEY (`zone_to_geo_zone_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `oc_address`
--
ALTER TABLE `oc_address`
  MODIFY `address_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_api`
--
ALTER TABLE `oc_api`
  MODIFY `api_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `oc_api_ip`
--
ALTER TABLE `oc_api_ip`
  MODIFY `api_ip_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_api_session`
--
ALTER TABLE `oc_api_session`
  MODIFY `api_session_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_attribute`
--
ALTER TABLE `oc_attribute`
  MODIFY `attribute_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `oc_attribute_group`
--
ALTER TABLE `oc_attribute_group`
  MODIFY `attribute_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `oc_banner`
--
ALTER TABLE `oc_banner`
  MODIFY `banner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `oc_banner_image`
--
ALTER TABLE `oc_banner_image`
  MODIFY `banner_image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `oc_cart`
--
ALTER TABLE `oc_cart`
  MODIFY `cart_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `oc_category`
--
ALTER TABLE `oc_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `oc_country`
--
ALTER TABLE `oc_country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=240;

--
-- AUTO_INCREMENT for table `oc_coupon`
--
ALTER TABLE `oc_coupon`
  MODIFY `coupon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `oc_coupon_history`
--
ALTER TABLE `oc_coupon_history`
  MODIFY `coupon_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_coupon_product`
--
ALTER TABLE `oc_coupon_product`
  MODIFY `coupon_product_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_currency`
--
ALTER TABLE `oc_currency`
  MODIFY `currency_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `oc_customer`
--
ALTER TABLE `oc_customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_customer_activity`
--
ALTER TABLE `oc_customer_activity`
  MODIFY `customer_activity_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_customer_approval`
--
ALTER TABLE `oc_customer_approval`
  MODIFY `customer_approval_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_customer_group`
--
ALTER TABLE `oc_customer_group`
  MODIFY `customer_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `oc_customer_history`
--
ALTER TABLE `oc_customer_history`
  MODIFY `customer_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_customer_ip`
--
ALTER TABLE `oc_customer_ip`
  MODIFY `customer_ip_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_customer_login`
--
ALTER TABLE `oc_customer_login`
  MODIFY `customer_login_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_customer_reward`
--
ALTER TABLE `oc_customer_reward`
  MODIFY `customer_reward_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_customer_search`
--
ALTER TABLE `oc_customer_search`
  MODIFY `customer_search_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_customer_transaction`
--
ALTER TABLE `oc_customer_transaction`
  MODIFY `customer_transaction_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_custom_field`
--
ALTER TABLE `oc_custom_field`
  MODIFY `custom_field_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_custom_field_value`
--
ALTER TABLE `oc_custom_field_value`
  MODIFY `custom_field_value_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_download`
--
ALTER TABLE `oc_download`
  MODIFY `download_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_event`
--
ALTER TABLE `oc_event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `oc_extension`
--
ALTER TABLE `oc_extension`
  MODIFY `extension_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `oc_extension_install`
--
ALTER TABLE `oc_extension_install`
  MODIFY `extension_install_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `oc_extension_path`
--
ALTER TABLE `oc_extension_path`
  MODIFY `extension_path_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1457;

--
-- AUTO_INCREMENT for table `oc_filter`
--
ALTER TABLE `oc_filter`
  MODIFY `filter_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_filter_group`
--
ALTER TABLE `oc_filter_group`
  MODIFY `filter_group_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_geo_zone`
--
ALTER TABLE `oc_geo_zone`
  MODIFY `geo_zone_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `oc_information`
--
ALTER TABLE `oc_information`
  MODIFY `information_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `oc_language`
--
ALTER TABLE `oc_language`
  MODIFY `language_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oc_layout`
--
ALTER TABLE `oc_layout`
  MODIFY `layout_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `oc_layout_module`
--
ALTER TABLE `oc_layout_module`
  MODIFY `layout_module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `oc_layout_route`
--
ALTER TABLE `oc_layout_route`
  MODIFY `layout_route_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `oc_length_class`
--
ALTER TABLE `oc_length_class`
  MODIFY `length_class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `oc_location`
--
ALTER TABLE `oc_location`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_manufacturer`
--
ALTER TABLE `oc_manufacturer`
  MODIFY `manufacturer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `oc_marketing`
--
ALTER TABLE `oc_marketing`
  MODIFY `marketing_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_modification`
--
ALTER TABLE `oc_modification`
  MODIFY `modification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `oc_module`
--
ALTER TABLE `oc_module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `oc_ocfilter_option`
--
ALTER TABLE `oc_ocfilter_option`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_ocfilter_option_value`
--
ALTER TABLE `oc_ocfilter_option_value`
  MODIFY `value_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_ocfilter_option_value_to_product`
--
ALTER TABLE `oc_ocfilter_option_value_to_product`
  MODIFY `ocfilter_option_value_to_product_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_ocfilter_page`
--
ALTER TABLE `oc_ocfilter_page`
  MODIFY `ocfilter_page_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_option`
--
ALTER TABLE `oc_option`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `oc_option_value`
--
ALTER TABLE `oc_option_value`
  MODIFY `option_value_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `oc_order`
--
ALTER TABLE `oc_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_order_history`
--
ALTER TABLE `oc_order_history`
  MODIFY `order_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_order_option`
--
ALTER TABLE `oc_order_option`
  MODIFY `order_option_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_order_product`
--
ALTER TABLE `oc_order_product`
  MODIFY `order_product_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_order_recurring`
--
ALTER TABLE `oc_order_recurring`
  MODIFY `order_recurring_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_order_recurring_transaction`
--
ALTER TABLE `oc_order_recurring_transaction`
  MODIFY `order_recurring_transaction_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_order_shipment`
--
ALTER TABLE `oc_order_shipment`
  MODIFY `order_shipment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_order_status`
--
ALTER TABLE `oc_order_status`
  MODIFY `order_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `oc_order_total`
--
ALTER TABLE `oc_order_total`
  MODIFY `order_total_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_order_voucher`
--
ALTER TABLE `oc_order_voucher`
  MODIFY `order_voucher_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_product`
--
ALTER TABLE `oc_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `oc_product_discount`
--
ALTER TABLE `oc_product_discount`
  MODIFY `product_discount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=441;

--
-- AUTO_INCREMENT for table `oc_product_image`
--
ALTER TABLE `oc_product_image`
  MODIFY `product_image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2352;

--
-- AUTO_INCREMENT for table `oc_product_option`
--
ALTER TABLE `oc_product_option`
  MODIFY `product_option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=227;

--
-- AUTO_INCREMENT for table `oc_product_option_value`
--
ALTER TABLE `oc_product_option_value`
  MODIFY `product_option_value_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `oc_product_reward`
--
ALTER TABLE `oc_product_reward`
  MODIFY `product_reward_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=546;

--
-- AUTO_INCREMENT for table `oc_product_special`
--
ALTER TABLE `oc_product_special`
  MODIFY `product_special_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=440;

--
-- AUTO_INCREMENT for table `oc_recurring`
--
ALTER TABLE `oc_recurring`
  MODIFY `recurring_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_return`
--
ALTER TABLE `oc_return`
  MODIFY `return_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_return_action`
--
ALTER TABLE `oc_return_action`
  MODIFY `return_action_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `oc_return_history`
--
ALTER TABLE `oc_return_history`
  MODIFY `return_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_return_reason`
--
ALTER TABLE `oc_return_reason`
  MODIFY `return_reason_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `oc_return_status`
--
ALTER TABLE `oc_return_status`
  MODIFY `return_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `oc_review`
--
ALTER TABLE `oc_review`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_seo_url`
--
ALTER TABLE `oc_seo_url`
  MODIFY `seo_url_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2101;

--
-- AUTO_INCREMENT for table `oc_seo_url-2`
--
ALTER TABLE `oc_seo_url-2`
  MODIFY `seo_url_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=906;

--
-- AUTO_INCREMENT for table `oc_setting`
--
ALTER TABLE `oc_setting`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2206;

--
-- AUTO_INCREMENT for table `oc_statistics`
--
ALTER TABLE `oc_statistics`
  MODIFY `statistics_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `oc_stock_status`
--
ALTER TABLE `oc_stock_status`
  MODIFY `stock_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `oc_store`
--
ALTER TABLE `oc_store`
  MODIFY `store_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_tax_class`
--
ALTER TABLE `oc_tax_class`
  MODIFY `tax_class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `oc_tax_rate`
--
ALTER TABLE `oc_tax_rate`
  MODIFY `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `oc_tax_rule`
--
ALTER TABLE `oc_tax_rule`
  MODIFY `tax_rule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `oc_theme`
--
ALTER TABLE `oc_theme`
  MODIFY `theme_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_translation`
--
ALTER TABLE `oc_translation`
  MODIFY `translation_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_upload`
--
ALTER TABLE `oc_upload`
  MODIFY `upload_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_url_404`
--
ALTER TABLE `oc_url_404`
  MODIFY `url_404_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_url_absolute`
--
ALTER TABLE `oc_url_absolute`
  MODIFY `url_absolute_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_url_redirect`
--
ALTER TABLE `oc_url_redirect`
  MODIFY `url_redirect_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `oc_user`
--
ALTER TABLE `oc_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `oc_user_group`
--
ALTER TABLE `oc_user_group`
  MODIFY `user_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `oc_voucher`
--
ALTER TABLE `oc_voucher`
  MODIFY `voucher_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_voucher_history`
--
ALTER TABLE `oc_voucher_history`
  MODIFY `voucher_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oc_voucher_theme`
--
ALTER TABLE `oc_voucher_theme`
  MODIFY `voucher_theme_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `oc_weight_class`
--
ALTER TABLE `oc_weight_class`
  MODIFY `weight_class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `oc_zone`
--
ALTER TABLE `oc_zone`
  MODIFY `zone_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4232;

--
-- AUTO_INCREMENT for table `oc_zone_to_geo_zone`
--
ALTER TABLE `oc_zone_to_geo_zone`
  MODIFY `zone_to_geo_zone_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
